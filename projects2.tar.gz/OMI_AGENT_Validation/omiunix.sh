#!/bin/bash
hostname
echo "======================================="
echo "=============OVC STATUS================"
/opt/OV/bin/ovc -status
echo "=============OPCAGT STATUS============="
/opt/OV/bin/opcagt -status
echo "=============OVCERT CHECK=============="
/opt/OV/bin/ovcert -check
echo "=============OVCONFGET STATUS=========="
/opt/OV/bin/ovconfget
echo "=============PING OMICOLECTOR=========="
/opt/OV/bin/bbcutil -ping omicolector.uio.bpichincha.com
echo "============AGENT VERSION VALIDATION==========="
/opt/OV/bin/opcagt -version
