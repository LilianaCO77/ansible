#!/bin/bash
hostname
echo "======================================="
echo "=============OVC STATUS================"
/usr/lpp/OV/bin/ovc -status
echo "=============OPCAGT STATUS============="
/usr/lpp/OV/bin/opcagt -status
echo "=============OVCERT CHECK=============="
/usr/lpp/OV/bin/ovcert -check
echo "=============OVCONFGET STATUS=========="
/usr/lpp/OV/bin/ovconfget
echo "=============PING OMICOLECTOR=========="
/usr/lpp/OV/bin/bbcutil -ping omicolector.uio.bpichincha.com
echo "============AGENT VERSION VALIDATION==========="
/usr/lpp/OV/bin/opcagt -version
