NB_AIX=/backup/NetBackup_7.7.3_CLIENTS1_AIX/NBClients/anb/Clients/usr/openv/netbackup/client/RS6000/AIX6
gunzip -cd ${NB_AIX}/pddeagent.tar.gz | tar -xvf -
