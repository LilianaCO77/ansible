#!/usr/bin/expect -f
set timeout -1
spawn ssh -o "StrictHostKeyChecking=no" -o "UserKnownHostsFile=/dev/null" admin@10.151.16.131
expect "admin@10.151.16.131's password:"
send "*sw112133pd\r"
expect "sansw_bp11:FID128:admin>"
send "cfgsave\r"
expect "]"
send "y\r"
expect "sansw_bp11:FID128:admin>"
send "exit\r"
expect eof
