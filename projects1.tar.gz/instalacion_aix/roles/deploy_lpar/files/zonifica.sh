#!/bin/bash
#VARIABLES
PDa=ds8kpda.ini
FOa=ds8kfoa.ini
PDb=ds8kpdb.ini
FOb=ds8kfob.ini
HIa=hitachia.ini
HIb=hitachib.ini
DRa=ds8kdra.ini
DRb=ds8kdrb.ini
HId=hitachid.ini
HIe=hitachie.ini
V9a=v9000a.ini
V9b=v9000b.ini
ALa=alia.sh
ALb=alib.sh
ALd=alid.sh
ALe=alie.sh
IPSW1="10.70.152.24"
IPSW2="10.70.152.28"
IPSW3="172.26.8.50"
IPSW4="172.26.8.53"
SAN1="BPichincha_fabricA"
SAN2="BPichincha_fabricB"
server=$1
power=$2
stg=$3

>cfg_sw1.txt
>cfg_sw2.txt
echo "Inicia zonificacion hacia storage $stg"
echo "Obteniendo WWNs del servidor $server"
ssh -i ~/.ssh/id_rsa -o "StrictHostKeyChecking=no" -o "UserKnownHostsFile=/dev/null" hscroot@10.70.152.29 "lssyscfg -m $power -r prof --filter lpar_names=$server,profile_names=Normal -F virtual_fc_adapters" > fibras.txt
cat fibras.txt | awk -F '/' '{ print $5,$6,$11,$12,$17,$18,$23,$24,$29,$30,$35,$36}' | xargs -n2 | awk -F ',' '{print $1}' | sort -n | awk '{print $2}' | sed 's/../&:/g;s/:$//' > wwns.txt
fc0=`cat wwns.txt | sed -n 1p`
fc1=`cat wwns.txt | sed -n 2p`
fc2=`cat wwns.txt | sed -n 3p`
fc3=`cat wwns.txt | sed -n 4p`

case $stg in
	V9000) for alias in $(cat $V9a)
       		do
			./$ALa $alias > salida.out
		   cant=`cat salida.out | grep zone: | wc -l` 
		   echo " $cant $alias" >> cfg_sw1.txt
                done
		puerto1=`cat cfg_sw1.txt | sort -n | sed -n 1p | awk '{print $2}'`
		puerto2=`cat cfg_sw1.txt | sort -n | sed -n 2p | awk '{print $2}'`
		a1="alicreate \"ALI_"$server"_fcs0\",\""$fc0"\""
		a2="alicreate \"ALI_"$server"_fcs2\",\""$fc2"\""
		z1="zonecreate \"ZONE_"$server"_fcs0_V9000\", \"ALI_"$server"_fcs0;"$puerto1"\""
		z2="zonecreate \"ZONE_"$server"_fcs2_V9000\", \"ALI_"$server"_fcs2;"$puerto2"\""
		cfad1="cfgadd \"BPichincha_fabricA\",\"ZONE_"$server"_fcs0_V9000\""
		cfad2="cfgadd \"BPichincha_fabricA\",\"ZONE_"$server"_fcs2_V9000\""
		for alias1 in $(cat $V9b)
		do
	           ./$ALb $alias1 > salida.out
			   cant1=`cat salida.out | grep zone: | wc -l`
		   echo " $cant1 $alias1" >> cfg_sw2.txt
		done
		puerto3=`cat cfg_sw2.txt | sort -n | sed -n 1p | awk '{print $2}'`
		puerto4=`cat cfg_sw2.txt | sort -n | sed -n 2p | awk '{print $2}'`
		a3="alicreate \"ALI_"$server"_fcs1\",\""$fc1"\""
		a4="alicreate \"ALI_"$server"_fcs3\",\""$fc3"\""
		z3="zonecreate \"ZONE_"$server"_fcs1_V9000\", \"ALI_"$server"_fcs1;"$puerto3"\""
		z4="zonecreate \"ZONE_"$server"_fcs3_V9000\", \"ALI_"$server"_fcs3;"$puerto4"\""
		cfad3="cfgadd \"BPichincha_fabricB\",\"ZONE_"$server"_fcs1_V9000\""
		cfad4="cfgadd \"BPichincha_fabricB\",\"ZONE_"$server"_fcs3_V9000\""
		echo "Creando zonas en el switch 1"
		./cfgsa.sh "$a1" "$a2" "$z1" "$z2" "$cfad1" "$cfad2"
		echo "Creando zonas en el switch 2"
		./cfgsb.sh "$a3" "$a4" "$z3" "$z4" "$cfad3" "$cfad4"
		echo " "
		echo " "
		echo "**********************************************FIN************************************************";;
        ds8kfo) for alias in $(cat $FOa)
		do
			./$ALa $alias > salida.out
			cant=`cat salida.out | grep zone: | wc -l` 
			echo " $cant $alias" >> cfg_sw1.txt
		done
		puerto1=`cat cfg_sw1.txt | sort -n | sed -n 1p | awk '{print $2}'`
		puerto2=`cat cfg_sw1.txt | sort -n | sed -n 2p | awk '{print $2}'`
		a1="alicreate \"ALI_"$server"_fcs0\",\""$fc0"\""
		a2="alicreate \"ALI_"$server"_fcs2\",\""$fc2"\""
		z1="zonecreate \"ZONE_"$server"_fcs0_DS8Kfo\", \"ALI_"$server"_fcs0;"$puerto1"\""
		z2="zonecreate \"ZONE_"$server"_fcs2_DS8Kfo\", \"ALI_"$server"_fcs2;"$puerto2"\""
		cfad1="cfgadd \"BPichincha_fabricA\",\"ZONE_"$server"_fcs0_DS8Kfo\""
		cfad2="cfgadd \"BPichincha_fabricA\",\"ZONE_"$server"_fcs2_DS8Kfo\""
		for alias1 in $(cat $FOb)
		do
	       	./$ALb $alias1 > salida.out
		   cant1=`cat salida.out | grep zone: | wc -l` 
		   echo " $cant1 $alias1" >> cfg_sw2.txt
		done
		puerto3=`cat cfg_sw2.txt | sort -n | sed -n 1p | awk '{print $2}'`
		puerto4=`cat cfg_sw2.txt | sort -n | sed -n 2p | awk '{print $2}'`
		a3="alicreate \"ALI_"$server"_fcs1\",\""$fc1"\""
		a4="alicreate \"ALI_"$server"_fcs3\",\""$fc3"\""
		z3="zonecreate \"ZONE_"$server"_fcs1_DS8Kfo\", \"ALI_"$server"_fcs1;"$puerto3"\""
		z4="zonecreate \"ZONE_"$server"_fcs3_DS8Kfo\", \"ALI_"$server"_fcs3;"$puerto4"\""
		cfad3="cfgadd \"BPichincha_fabricB\",\"ZONE_"$server"_fcs1_DS8Kfo\""
		cfad4="cfgadd \"BPichincha_fabricB\",\"ZONE_"$server"_fcs3_DS8Kfo\""
		echo "Creando zonas en el switch 1"
		./cfgsa.sh "$a1" "$a2" "$z1" "$z2" "$cfad1" "$cfad2"
		echo "Creando zonas en el switch 2"
		./cfgsb.sh "$a3" "$a4" "$z3" "$z4" "$cfad3" "$cfad4"
		echo " "
		echo " "
		echo "**********************************************FIN************************************************";;
	VSPpd)   puerto1=`cat $HIa | sed -n 1p`
	         puerto2=`cat $HIa | sed -n 2p`
		 puerto3=`cat $HIb | sed -n 1p`
		 puerto4=`cat $HIb | sed -n 2p`
		 a1="alicreate \"ALI_"$server"_fcs0\",\""$fc0"\""
		 a2="alicreate \"ALI_"$server"_fcs2\",\""$fc2"\""
		 a3="alicreate \"ALI_"$server"_fcs1\",\""$fc1"\""
		 a4="alicreate \"ALI_"$server"_fcs3\",\""$fc3"\""
		 z1="zonecreate \"ZONE_"$server"_fcs0_STGSVPP01\", \"ALI_"$server"_fcs0;"$puerto1"\""
		 z2="zonecreate \"ZONE_"$server"_fcs2_STGSVPP01\", \"ALI_"$server"_fcs2;"$puerto2"\""
		 z3="zonecreate \"ZONE_"$server"_fcs1_STGSVPP01\", \"ALI_"$server"_fcs1;"$puerto3"\""
		 z4="zonecreate \"ZONE_"$server"_fcs3_STGSVPP01\", \"ALI_"$server"_fcs3;"$puerto4"\""
		 cfad1="cfgadd \"BPichincha_fabricA\",\"ZONE_"$server"_fcs0_STGSVPP01\""
		 cfad2="cfgadd \"BPichincha_fabricA\",\"ZONE_"$server"_fcs2_STGSVPP01\""
		 cfad3="cfgadd \"BPichincha_fabricB\",\"ZONE_"$server"_fcs1_STGSVPP01\""
		 cfad4="cfgadd \"BPichincha_fabricB\",\"ZONE_"$server"_fcs3_STGSVPP01\""
		 echo "Creando zonas en el switch 1"
		 ./cfgsa.sh "$a1" "$a2" "$z1" "$z2" "$cfad1" "$cfad2"
		 echo "Creando zonas en el switch 2"
		 ./cfgsb.sh "$a3" "$a4" "$z3" "$z4" "$cfad3" "$cfad4"
		 echo " "
		 echo " "
		 echo "**********************************************FIN************************************************";;
        ds8kdr) for alias in $(cat $DRa)
		do
			./$ALd $alias > salida.out
			cant=`cat salida.out | grep zone: | wc -l` 
			echo " $cant $alias" >> cfg_sw1.txt
		done
		puerto1=`cat cfg_sw1.txt | sort -n | sed -n 1p | awk '{print $2}'`
		puerto2=`cat cfg_sw1.txt | sort -n | sed -n 2p | awk '{print $2}'`
		a1="alicreate \"ALI_"$server"_fcs0\",\""$fc0"\""
		a2="alicreate \"ALI_"$server"_fcs2\",\""$fc2"\""
		z1="zonecreate \"ZONE_"$server"_fcs0_DS8KDR\", \"ALI_"$server"_fcs0;"$puerto1"\""
		z2="zonecreate \"ZONE_"$server"_fcs2_DS8KDR\", \"ALI_"$server"_fcs2;"$puerto2"\""
		cfad1="cfgadd \"sansw_bp101\",\"ZONE_"$server"_fcs0_DS8KDR\""
		cfad2="cfgadd \"sansw_bp101\",\"ZONE_"$server"_fcs2_DS8KDR\""
		for alias1 in $(cat $DRb)
		do
			./$ALe $alias1 > salida.out
			cant1=`cat salida.out | grep zone: | wc -l` 
			echo " $cant1 $alias1" >> cfg_sw2.txt
		done
		puerto3=`cat cfg_sw2.txt | sort -n | sed -n 1p | awk '{print $2}'`
		puerto4=`cat cfg_sw2.txt | sort -n | sed -n 2p | awk '{print $2}'`
		a3="alicreate \"ALI_"$server"_fcs1\",\""$fc1"\""
		a4="alicreate \"ALI_"$server"_fcs3\",\""$fc3"\""
		z3="zonecreate \"ZONE_"$server"_fcs1_DS8KDR\", \"ALI_"$server"_fcs1;"$puerto3"\""
		z4="zonecreate \"ZONE_"$server"_fcs3_DS8KDR\", \"ALI_"$server"_fcs3;"$puerto4"\""
		cfad3="cfgadd \"sansw_bp102\",\"ZONE_"$server"_fcs1_DS8KDR\""
		cfad4="cfgadd \"sansw_bp102\",\"ZONE_"$server"_fcs3_DS8KDR\""
		echo "Creando zonas en el switch 1"
		./cfgsd.sh "$a1" "$a2" "$z1" "$z2" "$cfad1" "$cfad2"
		echo "Creando zonas en el switch 2"
		./cfgse.sh "$a3" "$a4" "$z3" "$z4" "$cfad3" "$cfad4"
		echo " "
		echo " "
		echo "**********************************************FIN************************************************";;
	VSPdr)	for alias in $(cat $HId)
		do
			./$ALd $alias > salida.out
			cant=`cat salida.out | grep zone: | wc -l` 
			echo " $cant $alias" >> cfg_sw1.txt
		done
		puerto1=`cat cfg_sw1.txt | sort -n | sed -n 1p | awk '{print $2}'`
		puerto2=`cat cfg_sw1.txt | sort -n | sed -n 2p | awk '{print $2}'`
		a1="alicreate \"ALI_"$server"_fcs0\",\""$fc0"\""
		a2="alicreate \"ALI_"$server"_fcs2\",\""$fc2"\""
		z1="zonecreate \"ZONE_"$server"_fcs0_STGSVPA\", \"ALI_"$server"_fcs0;"$puerto1"\""
		z2="zonecreate \"ZONE_"$server"_fcs2_STGSVPA\", \"ALI_"$server"_fcs2;"$puerto2"\""
		cfad1="cfgadd \"sansw_bp101\",\"ZONE_"$server"_fcs0_STGSVPA\""
		cfad2="cfgadd \"sansw_bp101\",\"ZONE_"$server"_fcs2_STGSVPA\""
		for alias1 in $(cat $HIe)
		do
			./$ALe $alias1 > salida.out
			cant1=`cat salida.out | grep zone: | wc -l` 
			echo " $cant1 $alias1" >> cfg_sw2.txt
		done
		puerto3=`cat cfg_sw2.txt | sort -n | sed -n 1p | awk '{print $2}'`
		puerto4=`cat cfg_sw2.txt | sort -n | sed -n 2p | awk '{print $2}'`
		a3="alicreate \"ALI_"$server"_fcs1\",\""$fc1"\""
		a4="alicreate \"ALI_"$server"_fcs3\",\""$fc3"\""
		z3="zonecreate \"ZONE_"$server"_fcs1_STGSVPA\", \"ALI_"$server"_fcs1;"$puerto3"\""
		z4="zonecreate \"ZONE_"$server"_fcs3_STGSVPA\", \"ALI_"$server"_fcs3;"$puerto4"\""
		cfad3="cfgadd \"sansw_bp102\",\"ZONE_"$server"_fcs1_STGSVPA\""
		cfad4="cfgadd \"sansw_bp102\",\"ZONE_"$server"_fcs3_STGSVPA\""
		echo "Creando zonas en el switch 1"
		./cfgsd.sh "$a1" "$a2" "$z1" "$z2" "$cfad1" "$cfad2"
		echo "Creando zonas en el switch 2"
		./cfgse.sh "$a3" "$a4" "$z3" "$z4" "$cfad3" "$cfad4"
		echo " "
		echo " "
		echo "**********************************************FIN************************************************";;
        *) echo " "
		echo "Ingrese correctamente el nombre del storage"
		echo " "
		echo "**********************************************FIN************************************************"
		exit 0;;
esac
