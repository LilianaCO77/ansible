#!/bin/bash
#VARIABLES
PD=ds8kpd.ini
FO=ds8kfo.ini
IPSW1="10.70.152.24"

echo "Ingrese el storage hacia el cual zonificar: \c"
read stg
case $stg in
	ds8kpd) for alias in $(cat $PD)
		do
			echo "buscando alias $alias"
		done;;	
	ds8kfo) cat $FO;;
        *) echo "mal";;
esac

