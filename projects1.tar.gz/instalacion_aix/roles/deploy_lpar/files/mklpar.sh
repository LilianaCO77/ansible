##################################################################################################################################
#Script para crear LPAR IBM POWER                                                                                                #
##################################################################################################################################
#Parametros:                                                                                                                     #
#$1 corresponde al id del Power en donde se van a generar la o las lpars Ej. "Server-9119-MHE-SN21A6E57-PD"                      #
##################################################################################################################################
#!/bin/bash
#VARIABLES
ADDFC="./DefPfc.sh"
ZONF="./zonifica.sh"
#NSLOTS=$(($IDLPAR + 1))0
#if [ $# -ne 1 ] 
#then
#  echo "Por favor ingrese el id del Power Ej Server-XXXX-MHE-SNXXXXXXX-PD"
#  exit 1
#fi
#POWER=$1
LPARINI=lpars.ini

for conflpar in $( cat $LPARINI )
do
	clear
	LPAR=`echo $conflpar | cut -d ";" -f1`
	IDLPAR=`echo $conflpar | cut -d ";" -f2`
	MINMEM=`echo $conflpar | cut -d ";" -f3`
	DESMEM=`echo $conflpar | cut -d ";" -f4`
	MAXMEM=`echo $conflpar | cut -d ";" -f5`
	MINPROC=`echo $conflpar | cut -d ";" -f6`
	DESPROC=`echo $conflpar | cut -d ";" -f7`
	MAXPROC=`echo $conflpar | cut -d ";" -f8`
	UPROCMIN=`echo $conflpar | cut -d ";" -f9`
    UPROCDES=`echo $conflpar | cut -d ";" -f10`
	UPROCMAX=`echo $conflpar | cut -d ";" -f11`
	IDVIOS1=`echo $conflpar | cut -d ";" -f12`
	VIOS1=`echo $conflpar | cut -d ";" -f13`
	IDVIOS2=`echo $conflpar | cut -d ";" -f14`
	VIOS2=`echo $conflpar | cut -d ";" -f15`
	POWER=`echo $conflpar | cut -d ";" -f16`
	IPHMC=`echo $conflpar | cut -d ";" -f17`
	STORAGE=`echo $conflpar | cut -d ";" -f18`
	NSLOTS=$(($IDLPAR + 1))0

      CMM="mksyscfg -r lpar -m $POWER -i \"name=$LPAR, lpar_id=$IDLPAR, profile_name=Normal, lpar_env=aixlinux, min_mem=$MINMEM, desired_mem=$DESMEM, max_mem=$MAXMEM, proc_mode=shared, min_proc_units=$MINPROC, desired_proc_units=$DESPROC, max_proc_units=$MAXPROC, min_procs=$UPROCMIN, desired_procs=$UPROCDES, max_procs=$UPROCMAX, sharing_mode=cap, uncap_weight=0, boot_mode=norm, conn_monitoring=1, max_virtual_slots=$NSLOTS, virtual_scsi_adapters=$(($IDLPAR))0/client/$IDVIOS1/$VIOS1/$(($IDLPAR))0/0,\\\"virtual_fc_adapters=$(($IDLPAR))1/client/$IDVIOS1/$VIOS1/$(($IDLPAR))1//0,$(($IDLPAR))2/client/$IDVIOS1/$VIOS1/$(($IDLPAR))2//0,$(($IDLPAR))3/client/$IDVIOS2/$VIOS2/$(($IDLPAR))3//0,$(($IDLPAR))4/client/$IDVIOS2/$VIOS2/$(($IDLPAR))4//0,$(($IDLPAR))8/client/$IDVIOS1/$VIOS1/$(($IDLPAR))8//0,$(($IDLPAR))9/client/$IDVIOS2/$VIOS2/$(($IDLPAR))9//0\\\" \" "
      echo "Creando LPAR $LPAR"
      ssh -i /var/lib/awx/.ssh/id_rsa -o "StrictHostKeyChecking=no" -o "UserKnownHostsFile=/dev/null" hscroot@$IPHMC $CMM
      #echo $CMM
      for ((fcs=0;fcs<7;fcs++))
      do
      	case $fcs in
		0 )
		    HW="chhwres -r virtualio -m $POWER -o a -p $VIOS1 --rsubtype scsi -s $(($IDLPAR))$fcs -a \"adapter_type=server,remote_lpar_name=$LPAR,remote_slot_num=$(($IDLPAR))$fcs\""
			ssh  -i ~/.ssh/id_rsa -o "StrictHostKeyChecking=no" -o "UserKnownHostsFile=/dev/null" hscroot@$IPHMC $HW
			#echo $HW
			#echo "ssh hscroot@$IPHMC $HW"
			echo "Creando virtual SCSI"
			;;
		[1-2] )
			HW="chhwres -r virtualio -m $POWER -o a -p $VIOS1 --rsubtype fc -s $(($IDLPAR))$fcs -a \"adapter_type=server,remote_lpar_name=$LPAR,remote_slot_num=$(($IDLPAR))$fcs\""
			#echo $HW
			ssh  -i ~/.ssh/id_rsa -o "StrictHostKeyChecking=no" -o "UserKnownHostsFile=/dev/null" hscroot@$IPHMC $HW
			echo "Creando fcs$fcs en $VIOS1"
			;;
		[3-4] )
			HW="chhwres -r virtualio -m $POWER -o a -p $VIOS2 --rsubtype fc -s $(($IDLPAR))$fcs -a \"adapter_type=server,remote_lpar_name=$LPAR,remote_slot_num=$(($IDLPAR))$fcs\""
			#echo $HW
			ssh  -i ~/.ssh/id_rsa -o "StrictHostKeyChecking=no" -o "UserKnownHostsFile=/dev/null" hscroot@$IPHMC $HW
			echo "Creando fcs$fcs en $VIOS2"
			;;
		5 )
			HW="chhwres -r virtualio -m $POWER -o a -p $VIOS1 --rsubtype fc -s $(($IDLPAR))8 -a \"adapter_type=server,remote_lpar_name=$LPAR,remote_slot_num=$(($IDLPAR))8\""
			#echo $HW
			ssh  -i ~/.ssh/id_rsa -o "StrictHostKeyChecking=no" -o "UserKnownHostsFile=/dev/null" hscroot@$IPHMC $HW
			echo "Creando fcs$fcs en $VIOS1"
			;;
		6 )
			HW="chhwres -r virtualio -m $POWER -o a -p $VIOS2 --rsubtype fc -s $(($IDLPAR))9 -a \"adapter_type=server,remote_lpar_name=$LPAR,remote_slot_num=$(($IDLPAR))9\""
			#echo $HW
			ssh -i ~/.ssh/id_rsa -o "StrictHostKeyChecking=no" -o "UserKnownHostsFile=/dev/null" hscroot@$IPHMC $HW
			echo "Creando fcs$fcs en $VIOS2"
		        ;;
		esac
		
      done
	 
	 sh $ADDFC $VIOS1 $VIOS2 $IDLPAR 
	 sh $ZONF $LPAR $POWER $STORAGE
done
printf "Fin de la ejecucion .......\n"
#echo $IDLPAR
#echo $NSLOTS
#echo $POWER
