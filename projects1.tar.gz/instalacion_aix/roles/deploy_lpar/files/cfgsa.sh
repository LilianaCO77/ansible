#!/usr/bin/expect -f
set timeout -1
set alias1 [lindex $argv 0]
set alias2 [lindex $argv 1]
set zone1 [lindex $argv 2]
set zone2 [lindex $argv 3]
set zonead1 [lindex $argv 4]
set zonead2 [lindex $argv 5]
spawn ssh -o "StrictHostKeyChecking=no" -o "UserKnownHostsFile=/dev/null" admin@10.70.152.24
expect "admin@10.70.152.24's password:"
send "sw472133pd\r"
expect "sansw_bp47:FID128:admin>"
send "$alias1\r"
expect "sansw_bp47:FID128:admin>"
send "$alias2\r"
expect "sansw_bp47:FID128:admin>"
send "$zone1\r"
expect "sansw_bp47:FID128:admin>"
send "$zone2\r"
expect "sansw_bp47:FID128:admin>"
send "$zonead1\r"
expect "sansw_bp47:FID128:admin>"
send "$zonead2\r"
expect "sansw_bp47:FID128:admin>"
send "cfgsave\r"
expect "]"
send "y\r"
expect "sansw_bp47:FID128:admin>"
send "cfgenable BPichincha_fabricA\r"
expect "]"
send "y\r"
expect "sansw_bp47:FID128:admin>"
send "exit\r"
expect eof
