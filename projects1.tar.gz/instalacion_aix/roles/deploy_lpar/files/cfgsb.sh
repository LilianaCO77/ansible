#!/usr/bin/expect -f
set timeout -1
set alias3 [lindex $argv 0]
set alias4 [lindex $argv 1]
set zone3 [lindex $argv 2]
set zone4 [lindex $argv 3]
set zonead3 [lindex $argv 4]
set zonead4 [lindex $argv 5]
spawn ssh -o "StrictHostKeyChecking=no" -o "UserKnownHostsFile=/dev/null" admin@10.70.152.28
expect "admin@10.70.152.28's password:"
send "sw482133pd\r"
expect "sansw_bp48:FID128:admin>"
send "$alias3\r"
expect "sansw_bp48:FID128:admin>"
send "$alias4\r"
expect "sansw_bp48:FID128:admin>"
send "$zone3\r"
expect "sansw_bp48:FID128:admin>"
send "$zone4\r"
expect "sansw_bp48:FID128:admin>"
send "$zonead3\r"
expect "sansw_bp48:FID128:admin>"
send "$zonead4\r"
expect "sansw_bp48:FID128:admin>"
send "cfgsave\r"
expect "]"
send "y\r"
expect "sansw_bp48:FID128:admin>"
send "cfgenable BPichincha_fabricB\r"
expect "]"
send "y\r"
expect "sansw_bp48:FID128:admin>"
send "exit\r"
expect eof
