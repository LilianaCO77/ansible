#!/usr/bin/ksh
VIOS1=$1
VIOS2=$2
FNWK=nwk.cfg
FPFC=fc.cfg
COM="ioscli lsmap -all -npiv"

IPVIOS1=`cat $FNWK | grep $VIOS1 | cut -d ":" -f2`

for fiber in $(cat $FPFC | grep $VIOS1)
do
	PFC=`echo $fiber | cut -d ":" -f2`
	FCN=`ssh -i ~/.ssh/id_rsa -o "StrictHostKeyChecking=no" -o "UserKnownHostsFile=/dev/null" -q padmin@$IPVIOS1 $COM | sed -n /"FC name"/p | awk '{print $2}' | awk -v fc=$PFC -F: '$2==fc {print $2}' | wc -l`
	printf "$FCN:$PFC\n" >> FCS.out
	
done
