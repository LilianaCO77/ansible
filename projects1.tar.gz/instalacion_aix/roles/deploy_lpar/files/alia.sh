#!/usr/bin/expect -f
set timeout -1
set alias [lindex $argv 0]
spawn ssh -o "StrictHostKeyChecking=no" -o "UserKnownHostsFile=/dev/null" admin@10.70.152.24
expect "admin@10.70.152.24's password:"
send "sw472133pd\r"
expect "sansw_bp47:FID128:admin>"
send "zoneshow --ali $alias | grep zone\r"
send "exit\r"
expect eof
