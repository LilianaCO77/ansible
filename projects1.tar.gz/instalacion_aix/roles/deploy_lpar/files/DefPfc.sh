##################################################################################################################################
#Script para asignar FC a las LPAR                                                                                               #
##################################################################################################################################
#Parámetros:                                                                                                                     #
#$1 corresponde el nombre del VIOS Ej. "PRVIOS01E1"														                         #
##################################################################################################################################
#!/bin/bash
#VARIABLES
FTEM=ports.ini
FPFC=fc.cfg
FNWK=nwk.cfg
FCM=FCS.out
VIOS1=$1
VIOS2=$2
IDLPAR=$3
VFCH=vfchost.ini

#printf "Por favor ingrese la ip del VIOS1\n"
#read IPVIOS
IPVIOS1=`cat $FNWK | grep $VIOS1 | cut -d ":" -f2`
IPVIOS2=`cat $FNWK | grep $VIOS2 | cut -d ":" -f2`
printf "Cargando FC fisicas del VIOS $VIOS1. Por favor espere .......\n"
#CMM="ioscli lsnports"
CMM="fcvios.sh"
#ssh -q padmin@$IPVIOS1 $CMM > $FTEM
sh ./$CMM $VIOS1 $VIOS2
################Comentado JI##############################################
#printf "FC\tTOT_NPIV\tNPIV_DISP\tNPIV_USO\n"
#for Fiber in $(cat $FPFC | grep $VIOS1)
#do
#	PFC=`echo $Fiber | cut -d ":" -f2`
#	cat $FTEM | grep $PFC | awk '{print $1,"\t",$4,"\t\t",$5,"\t\t",$4-$5}'
#done

FCS=`cat $FCM | sort |  cut -d ":" -f2 | sed -n 1p`
FCS2=`cat $FPFC | grep $VIOS1 | grep $FCS | cut -d ":" -f3`
printf "La LPAR se mapea a las fibras $FCS y $FCS2\n"

for IP in $IPVIOS1 $IPVIOS2
do
	CMM="ioscli lsmap -all -npiv | grep C$IDLPAR"
	ssh -i ~/.ssh/id_rsa -o "StrictHostKeyChecking=no" -o "UserKnownHostsFile=/dev/null" -q padmin@$IP $CMM | awk -v lpid=$IDLPAR '$3==lpid {print $1}' > $VFCH
	vFiber1=`sed -n '1p' $VFCH`
	vFiber2=`sed -n '2p' $VFCH`

	CMM="ioscli vfcmap -vadapter $vFiber1 -fcp $FCS; ioscli vfcmap -vadapter $vFiber2 -fcp $FCS2"
	ssh -i ~/.ssh/id_rsa -o "StrictHostKeyChecking=no" -o "UserKnownHostsFile=/dev/null" -q padmin@$IP $CMM
	#CMM="ioscli vfcmap -vadapter $vFiber2 -fcp $FCS2"
	#ssh -q padmin@$IP $CMM
done
