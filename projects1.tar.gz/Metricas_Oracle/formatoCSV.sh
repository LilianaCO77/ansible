# /bin/sh
head -4 /tmp/Reporting.txt |awk 'BEGIN { OFS=";" } { print $1,$2,$3,$4,$5,$6}' > /tmp/ReportingOracle.csv
