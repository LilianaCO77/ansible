echo > /tmp/ClbSSH/`hostname`_resultados_MD5.txt
find / -type f \( -name 'authorized_keys' -o -name 'id_rsa' -o -name 'id_dsa' -o -name '*_rsa' -o -name '*_dsa' -o -name '*_key' -o -name '*.pub' -o -name '*.priv' -o -name '*.prv' -o -name '*.key' -o -name '*.pem' -o -name '*.ss' -o -name '*.cert' -o -name '*.crt' \) -print 2>/dev/null | while read registro
do
   _perm=`ls -alt $registro`
   _hash=`ssh-keygen -l -E md5 -f $registro 2>/dev/null`
   _vige=`/usr/bin/openssl x509 -enddate -noout -in $registro 2>/dev/null`
   echo `hostname`@$_perm@$_vige@HASH=\($_hash\) >> /tmp/ClbSSH/`hostname`_resultados_MD5.txt
done
