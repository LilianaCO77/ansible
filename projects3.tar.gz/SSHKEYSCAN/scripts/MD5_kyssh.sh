echo find / -type f \\\\\( -name \'authorized_keys\' -o -name \'id_rsa\' -o -name \'id_dsa\' -o -name \'*_rsa\' -o -name \'*_dsa\' -o -name \'*_key\' -o -name \'*.pub\' -o -name \'*.priv\' -o -name \'*.prv\' -o -name \'*.key\' -o -name \'*.pem\' -o -name \'*.ss\' -o -name \'*.cert\' -o -name \'*.crt\' \\\\\) -print \2\>\/dev\/null \| while read registro > /tmp/MD5_kyssh.sh
echo "do" >> /tmp/MD5_kyssh.sh
echo "   _perm=\`ls -alt \$registro\`" >> /tmp/MD5_kyssh.sh
echo "   _hash=\`ssh-keygen -l -E md5 -f \$registro 2>/dev/null\`" >> /tmp/MD5_kyssh.sh
echo "   _vige=\`/usr/bin/openssl x509 -enddate -noout -in \$registro 2>/dev/null\`" >> /tmp/MD5_kyssh.sh
echo "   echo \`hostname\`@\$_perm@\$_vige@HASH=\(\$_hash\)" >> /tmp/MD5_kyssh.sh
echo "done" >> /tmp/MD5_kyssh.sh
chmod +x /tmp/MD5_kyssh.sh
sh /tmp/MD5_kyssh.sh > /tmp/`hostname`_resultados_MD5.txt
