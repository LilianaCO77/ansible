echo find / -type f -name \'authorized_keys\' -o -name \'id_rsa\' -o -name \'id_dsa\' -o -name \'*_rsa\' -o -name \'*_dsa\' -o -name \'*_key\' -o -name \'*.pub\' -o -name \'*.priv\' -o -name \'*.prv\' -o -name \'*.key\' -o -name \'*.pem\' -o -name \'*.ss\' -o -name \'*.cert\' -o -name \'*.crt\' -print \2\>\/dev\/null \| while read registro > /tmp/SHA256_kyssh.sh
echo "do" >> /tmp/SHA256_kyssh.sh
echo "   _perm=\`ls -alt \$registro\`" >> /tmp/SHA256_kyssh.sh
echo "   _hash=\`ssh-keygen -l -f \$registro 2>/dev/null\`" >> /tmp/SHA256_kyssh.sh
echo "   _vige=\`/usr/bin/openssl x509 -enddate -noout -in \$registro 2>/dev/null\`" >> /tmp/SHA256_kyssh.sh
echo "   echo \`hostname\`@\$_perm@\$_vige@HASH=\(\$_hash\)" >> /tmp/SHA256_kyssh.sh
echo "done" >> /tmp/SHA256_kyssh.sh
chmod +x /tmp/SHA256_kyssh.sh
sh /tmp/SHA256_kyssh.sh > /tmp/`hostname`_resultados_SHA256.txt
