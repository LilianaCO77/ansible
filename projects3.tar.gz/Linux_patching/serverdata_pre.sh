#!/bin/sh
#scrip obtener informacion antes de actualizar el SO
server=`hostname`
date=`date "+%d%m%Y"`
mkdir /home/fdgarcia/$server-$date-prepatch
home=/home/fdgarcia/$server-$date-prepatch
rpm -qa > $home/paqinst_$server
df -hT > $home/filesystems_$server
lvmdiskscan > $home/discos_$server
echo -e "************************************************************">>$home/filesystems_$server
lsblk >>$home/filesystems_$server
(echo -e "********************************DISCOS**************************** \n";fdisk -l; echo -e "******************************VOLUMENES FISICOS********************* \n"; pvs; echo -e "*****************************GRUPO VOLUMENES************************* \n"; vgs; echo -e "******************************VOLUMENES LOGICOS******************************** \n"; lvs) > $home/lvminfo_$server
(echo -e "********************************IP*********************** \n"; ifconfig -a; echo -e "**************configuracion de ip address*********************** \n"; cat /etc/sysconfig/network-scripts/ifcfg-*) > $home/networkinfo_$server
env > $home/entorno_$server
yum history > $home/yumhist_$server
cp -p /etc/fstab $home/fstab_$server
echo -e "******************Version SO************************"> $home/SO_$server
cat /etc/redhat-release >> $home/SO_$server
echo -e "******************Version Kernel************************">> $home/SO_$server
uname -r >> $home/SO_$server
echo -e "******************iptables************************"> $home/iptables_$server
iptables -L -n -v >> $home/iptables_$server
systemctl status iptables > $home/iptablesstatus_$server
systemctl status firewalld > $home/fwstatus_$server
cp -p /etc/sysconfig/iptables-config $home/iptables_$server
echo -e "******************selinux************************"> $home/selinux_$server
sestatus >> $home/selinux_$server
echo -e "******************symantec************************"> $home/symantec_$server
ps -ef | grep symantec >> $home/symantec_$server
cp -p /etc/profile $home/profile_$server 2>/dev/null
echo -e "******************procesos java************************"> $home/JAVA_$server
ps -ef | grep java >> $home/JAVA_$server
echo -e "******************Version java************************">> $home/JAVA_$server
java -version 2>> $home/JAVA_$server
echo -e "******************HOME java************************">> $home/JAVA_$server
echo  $JAVA_HOME >> $home/JAVA_$server
echo -e "******************verinter************************">> $home/JAVA_$server
