#Script Elaborado por Rodrigo López - UNIX
#Fecha: 04/02/2022
#HOSTNAME
HOSTNAME=$(hostname)
#IP
IP=$(ip -o address | awk '{print $4}' | cut -d/ -f1 | grep -a 10 | grep -v grep)
#CPU
CPU=$(nproc --all)
#MEMORIA
MEMORIA=$(lsmem | grep "Total online memory" | grep -v grep | awk '{print $4}')
#STORAGE
STORAGE=$(lsblk -d | grep G | grep -v grep | awk '{print $4}' | cut -dG -f1 | paste -sd+ | bc)
echo "$HOSTNAME,$IP,$CPU,$MEMORIA,$STORAGE"
