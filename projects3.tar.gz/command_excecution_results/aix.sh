#!/bin/bash
hostname
echo "=========="
lslpp -h bos.rte
#lspv | head -1 | awk '{print $1}' | xargs -i lspath -l {}
#echo "=========="
#oslevel -s
#echo "=========="
#df -gt
#echo "=========="
#ifconfig -a
