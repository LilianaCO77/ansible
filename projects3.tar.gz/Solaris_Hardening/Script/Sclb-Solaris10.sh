####################################################
# Scritp de control de linea base para solaris 10
# CREADO POR: 		ALEXANDER GONZALEZ
# AUTORIZADO POR: 	NELSON PORRAS
####################################################
clear
# --------------------------------------
# VARIABLES LOCALES
# --------------------------------------
dateTime=` date "+%Y-%m-%d %H:%M:%S" `
oDate=` date "+%Y-%m-%d" `
oMonth=` date "+%m%Y" `
constPathTmp=/tmp
constPathClb=$constPathTmp/ClbUnix/solaris10
#constPathClb=$constPathTmp
constServer=` hostname `
constVersion="Solaris 10"

constHeader="Fecha|Server|Version|Item|Item_Standar|Criticidad|Detalle|Valor_Esperado|Valor_Encontrado|Cumplimiento|Observaciones"

varValEsp=""
varValEnc=""
varCumplimiento=""
varItem=""
varItemStandard=""
varItemReg=""
varCriticidad=""
varAuditLog=""
varObservaciones=""

# --------------------------------------
# MAIN: SHELL PRINCIPAL
# --------------------------------------
echo 
echo [INICIO PROCESO] - $dateTime 
echo 

if (test -d  $constPathClb ); then
	echo 
	echo 	[*] Ruta encontrada  $constPathClb
	echo 
else
	echo 
	echo 	!Error! Ruta no encontrada $constPathClb
	echo	[*] Creando la ruta $constPathClb
	mkdir -p /tmp/ClbUnix/solaris10
	echo 	[*] La ruta ha sido creada correctamente $constPathClb
	echo 	
fi

echo $constHeader
echo $constHeader > $constPathClb/CLB_$constServer.$oMonth.csv
	
echo "Fecha_Hora|Servidor|Item|Valor_Encontrado" > $constPathClb/LOG_$constServer.$oMonth.log
#------------------------------------------
# [INICIO] ÍTEM 0.0.0
	varItem="0.0"
	varItemStandard="0.0.0"		
	varCriticidad="Alto"
	varDetalle="ITEM $varItem Validar que se encuentre instalado el antivirus sophos"
	varValEsp="Sophos Anti-Virus is active"
	if ( test -d "/opt/sophos-av" ); then	
		varValEnc=`/opt/sophos-av/bin/savdstatus` 
		if (test "$varValEsp" = "$varValEnc" ) ; then	
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"						
		else
			if ( test "$varValEnc" = "" ); then 
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				varValEnc="not configured"	
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
			fi
		fi	
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varValEnc="No se encontro la ruta /opt/sophos-av"
	fi	
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 0.0.0	
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.1.1
	varItem="1.1"
	varItemStandard="1.1.1"		
	varCriticidad="Alto"
	varPath=/var/share/cores
	varDetalle="ITEM $varItem Restringir Core Dumps para proteger el directorio $varPath"
	varValEsp="global core file content: default, init core file pattern: core, init core file content: default,"
	varValEsp="$varValEsp global core dumps: enabled, per-process core dumps: disabled, global setid core dumps: enabled,"
	varValEsp="$varValEsp per-process setid core dumps: disabled, global core dump logging: enabled"
	varCumplimiento="Cumple"
	varObservaciones="Ninguna"
	varAyuda=""
	varParm="global core file content"
	varValEnc=` coreadm | grep "$varParm" | awk '{print $NF}' `	
	if ( test "varValEnc" != "default" ) ; then
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
	fi
	varAyuda="$varAyuda $varParm: $varValEnc,"
	varParm="init core file pattern"
	varValEnc=` coreadm | grep "$varParm" | awk '{print $NF}' `		
	if ( test "$varValEnc" != "core" ) ; then
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
	fi
	varAyuda="$varAyuda $varParm: $varValEnc,"
	varParm="init core file content"
	varValEnc=` coreadm | grep "$varParm" | awk '{print $NF}' `		
	if ( test "$varValEnc" != "default" ) ; then
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
	fi	
	varAyuda="$varAyuda $varParm: $varValEnc,"
	varParm="global core dumps"
	varValEnc=` coreadm | grep "$varParm" | awk '{print $NF}' `		
	if ( test "$varValEnc" != "enabled" ) ; then
		varCumplimiento="No Cumple"
		varObservaciones="Error"
	fi	
	varAyuda="$varAyuda $varParm: $varValEnc,"
	varParm="per-process core dumps"
	varValEnc=` coreadm | grep "$varParm" | awk '{print $NF}' `		
	if ( test "$varValEnc" != "disabled" ) ; then
		varCumplimiento="No Cumple"
		varObservaciones="Error"		
	fi	
	varAyuda="$varAyuda $varParm: $varValEnc,"
	varParm="global setid core dumps"
	varValEnc=` coreadm | grep "$varParm" | awk '{print $NF}' `		
	if ( test "$varValEnc" != "enabled" ) ; then
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
	fi	
	varAyuda="$varAyuda $varParm: $varValEnc,"
	varParm="per-process setid core dumps"
	varValEnc=` coreadm | grep "$varParm" | awk '{print $NF}' `		
	if ( test "$varValEnc" != "disabled" ) ; then
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
	fi	
	varAyuda="$varAyuda $varParm: $varValEnc,"
	varParm="global core dump logging"
	varValEnc=` coreadm | grep "$varParm" | awk '{print $NF}' `		
	if ( test "$varValEnc" != "enabled" ) ; then
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
	fi	
	varAyuda="$varAyuda $varParm: $varValEnc"
	varValEnc="$varAyuda"
	
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.1.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.1.2
	varItem="1.1"
	varItemStandard="1.1.2"		
	varCriticidad="Alto"
	varPath=/var/cores
	varValEsp="drwx------ root sys"
	varDetalle="ITEM $varItem Restringir Core Dumps validar los permisos $varPath"
	varValEnc=` ls -ld /var/cores | awk '{print $1, $3, $4}' `	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.1.2
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.2.1
	varItem="1.2"
	varItemStandard="1.2.1"		
	varCriticidad="Alto"
	varPath=/etc/system
	varValEsp="setnoexec_user_stack=1"
	varParm="noexec_user_stack"
	varDetalle="ITEM $varItemStandard Habilitar la proteccion de la pila $varPath"
	varValEnc=` grep "noexec_user_stack" "/etc/system" | tr -d " "| awk -F"=" '{print $1,"=", $2}' | tr -d " " | grep "noexec_user_stack=" | tail -1`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.2.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.2.2
	varItem="1.2"
	varItemStandard="1.2.2"		
	varCriticidad="Alto"
	varPath=/etc/system
	varValEsp="setnoexec_user_stack_log=1"
	varParm="noexec_user_stack_log"
	varDetalle="ITEM $varItemStandard Habilitar la proteccion de la pila $varPath"
	varValEnc=` grep "noexec_user_stack_log" "/etc/system" | tr -d " "| awk -F"=" '{print $1,"=", $2}' | tr -d " " | tail -1`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.2.2
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.3
	varItem="1.3"
	varItemStandard="1.3.1"		
	varCriticidad="Alto"
	varPath=""
	varValEsp=""
	varParm=""
	varDetalle="ITEM $varItemStandard actualizacion de paquetes"
	varValEnc=``	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Validacion manual"	
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.3.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.4
	varItem="1.4"
	varItemStandard="1.4.1"		
	varCriticidad="Alto"
	varPath="ssh"
	varValEsp="online"
	varParm=""
	varDetalle="ITEM $varItemStandard Validar el estado de los servicio $varPath"
	varValEnc=` svcs -Ho state svc:/network/ssh`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.4.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.4
	varItem="1.4"
	varItemStandard="1.4.2"		
	varCriticidad="Alto"
	varPath="ftp"
	varValEsp="disabled"
	varParm=""
	varDetalle="ITEM $varItemStandard Validar el estado de los servicio $varPath"
	varValEnc=` svcs -Ho state svc:/network/ftp`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		if ( test "$varValEnc" = "" ) ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="No Installed"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.4.2
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.4.3
	varItem="1.4"
	varItemStandard="1.4.3"		
	varCriticidad="Alto"
	varPath="telnet"
	varValEsp="disabled"
	varParm=""
	varDetalle="ITEM $varItemStandard Validar el estado de los servicio $varPath"
	varValEnc=` svcs -Ho state svc:/network/telnet`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		if ( test "$varValEnc" = "" ) ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="No Installed"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.4.3
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.4.4
	varItem="1.4"
	varItemStandard="1.4.4"		
	varCriticidad="Alto"
	varPath="rpc keyserv"
	varValEsp="disabled"
	varParm=""
	varDetalle="ITEM $varItemStandard Validar el estado de los servicio $varPath"
	varValEnc=` svcs -Ho state svc:/network/rpc/keyserv`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		if ( test "$varValEnc" = "" ) ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="No Installed"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.4.4
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.4.5
	varItem="1.4"
	varItemStandard="1.4.5"		
	varCriticidad="Alto"
	varPath="nis server"
	varValEsp="disabled"
	varParm=""
	varDetalle="ITEM $varItemStandard Validar el estado de los servicio $varPath"
	varValEnc=` svcs -Ho state svc:/network/nis/server`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		if ( test "$varValEnc" = "" ) ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="No Installed"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.4.5
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.4.6
	varItem="1.4"
	varItemStandard="1.4.6"		
	varCriticidad="Alto"
	varPath="nis client"
	varValEsp="disabled"
	varParm=""
	varDetalle="ITEM $varItemStandard Validar el estado de los servicio $varPath"
	varValEnc=` svcs -Ho state svc:/network/nis/client`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		if ( test "$varValEnc" = "" ) ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="No Installed"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.4.6
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.4.7
	varItem="1.4"
	varItemStandard="1.4.7"		
	varCriticidad="Alto"
	varPath="rpc gss"
	varValEsp="disabled"
	varParm=""
	varDetalle="ITEM $varItemStandard Validar el estado de los servicio $varPath"
	varValEnc=` svcs -Ho state svc:/network/rpc/gss`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		if ( test "$varValEnc" = "" ) ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="No Installed"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.4.7
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.4.8
	varItem="1.4"
	varItemStandard="1.4.8"		
	varCriticidad="Alto"
	varPath="security ktkt_warn"
	varValEsp="disabled"
	varParm=""
	varDetalle="ITEM $varItemStandard Validar el estado de los servicio $varPath"
	varValEnc=` svcs -Ho state svc:/network/security/ktkt_warn`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		if ( test "$varValEnc" = "" ) ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="No Installed"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.4.8
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.4.9
	varItem="1.4"
	varItemStandard="1.4.9"		
	varCriticidad="Alto"
	varPath="filesystem rmvolmgr"
	varValEsp="disabled"
	varParm=""
	varDetalle="ITEM $varItemStandard Validar el estado de los servicio $varPath"
	varValEnc=` svcs -Ho state svc:/system/filesystem/rmvolmgr`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		if ( test "$varValEnc" = "" ) ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="No Installed"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.4.9
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.4.10
	varItem="1.4"
	varItemStandard="1.4.10"		
	varCriticidad="Alto"
	varPath="rpc smserver"
	varValEsp="disabled"
	varParm=""
	varDetalle="ITEM $varItemStandard Validar el estado de los servicio $varPath"
	varValEnc=` svcs -Ho state svc:/network/rpc/smserver`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		if ( test "$varValEnc" = "" ) ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="No Installed"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.4.10
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.4.11
	varItem="1.4"
	varItemStandard="1.4.11"		
	varCriticidad="Alto"
	varPath="filesystem autofs"
	varValEsp="disabled"
	varParm=""
	varDetalle="ITEM $varItemStandard Validar el estado de los servicio $varPath"
	varValEnc=` svcs -Ho state svc:/system/filesystem/autofs`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		if ( test "$varValEnc" = "" ) ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="No Installed"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.4.11
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.4.12
	varItem="1.4"
	varItemStandard="1.4.12"		
	varCriticidad="Alto"
	varPath="http:apache22"
	varValEsp="disabled"
	varParm=""
	varDetalle="ITEM $varItemStandard Validar el estado de los servicio $varPath"
	varValEnc=` svcs -Ho state svc:/network/http:apache22`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		if ( test "$varValEnc" = "" ) ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="No Installed"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.4.12
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.5.1
	varItem="1.5"
	varItemStandard="1.5.1"		
	varCriticidad="Alto"
	varPath="PermitRootLogin"
	varValEsp="PermitRootLogin No"
	varParm=""
	varDetalle="ITEM $varItemStandard Configuraciones seguras para ssh $varPath"
	varValEnc=` cat /etc/ssh/sshd_config | grep PermitRootLogin | tail -1 | awk '{print $1, $2}'`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.5.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.5.2
	varItem="1.5"
	varItemStandard="1.5.2"		
	varCriticidad="Alto"
	varPath="Port"
	varValEsp="Port 534"
	varParm=""
	varDetalle="ITEM $varItemStandard Configuraciones seguras para ssh $varPath"
	varValEnc=` cat /etc/ssh/sshd_config | grep "^Port" | tail -1 | awk '{print $1, $2}'`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else	
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi	
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.5.2
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.5.3
	varItem="1.5"
	varItemStandard="1.5.3"		
	varCriticidad="Alto"
	varPath="Protocol"
	varValEsp="Protocol 2"
	varParm=""
	varDetalle="ITEM $varItemStandard Configuraciones seguras para ssh $varPath"
	varValEnc=` cat /etc/ssh/sshd_config | grep "^Protocol" | tail -1 | awk '{print $1, $2}'`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.5.3
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.5.4
	varItem="1.5"
	varItemStandard="1.5.4"		
	varCriticidad="Alto"
	varPath="LoginGraceTime"
	varValEsp="LoginGraceTime 30"
	varParm=""
	varDetalle="ITEM $varItemStandard Configuraciones seguras para ssh $varPath"
	varValEnc=` cat /etc/ssh/sshd_config | grep LoginGraceTime | tail -1 | awk '{print $1, $2}'`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.5.4
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.5.5
	varItem="1.5"
	varItemStandard="1.5.5"		
	varCriticidad="Alto"
	varPath="MaxAuthTries"
	varValEsp="MaxAuthTries 2"
	varParm=""
	varDetalle="ITEM $varItemStandard Configuraciones seguras para ssh $varPath"
	varValEnc=` cat /etc/ssh/sshd_config | grep "MaxAuthTries" | awk '$1=="MaxAuthTries" {print $1, $2}'`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.5.5
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.5.6
	varItem="1.5"
	varItemStandard="1.5.6"		
	varCriticidad="Alto"
	varPath="MaxStartups"
	varValEsp="MaxStartups 1"
	varParm=""
	varDetalle="ITEM $varItemStandard Configuraciones seguras para ssh $varPath"
	varValEnc=` cat /etc/ssh/sshd_config | grep MaxStartups | tail -1 | awk '{print $1, $2}'`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.5.6
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.5.7
	varItem="1.5"
	varItemStandard="1.5.7"		
	varCriticidad="Alto"
	varPath="AllowUsers"
	varValEsp="AllowUsers"
	varParm=""
	varDetalle="ITEM $varItemStandard Configuraciones seguras para ssh $varPath"
	varValEnc="Does not apply"
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Logging for cyberarck"
	else
		#varCumplimiento="No Cumple"	
		varCumplimiento="Cumple"	
		#varObservaciones="Error"
		varObservaciones="Logging for cyberarck"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.5.7
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.5.8
	varItem="1.5"
	varItemStandard="1.5.8"		
	varCriticidad="Alto"
	varPath="DenyUsers"
	varValEsp="DenyUsers"
	varParm=""
	varDetalle="ITEM $varItemStandard Configuraciones seguras para ssh $varPath"
	varValEnc="Does not apply"
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Logging for cyberarck"
	else
		#varCumplimiento="No Cumple"	
		varCumplimiento="Cumple"	
		#varObservaciones="Error"
		varObservaciones="Logging for cyberarck"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.5.8
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.5.9
	varItem="1.5"
	varItemStandard="1.5.9"		
	varCriticidad="Alto"
	varPath="HostbasedAuthentication"
	varValEsp="HostbasedAuthentication no"
	varParm=""
	varDetalle="ITEM $varItemStandard Configuraciones seguras para ssh $varPath"
	varValEnc=` cat /etc/ssh/sshd_config | grep HostbasedAuthentication | tail -1 | awk '{print $1, $2}'`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.5.9
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.5.10
	varItem="1.5"
	varItemStandard="1.5.10"		
	varCriticidad="Alto"
	varPath="StrictModes"
	varValEsp="StrictModes yes"
	varParm=""
	varDetalle="ITEM $varItemStandard Configuraciones seguras para ssh $varPath"
	varValEnc=` cat /etc/ssh/sshd_config | grep "^StrictModes" | tail -1 | awk '{print $1, $2}'`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.5.10
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.5.11
	varItem="1.5"
	varItemStandard="1.5.11"		
	varCriticidad="Alto"
	varPath="PermitEmptyPasswords"
	varValEsp="PermitEmptyPasswords no"
	varParm=""
	varDetalle="ITEM $varItemStandard Configuraciones seguras para ssh $varPath"
	varValEnc=` cat /etc/ssh/sshd_config | grep "^PermitEmptyPasswords" | tail -1 | awk '{print $1, $2}'`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.5.11
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.5.12
	varItem="1.5"
	varItemStandard="1.5.12"		
	varCriticidad="Alto"
	varPath="PasswordAuthentication"
	varValEsp="PasswordAuthentication yes"
	varParm=""
	varDetalle="ITEM $varItemStandard Configuraciones seguras para ssh $varPath"
	varValEnc=` cat /etc/ssh/sshd_config | grep "^PasswordAuthentication" | tail -1 | awk '{print $1, $2}'`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.5.12
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.6.1
	varItem="1.6"
	varItemStandard="1.6.1"		
	varCriticidad="Alto"
	varPath="/etc/motd"
	varValEsp="Banner"
	varParm=""
	varDetalle="ITEM $varItemStandard Establecer mensajes de seguridad con archivos banner $varPath"
	varValEnc=`cat /etc/issue | wc -l`	
	if ( test $varValEnc -eq 0 ) ; then
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.6.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.7.1
	varItem="1.7"
	varItemStandard="1.7.1"		
	varCriticidad="Alto"
	varPath="console-login:terma"
	varValEsp="disabled"
	varParm=""
	varDetalle="ITEM $varItemStandard Restriccion de Puertos Seriales $varPath"
	varValEnc=` svcs -Ho state svc:/system/console-login:terma`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		if ( test "$varValEnc" = "" ) ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="No Installed"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.7.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.7.2
	varItem="1.7"
	varItemStandard="1.7.2"		
	varCriticidad="Alto"
	varPath="console-login:termb"
	varValEsp="disabled"
	varParm=""
	varDetalle="ITEM $varItemStandard Restriccion de puertos Seriales $varPath"
	varValEnc=` svcs -Ho state svc:/system/console-login:termb`	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"	
	else
		if ( test "$varValEnc" = "" ) ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="No Installed"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.7.2
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.8.1
	varItem="1.8"
	varItemStandard="1.8.1"		
	varCriticidad="Alto"
	varPath="/etc/cron.d/cron.deny"
	varValEsp="Empty"
	varParm=""
	varDetalle="ITEM $varItemStandard Proteccion del cron, que no este ningun id registrado $varPath"
	varValEnc=` cat /etc/cron.d/cron.deny | wc -l`	
	if ( test $varValEnc = 0 ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		varValEnc="Empty"		
	else
		if ( test "$varValEnc" = "" ) ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="Empty"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
			if ( test "$varValEnc" = "" ); then 
				varValEnc="S/D"	
			fi
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.8.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.8.2
	varItem="1.8"
	varItemStandard="1.8.2"		
	varCriticidad="Alto"
	varPath="/etc/cron.d/cron.allow"
	varValEsp="root"
	varParm=""
	varDetalle="ITEM $varItemStandard Proteccion del cron, cron.allow solo este registrado el usuario root $varPath"
	varValEnc=`cat /etc/cron.d/cron.allow | grep "^root"`	
	if ( test "$varValEsp" = "$varValEnc" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.8.2
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.9.1
	varItem="1.9"
	varItemStandard="1.9.1"		
	varCriticidad="Alto"
	varPath="/etc/rc2.d"
	varValEsp="Services"
	varParm=""
	varDetalle="ITEM $varItemStandard Validar que los servicios en la ruta  $varPath inicien con la letra K"
	varValEnc=` ls  /etc/rc2.d | grep K | tr -s "\n" " "`	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="No Cumple"	
		varObservaciones="Error"	
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.9.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.9.2
	varItem="1.9"
	varItemStandard="1.9.2"		
	varCriticidad="Alto"
	varPath="/etc/rc3.d"
	varValEsp="Services"
	varParm=""
	varDetalle="ITEM $varItemStandard Validar que los servicios en la ruta  $varPath inicien con la letra K"
	varValEnc=` ls  /etc/rc3.d | grep K | tr -s "\n" " "`	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="No Cumple"	
		varObservaciones="Error"	
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi	
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.9.2
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.10.1
	varItem="1.10"
	varItemStandard="1.10.1"		
	varCriticidad="Alto"
	varPath="/etc/inet/ntp.conf"
	varValEsp="server"
	varDetalle="ITEM $varItemStandard configurar el servidor NTP  $varPath"
	varValEnc=`cat /etc/inet/ntp.conf | grep "^server" | awk '{print $2}'`	
	varSrvNtp="ecuio012d04 ecuio012d02 ecbpprd11 10.0.0.163 10.151.1.125 ECUIO012D04 ECUIO012D02 ECBPPRD11"
	varFlag="False"
	if ( test -f "/etc/inet/ntp.conf" ); then
		if	( test "$varValEnc" = "`echo $varSrvNtp | awk '{print $1}'`" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
			varFlag="True"
		fi
		if	( test "$varValEnc" = "`echo $varSrvNtp | awk '{print $2}'`" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
			varFlag="True"
		fi
		if	( test "$varValEnc" = "`echo $varSrvNtp | awk '{print $3}'`" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
			varFlag="True"
		fi
		
		if	( test "$varValEnc" = "`echo $varSrvNtp | awk '{print $4}'`" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
			varFlag="True"
		fi
		if	( test "$varValEnc" = "`echo $varSrvNtp | awk '{print $5}'`" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
			varFlag="True"
		fi
		if	( test "$varValEnc" = "`echo $varSrvNtp | awk '{print $6}'`" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
			varFlag="True"
		fi
		if	( test "$varValEnc" = "`echo $varSrvNtp | awk '{print $7}'`" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
			varFlag="True"
		fi
		if	( test "$varValEnc" = "`echo $varSrvNtp | awk '{print $8}'`" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
			varFlag="True"
		fi
		if	( test "$varFlag" = "False" ) ; then
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
			varValEnc="Not configurated"
		fi
		echo $varValEnc
	else
		varCumplimiento="No Cumple"	
		varValEnc="Not exists file"
		varObservaciones="Error"
	fi	

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.10.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.11.1
	varItem="1.11"
	varItemStandard="1.11.1"		
	varCriticidad="Alto"
	varPath="/etc/rc3.d"
	varValEsp="K76snmpdx"
	varParm=""
	varDetalle="ITEM $varItemStandard Validar que el servicio 76snmpdx inicie con la letra K $varPath"
	varValEnc=`ls /etc/rc3.d | grep "76snmpdx" `	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
		varValEnc="No Installed"
	else
		if	( test "$varValEnc" = "$varValEsp" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
			if ( test "$varValEnc" = "" ); then 
				varValEnc="S/D"	
			fi				
		fi			
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.11.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.12.1
	varItem="1.12"
	varItemStandard="1.12.1"		
	varCriticidad="Alto"
	varPath=""
	varValEsp="security-#badlogins=0"
	varParm=""
	varDetalle="ITEM $varItemStandard Proteccion de EEPROM $varPath"
	varValEnc=` eeprom security-#badlogins `	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.12.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.13.1
	varItem="1.13"
	varItemStandard="1.13.1"		
	varCriticidad="Alto"
	varPath=""
	varValEsp="-rw-r--r-- root root"
	varParm=""
	varDetalle="ITEM $varItemStandard Permisos sobre el fichero /etc/profile $varPath"
	varValEnc=` ls -l /etc/profile | awk '{print $1, $3, $4}' `	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.13.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.14.1
	varItem="1.14"
	varItemStandard="1.14.1"		
	varCriticidad="Alto"
	varPath=""
	varValEsp="Pendiente"
	varParm=""
	varDetalle="ITEM $varItemStandard Configuracion del hostname del equipos $varPath"
	varValEnc="Pendiente"	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna --- Pendiente Revision standard"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.14.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.15.1
	varItem="1.15"
	varItemStandard="1.15.1"		
	varCriticidad="Alto"
	varPath="/etc/ssh/sshd_config"
	varValEsp="Banner /etc/issue"
	varParm=""
	varDetalle="ITEM $varItemStandard Desplegar un mensaje de seguridad a usuarios SSH $varPath"
	varValEnc=`cat /etc/ssh/sshd_config | grep "^Banner" `	
	if ( test "$varValEnc" = "$varValEsp" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="S/D"	
		fi		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.15.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.16.1
	varItem="1.16"
	varItemStandard="1.16.1"		
	varCriticidad="Alto"
	varPath="ipadm show-prop -p _forward_src_routed -co current ipv4"
	varValEsp="0"
	varParm=""
	varDetalle="ITEM $varItemStandard Deshabilitar reenvios de paqueste desde el origen  $varPath"
	if ( test "$constVersion" = "Solaris 10"); then 
		varCumplimiento="Cumple"	
		varObservaciones="Only SunOS 11"
		varValEnc="Does not apply"
	else
		varValEnc=`ipadm show-prop -p _forward_src_routed -co current ipv4`	
		if ( test "$varValEnc" = "$varValEsp" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if ( test "$varValEnc" = "" ); then 
				varValEnc="S/D"	
			fi		
		fi
	fi	
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.16.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.16.2
	varItem="1.16"
	varItemStandard="1.16.2"		
	varCriticidad="Alto"
	varPath="ipadm show-prop -p _forward_src_routed -co persistent ipv4"
	varValEsp="0"
	varParm=""
	varDetalle="ITEM $varItemStandard Deshabilitar reenvios de paqueste desde el origen  $varPath"
	if ( test "$constVersion" = "Solaris 10"); then 
		varCumplimiento="Cumple"	
		varObservaciones="Only SunOS 11"
		varValEnc="Does not apply"
	else
		varValEnc=`ipadm show-prop -p _forward_src_routed -co persistent ipv4`	
		if ( test "$varValEnc" = "$varValEsp" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if ( test "$varValEnc" = "" ); then 
				varValEnc="S/D"	
			fi		
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.16.2
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.16.3
	varItem="1.16"
	varItemStandard="1.16.3"		
	varCriticidad="Alto"
	varPath="ipadm show-prop -p _forward_src_routed -co current ipv6"
	varValEsp="0"
	varParm=""
	varDetalle="ITEM $varItemStandard Deshabilitar reenvios de paqueste desde el origen  $varPath"
	if ( test "$constVersion" = "Solaris 10"); then 
		varCumplimiento="Cumple"	
		varObservaciones="Only SunOS 11"
		varValEnc="Does not apply"
	else
		varValEnc=`ipadm show-prop -p _forward_src_routed -co current ipv6`	
		if ( test "$varValEnc" = "$varValEsp" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if ( test "$varValEnc" = "" ); then 
				varValEnc="S/D"	
			fi		
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.16.3
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.16.4
	varItem="1.16"
	varItemStandard="1.16.4"		
	varCriticidad="Alto"
	varPath="ipadm show-prop -p _forward_src_routed -co persistent ipv6"
	varValEsp="0"
	varParm=""
	varDetalle="ITEM $varItemStandard Deshabilitar reenvios de paqueste desde el origen  $varPath"
	if ( test "$constVersion" = "Solaris 10"); then 
		varCumplimiento="Cumple"	
		varObservaciones="Only SunOS 11"
		varValEnc="Does not apply"
	else
		varValEnc=`ipadm show-prop -p _forward_src_routed -co persistent ipv6`	
		if ( test "$varValEnc" = "$varValEsp" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if ( test "$varValEnc" = "" ); then 
				varValEnc="S/D"	
			fi		
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.16.4
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.17.1
	varItem="1.17"
	varItemStandard="1.17.1"		
	varCriticidad="Alto"
	varPath="ipadm show-prop -p _forward_directed_broadcasts ip"
	varValEsp="CURRENT 0"
	varParm=""
	varDetalle="ITEM $varItemStandard Deshabilitar reenvio de Paquetes Broadcast $varPath"
	if ( test "$constVersion" = "Solaris 10"); then 
		varCumplimiento="Cumple"	
		varObservaciones="Only SunOS 11"
		varValEnc="Does not apply"
	else
		varValUno=`ipadm show-prop -p _forward_directed_broadcasts ip | awk '{print $4 }' | head -1`
		varValDos=`ipadm show-prop -p _forward_directed_broadcasts ip | awk '{print $4 }' | tail -1`
		varValEnc="$varValUno $varValDos"	
		if ( test "$varValEnc" = "$varValEsp" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if ( test "$varValEnc" = "" ); then 
				varValEnc="S/D"	
			fi		
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.17.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.18.1
	varItem="1.18"
	varItemStandard="1.18.1"		
	varCriticidad="Alto"
	varPath="ipadm show-prop -p _respond_to_timestamp_broadcast -co current ip"
	varValEsp="0"
	varParm=""
	varDetalle="ITEM $varItemStandard Deshabilitar respuestas de solicitudes ICMP Broadcast Timestamp $varPath"
	if ( test "$constVersion" = "Solaris 10"); then 
		varCumplimiento="Cumple"	
		varObservaciones="Only SunOS 11"
		varValEnc="Does not apply"
	else
		varValEnc=`ipadm show-prop -p _respond_to_timestamp_broadcast -co current ip`
		if ( test "$varValEnc" = "$varValEsp" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if ( test "$varValEnc" = "" ); then 
				varValEnc="S/D"	
			fi		
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.18.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.18.2
	varItem="1.18"
	varItemStandard="1.18.2"		
	varCriticidad="Alto"
	varPath="ipadm show-prop -p _respond_to_timestamp -co persistent ip"
	varValEsp="0"
	varParm=""
	varDetalle="ITEM $varItemStandard Deshabilitar respuestas de solicitudes ICMP Broadcast Timestamp $varPath"
	if ( test "$constVersion" = "Solaris 10"); then 
		varCumplimiento="Cumple"	
		varObservaciones="Only SunOS 11"
		varValEnc="Does not apply"
	else
		varValEnc=`ipadm show-prop -p _respond_to_timestamp -co persistent ip`
		if ( test "$varValEnc" = "$varValEsp" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if ( test "$varValEnc" = "" ); then 
				varValEnc="S/D"	
			fi		
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.18.2
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.19.1
	varItem="1.19"
	varItemStandard="1.19.1"		
	varCriticidad="Alto"
	varPath="ipadm show-prop -p _respond_to_timestamp_broadcast -co current ip"
	varValEsp="0"
	varParm=""
	varDetalle="ITEM $varItemStandard Deshabilitar respuestas de solicitudes ICMP Broadcast Timestamp $varPath"
	if ( test "$constVersion" = "Solaris 10"); then 
		varCumplimiento="Cumple"	
		varObservaciones="Only SunOS 11"
		varValEnc="Does not apply"
	else
		varValEnc=`ipadm show-prop -p _respond_to_timestamp_broadcast -co current ip`
		if ( test "$varValEnc" = "$varValEsp" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if ( test "$varValEnc" = "" ); then 
				varValEnc="S/D"	
			fi		
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.19.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.19.2
	varItem="1.19"
	varItemStandard="1.19.2"		
	varCriticidad="Alto"
	varPath="ipadm show-prop -p _respond_to_timestamp_broadcast -co persistent ip"
	varValEsp="0"
	varParm=""
	varDetalle="ITEM $varItemStandard Deshabilitar respuestas de solicitudes ICMP Broadcast Timestamp $varPath"
	if ( test "$constVersion" = "Solaris 10"); then 
		varCumplimiento="Cumple"	
		varObservaciones="Only SunOS 11"
		varValEnc="Does not apply"
	else
		varValEnc=`ipadm show-prop -p _respond_to_timestamp_broadcast -co persistent ip`
		if ( test "$varValEnc" = "$varValEsp" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if ( test "$varValEnc" = "" ); then 
				varValEnc="S/D"	
			fi		
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.19.2
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.20.1
	varItem="1.20"
	varItemStandard="1.20.1"		
	varCriticidad="Alto"
	varPath="ipadm show-prop -p _respond_to_address_mask_broadcast -co current ip"
	varValEsp="0"
	varParm=""
	varDetalle="ITEM $varItemStandard Deshabilitar respuestas de solicitudes ICMP Broadcast Netmask $varPath"
	if ( test "$constVersion" = "Solaris 10"); then 
		varCumplimiento="Cumple"	
		varObservaciones="Only SunOS 11"
		varValEnc="Does not apply"
	else
		varValEnc=`ipadm show-prop -p _respond_to_address_mask_broadcast -co current ip`
		if ( test "$varValEnc" = "$varValEsp" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if ( test "$varValEnc" = "" ); then 
				varValEnc="S/D"	
			fi		
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.20.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.20.2
	varItem="1.20"
	varItemStandard="1.20.2"		
	varCriticidad="Alto"
	varPath="ipadm show-prop -p _respond_to_address_mask_broadcast -co persistent ip"
	varValEsp="0"
	varParm=""
	varDetalle="ITEM $varItemStandard Deshabilitar respuestas de solicitudes ICMP Broadcast Netmask $varPath"
	if ( test "$constVersion" = "Solaris 10"); then 
		varCumplimiento="Cumple"	
		varObservaciones="Only SunOS 11"
		varValEnc="Does not apply"
	else
		varValEnc=`ipadm show-prop -p _respond_to_address_mask_broadcast -co persistent ip`
		if ( test "$varValEnc" = "$varValEsp" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if ( test "$varValEnc" = "" ); then 
				varValEnc="S/D"	
			fi		
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.20.2
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.21.1
	varItem="1.21"
	varItemStandard="1.21.1"		
	varCriticidad="Alto"
	varPath="ipadm show-prop -p _respond_to_echo_broadcast ip"
	varValEsp="CURRENT 0"
	varParm=""
	varDetalle="ITEM $varItemStandard Deshabilitar respuestas a Echo Request $varPath"
	if ( test "$constVersion" = "Solaris 10"); then 
		varCumplimiento="Cumple"	
		varObservaciones="Only SunOS 11"
		varValEnc="Does not apply"
	else
		varValUno=`ipadm show-prop -p _respond_to_echo_broadcast ip | awk '{print $4 }' | head -1`
		varValDos=`ipadm show-prop -p _respond_to_echo_broadcast ip | awk '{print $4 }' | tail -1`
		varValEnc="$varValUno $varValDos"	
		if ( test "$varValEnc" = "$varValEsp" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if ( test "$varValEnc" = "" ); then 
				varValEnc="S/D"	
			fi		
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.21.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.21.2
	varItem="1.21"
	varItemStandard="1.21.2"		
	varCriticidad="Alto"
	varPath="ipadm show-prop -p _respond_to_echo_multicast ipv4"
	varValEsp="CURRENT 0"
	varParm=""
	varDetalle="ITEM $varItemStandard Deshabilitar respuestas a Echo Request $varPath"
	if ( test "$constVersion" = "Solaris 10"); then 
		varCumplimiento="Cumple"	
		varObservaciones="Only SunOS 11"
		varValEnc="Does not apply"
	else
		varValUno=`ipadm show-prop -p _respond_to_echo_multicast ipv4 | awk '{print $4 }' | head -1`
		varValDos=`ipadm show-prop -p _respond_to_echo_multicast ipv4 | awk '{print $4 }' | tail -1`
		varValEnc="$varValUno $varValDos"	
		if ( test "$varValEnc" = "$varValEsp" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if ( test "$varValEnc" = "" ); then 
				varValEnc="S/D"	
			fi		
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.21.2
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.21.3
	varItem="1.21"
	varItemStandard="1.21.3"		
	varCriticidad="Alto"
	varPath="ipadm show-prop -p _respond_to_echo_multicast ipv6"
	varValEsp="CURRENT 0"
	varParm=""
	varDetalle="ITEM $varItemStandard Deshabilitar respuestas a Echo Request $varPath"
	if ( test "$constVersion" = "Solaris 10"); then 
		varCumplimiento="Cumple"	
		varObservaciones="Only SunOS 11"
		varValEnc="Does not apply"
	else
		varValUno=`ipadm show-prop -p _respond_to_echo_multicast ipv6 | awk '{print $4 }' | head -1`
		varValDos=`ipadm show-prop -p _respond_to_echo_multicast ipv6 | awk '{print $4 }' | tail -1`
		varValEnc="$varValUno $varValDos"	
		if ( test "$varValEnc" = "$varValEsp" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if ( test "$varValEnc" = "" ); then 
				varValEnc="S/D"	
			fi		
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.21.3
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.22.1
	varItem="1.22"
	varItemStandard="1.22.1"		
	varCriticidad="Alto"
	varPath="ipadm show-prop -p _strict_dst_multihoming -co current ipv4"
	varValEsp="1"
	varParm=""
	varDetalle="ITEM $varItemStandard Establecer estricto multihoming $varPath"
	if ( test "$constVersion" = "Solaris 10"); then 
		varCumplimiento="Cumple"	
		varObservaciones="Only SunOS 11"
		varValEnc="Does not apply"
	else
		varValEnc=`ipadm show-prop -p _strict_dst_multihoming -co current ipv4`
		if ( test "$varValEnc" = "$varValEsp" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if ( test "$varValEnc" = "" ); then 
				varValEnc="S/D"	
			fi		
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.22.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.22.2
	varItem="1.22"
	varItemStandard="1.22.2"		
	varCriticidad="Alto"
	varPath="ipadm show-prop -p _strict_dst_multihoming -co persistent ipv4"
	varValEsp="1"
	varParm=""
	varDetalle="ITEM $varItemStandard Establecer estricto multihoming $varPath"
	if ( test "$constVersion" = "Solaris 10"); then 
		varCumplimiento="Cumple"	
		varObservaciones="Only SunOS 11"
		varValEnc="Does not apply"
	else
		varValEnc=`ipadm show-prop -p _strict_dst_multihoming -co persistent ipv4`
		if ( test "$varValEnc" = "$varValEsp" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if ( test "$varValEnc" = "" ); then 
				varValEnc="S/D"	
			fi		
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.22.2
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.22.3
	varItem="1.22"
	varItemStandard="1.22.3"		
	varCriticidad="Alto"
	varPath="ipadm show-prop -p _strict_dst_multihoming -co current ipv6"
	varValEsp="1"
	varParm=""
	varDetalle="ITEM $varItemStandard Establecer estricto multihoming $varPath"
	if ( test "$constVersion" = "Solaris 10"); then 
		varCumplimiento="Cumple"	
		varObservaciones="Only SunOS 11"
		varValEnc="Does not apply"
	else
		varValEnc=`ipadm show-prop -p _strict_dst_multihoming -co current ipv6`
		if ( test "$varValEnc" = "$varValEsp" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if ( test "$varValEnc" = "" ); then 
				varValEnc="S/D"	
			fi		
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.22.3
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.22.4
	varItem="1.22"
	varItemStandard="1.22.4"		
	varCriticidad="Alto"
	varPath="ipadm show-prop -p _strict_dst_multihoming -co persistent ipv6"
	varValEsp="1"
	varParm=""
	varDetalle="ITEM $varItemStandard Establecer estricto multihoming $varPath"
	if ( test "$constVersion" = "Solaris 10"); then 
		varCumplimiento="Cumple"	
		varObservaciones="Only SunOS 11"
		varValEnc="Does not apply"
	else
		varValEnc=`ipadm show-prop -p _strict_dst_multihoming -co persistent ipv6`
		if ( test "$varValEnc" = "$varValEsp" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if ( test "$varValEnc" = "" ); then 
				varValEnc="S/D"	
			fi		
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.22.4
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 1.23.1
	varItem="1.23"
	varItemStandard="1.23.1"		
	varCriticidad="Alto"
	varPath="ipadm show-prop -p _conn_req_max_q0 tcp"
	varValEsp="CURRENT 4096"
	varParm=""
	varDetalle="ITEM $varItemStandard Fijar el maximo de numero de conexiones TCP incompletas y pendientes $varPath"
	if ( test "$constVersion" = "Solaris 10"); then 
		varCumplimiento="Cumple"	
		varObservaciones="Only SunOS 11"
		varValEnc="Does not apply"
	else
		varValUno=`ipadm show-prop -p _conn_req_max_q0 tcp | awk '{print $4 }' | head -1`
		varValDos=`ipadm show-prop -p _conn_req_max_q0 tcp | awk '{print $4 }' | tail -1`
		varValEnc="$varValUno $varValDos"	
		if ( test "$varValEnc" = "$varValEsp" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if ( test "$varValEnc" = "" ); then 
				varValEnc="S/D"	
			fi		
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.23.1
#------------------------------------------



#------------------------------------------
# [INICIO] 	ÍTEM 1.23.2
	varItem="1.23"
	varItemStandard="1.23.2"		
	varCriticidad="Alto"
	varPath="ipadm show-prop -p _conn_req_max_q tcp"
	varValEsp="CURRENT 1024"
	varParm=""
	varDetalle="ITEM $varItemStandard Fijar el maximo de numero de conexiones TCP incompletas y pendientes $varPath"
	if ( test "$constVersion" = "Solaris 10"); then 
		varCumplimiento="Cumple"	
		varObservaciones="Only SunOS 11"
		varValEnc="Does not apply"
	else
		varValUno=`ipadm show-prop -p _conn_req_max_q tcp | awk '{print $4 }' | head -1`
		varValDos=`ipadm show-prop -p _conn_req_max_q tcp | awk '{print $4 }' | tail -1`
		varValEnc="$varValUno $varValDos"	
		if ( test "$varValEnc" = "$varValEsp" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if ( test "$varValEnc" = "" ); then 
				varValEnc="S/D"	
			fi		
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 1.23.2
#------------------------------------------



#------------------------------------------
# [INICIO] 	ÍTEM 2.1.1
	varItem="2.1"
	varItemStandard="2.1.1"		
	varCriticidad="Alto"
	varPath=""
	varValEsp="root ssi_adm	lib_adm	cent_adm redteam tools gen_adm"
	varParmUno="Existe "
	varParmDos="Falta "
	varFlag=""
	varDetalle="ITEM $varItemStandard Grupos de administracipn $varPath"
	varValEnc=` cat /etc/group | awk -F: '{print $1}' | egrep "root" `	
	if ( test "$varValEnc" = "root" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
		varParmUno="$varParmUno $varValEnc "
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varParmDos="$varParmDos root "	
		varFlag="false"
	fi
	varValEnc=` cat /etc/group | awk -F: '{print $1}' | egrep "ssi_adm" `	
	if ( test "$varValEnc" = "ssi_adm" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
		varParmUno="$varParmUno $varValEnc "
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varParmDos="$varParmDos ssi_adm "
		varFlag="false"
	fi
	varValEnc=` cat /etc/group | awk -F: '{print $1}' | egrep "lib_adm" `	
	if ( test "$varValEnc" = "lib_adm" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
		varParmUno="$varParmUno $varValEnc "
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varParmDos="$varParmDos lib_adm "
		varFlag="false"		
	fi
	varValEnc=` cat /etc/group | awk -F: '{print $1}' | egrep "cent_adm" `	
	if ( test "$varValEnc" = "cent_adm" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
		varParmUno="$varParmUno $varValEnc "
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varParmDos="$varParmDos cent_adm "
		varFlag="false"
	fi
	varValEnc=` cat /etc/group | awk -F: '{print $1}' | egrep "redteam" `	
	if ( test "$varValEnc" = "redteam" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
		varParmUno="$varParmUno $varValEnc "
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varParmDos="$varParmDos redteam "
		varFlag="false"
	fi
	varValEnc=` cat /etc/group | awk -F: '{print $1}' | egrep "tools" `	
	if ( test "$varValEnc" = "tools" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
		varParmUno="$varParmUno $varValEnc "
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varParmDos="$varParmDos tools "	
		varFlag="false"
	fi
	varValEnc=` cat /etc/group | awk -F: '{print $1}' | egrep "gen_adm" `	
	if ( test "$varValEnc" = "gen_adm" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
		varParmUno="$varParmUno $varValEnc "
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varParmDos="$varParmDos gen_adm "
		varFlag="false"
	fi
	
	if (test "$varFlag" = "" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
	fi 
	
	
	
	varValEnc="$varParmUno $varParmDos "
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.1.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.2.1
	varItem="2.2"
	varItemStandard="2.2.1"		
	varCriticidad="Alto"
	varPath=""
	varValEsp="No User"
	varParmUno=""
	varFlag=""
	varParmDos="Se encontro"
	varDetalle="ITEM $varItemStandard Grupos de administracipn $varPath"
	varValEnc=` cat /etc/passwd | awk -F: '{print $1,$NF}' | grep "sh" | grep "^adm" `	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
		varValEsp="No se encontraron usuarios"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varParmDos="$varParmDos adm "
		varFlag="false"
	fi
	varValEnc=`cat /etc/passwd | awk -F: '{print $1,$NF}' | grep "sh" | grep "^bin" `	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
		varValEsp="No se encontraron usuarios"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varParmDos="$varParmDos bin "	
		varFlag="false"		
	fi
	varValEnc=` cat /etc/passwd | awk -F: '{print $1,$NF}' | grep "sh" | grep "^daemon"  `	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
		varValEsp="No se encontraron usuarios"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varParmDos="$varParmDos daemon "
		varFlag="false"		
	fi
	varValEnc=` cat /etc/passwd | awk -F: '{print $1,$NF}' | grep "sh" | grep "^smmsp" `	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
		varValEsp="No se encontraron usuarios"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varParmDos="$varParmDos smmsp "	
		varFlag="false"		
	fi
	varValEnc=` cat /etc/passwd | awk -F: '{print $1,$NF}' | grep "sh" | grep "^listen" `	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
		varValEsp="No se encontraron usuarios"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varParmDos="$varParmDos listen "	
		varFlag="false"		
	fi
	varValEnc=` cat /etc/passwd | awk -F: '{print $1,$NF}' | grep "sh" | grep "^webservd" `	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
		varValEsp="No se encontraron usuarios"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varParmDos="$varParmDos webservd "	
		varFlag="false"		
	fi
	varValEnc=` cat /etc/passwd | awk -F: '{print $1,$NF}' | grep "sh" | grep "^lp" `	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
		varValEsp="No se encontraron usuarios"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varParmDos="$varParmDos lp "
		varFlag="false"		
	fi
	varValEnc=` cat /etc/passwd | awk -F: '{print $1,$NF}' | grep "sh" | grep "^postgres" `	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
		varValEsp="No se encontraron usuarios"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varParmDos="$varParmDos postgres "	
		varFlag="false"		
	fi
	varValEnc=` cat /etc/passwd | awk -F: '{print $1,$NF}' | grep "sh" | grep "^noaccess" `	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
		varValEsp="No se encontraron usuarios"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varParmDos="$varParmDos noaccess "	
		varFlag="false"		
	fi
	varValEnc=` cat /etc/passwd | awk -F: '{print $1,$NF}' | grep "sh" | grep "^nobody" `	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
		varValEsp="No se encontraron usuarios"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varParmDos="$varParmDos nobody "
		varFlag="false"		
	fi
	varValEnc=` cat /etc/passwd | awk -F: '{print $1,$NF}' | grep "sh" | grep "^nuucp" `	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
		varValEsp="No se encontraron usuarios"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varParmDos="$varParmDos nuucp "	
		varFlag="false"		
	fi
	
	varValEnc=` cat /etc/passwd | awk -F: '{print $1,$NF}' | grep "sh" | grep "^svctag" `	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
		varValEsp="No se encontraron usuarios"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varParmDos="$varParmDos svctag "
		varFlag="false"		
	fi
	
	varValEnc=` cat /etc/passwd | awk -F: '{print $1,$NF}' | grep "sh" | grep "^nobody4" `	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
		varValEsp="No se encontraron usuarios"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varParmDos="$varParmDos nobody4 "
		varFlag="false"		
	fi
	varValEnc=` cat /etc/passwd | awk -F: '{print $1,$NF}' | grep "sh" | grep "^sys" `	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
		varValEsp="No se encontraron usuarios"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varParmDos="$varParmDos sys "
		varFlag="false"		
	fi
	varValEnc=` cat /etc/passwd | awk -F: '{print $1,$NF}' | grep "sh" | grep "^uucp" `	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
		varValEsp="No se encontraron usuarios"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varParmDos="$varParmDos uucp "	
		varFlag="false"		
	fi
		
	if (test "$varFlag" = "" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		varValEsp="No se encontraron usuarios"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
	fi 
		
	varValEnc="$varParmUno $varParmDos "
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.2.1
#------------------------------------------



#------------------------------------------
# [INICIO] 	ÍTEM 2.3.1
	varItem="2.3"
	varItemStandard="2.3.1"		
	varCriticidad="Alto"
	varPath="/etc/shadow"
	varValEsp="adm *LK*"
	varParm="adm"
	varDetalle="ITEM $varItemStandard Validar que la cuenta $varParm esta deshabilitada con el *LK* en el campo del usuario"
	varValEnc=`cat /etc/shadow | grep "^adm" | awk -F: '/LK/{print $1, $2}' | tr -d "NP" | tail -1`	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		varValEnc="Not exist"		
	else
		if ( test "$varValEnc" = "$varValEsp" ); then 
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi			
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.3.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.3.2
	varItem="2.3"
	varItemStandard="2.3.2"		
	varCriticidad="Alto"
	varPath="/etc/shadow"
	varValEsp="bin *LK*"
	varParm="bin"
	varDetalle="ITEM $varItemStandard Validar que la cuenta $varParm esta deshabilitada con el *LK* en el campo del usuario"
	varValEnc=` cat /etc/shadow | grep "^bin" | awk -F: '/LK/{print $1, $2}' | tr -d "NP" | tail -1`	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		varValEnc="Not exist"		
	else
		if ( test "$varValEnc" = "$varValEsp" ); then 
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi			
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.3.2
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.3.3
	varItem="2.3"
	varItemStandard="2.3.3"		
	varCriticidad="Alto"
	varPath="/etc/shadow"
	varValEsp="daemon *LK*"
	varParm="daemon"
	varDetalle="ITEM $varItemStandard Validar que la cuenta $varParm esta deshabilitada con el *LK* en el campo del usuario"
	varValEnc=` cat /etc/shadow | grep "^daemon" | awk -F: '/LK/{print $1, $2}' | tr -d "NP" | tail -1`	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		varValEnc="Not exist"		
	else
		if ( test "$varValEnc" = "$varValEsp" ); then 
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi			
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.3.3
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.3.4
	varItem="2.3"
	varItemStandard="2.3.4"		
	varCriticidad="Alto"
	varPath="/etc/shadow"
	varValEsp="smmsp *LK*"
	varParm="smmsp"
	varDetalle="ITEM $varItemStandard Validar que la cuenta $varParm esta deshabilitada con el *LK* en el campo del usuario"
	varValEnc=` cat /etc/shadow | grep "^smmsp" | awk -F: '/LK/{print $1, $2}' | tr -d "NP" | tail -1`	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		varValEnc="Not exist"		
	else
		if ( test "$varValEnc" = "$varValEsp" ); then 
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi			
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.3.4
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.3.5
	varItem="2.3"
	varItemStandard="2.3.5"		
	varCriticidad="Alto"
	varPath="/etc/shadow"
	varValEsp="listen *LK*"
	varParm="listen"
	varDetalle="ITEM $varItemStandard Validar que la cuenta $varParm esta deshabilitada con el *LK* en el campo del usuario"
	varValEnc=` cat /etc/shadow | grep "^listen" | awk -F: '/LK/{print $1, $2}' | tr -d "NP" | tail -1`	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		varValEnc="Not exist"		
	else
		if ( test "$varValEnc" = "$varValEsp" ); then 
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi			
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.3.5
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.3.6
	varItem="2.3"
	varItemStandard="2.3.6"		
	varCriticidad="Alto"
	varPath="/etc/shadow"
	varValEsp="webservd *LK*"
	varParm="webservd"
	varDetalle="ITEM $varItemStandard Validar que la cuenta $varParm esta deshabilitada con el *LK* en el campo del usuario"
	varValEnc=` cat /etc/shadow | grep "^webservd" | awk -F: '/LK/{print $1, $2}' | tr -d "NP" | tail -1 `	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		varValEnc="Not exist"		
	else
		if ( test "$varValEnc" = "$varValEsp" ); then 
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi			
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.3.6
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.3.7
	varItem="2.3"
	varItemStandard="2.3.7"		
	varCriticidad="Alto"
	varPath="/etc/shadow"
	varValEsp="lp *LK*"
	varParm="lp"
	varDetalle="ITEM $varItemStandard Validar que la cuenta $varParm esta deshabilitada con el *LK* en el campo del usuario"
	varValEnc=` cat /etc/shadow | grep "^lp" | awk -F: '/LK/{print $1, $2}' | tr -d "NP" | tail -1 `	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		varValEnc="Not exist"		
	else
		if ( test "$varValEnc" = "$varValEsp" ); then 
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi			
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.3.7
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.3.8
	varItem="2.3"
	varItemStandard="2.3.8"		
	varCriticidad="Alto"
	varPath="/etc/shadow"
	varValEsp="postgres *LK*"
	varParm="postgres"
	varDetalle="ITEM $varItemStandard Validar que la cuenta $varParm esta deshabilitada con el *LK* en el campo del usuario"
	varValEnc=` cat /etc/shadow | grep "^postgres" | awk -F: '/LK/{print $1, $2}' | tr -d "NP" | tail -1`	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		varValEnc="Not exist"		
	else
		if ( test "$varValEnc" = "$varValEsp" ); then 
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi			
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.3.8
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.3.9
	varItem="2.3"
	varItemStandard="2.3.9"		
	varCriticidad="Alto"
	varPath="/etc/shadow"
	varValEsp="noaccess *LK*"
	varParm="noaccess"
	varDetalle="ITEM $varItemStandard Validar que la cuenta $varParm esta deshabilitada con el *LK* en el campo del usuario"
	varValEnc=` cat /etc/shadow | grep "^noaccess" | awk -F: '/LK/{print $1, $2}' | tr -d "NP" | tail -1`	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		varValEnc="Not exist"		
	else
		if ( test "$varValEnc" = "$varValEsp" ); then 
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi			
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.3.9
#------------------------------------------



#------------------------------------------
# [INICIO] 	ÍTEM 2.3.10
	varItem="2.3"
	varItemStandard="2.3.10"		
	varCriticidad="Alto"
	varPath="/etc/shadow"
	varValEsp="nobody *LK*"
	varParm="nobody"
	varDetalle="ITEM $varItemStandard Validar que la cuenta $varParm esta deshabilitada con el *LK* en el campo del usuario"
	varValEnc=` cat /etc/shadow | grep "^nobody:" | awk -F: '/LK/{print $1, $2}' | tr -d "NP" | tail -1`	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		varValEnc="Not exist"		
	else
		if ( test "$varValEnc" = "$varValEsp" ); then 
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi			
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.3.10
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.3.11
	varItem="2.3"
	varItemStandard="2.3.11"		
	varCriticidad="Alto"
	varPath="/etc/shadow"
	varValEsp="nobody4 *LK*"
	varParm="nobody4"
	varDetalle="ITEM $varItemStandard Validar que la cuenta $varParm esta deshabilitada con el *LK* en el campo del usuario"
	varValEnc=` cat /etc/shadow | grep "^nobody4" | awk -F: '/LK/{print $1, $2}' | tr -d "NP" | tail -1`	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		varValEnc="Not exist"		
	else
		if ( test "$varValEnc" = "$varValEsp" ); then 
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi			
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.3.11
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.3.12
	varItem="2.3"
	varItemStandard="2.3.12"		
	varCriticidad="Alto"
	varPath="/etc/shadow"
	varValEsp="nuucp *LK*"
	varParm="nuucp"
	varDetalle="ITEM $varItemStandard Validar que la cuenta $varParm esta deshabilitada con el *LK* en el campo del usuario"
	varValEnc=` cat /etc/shadow | grep "^nuucp" | awk -F: '/LK/{print $1, $2}' | tr -d "NP" | tail -1`	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		varValEnc="Not exist"		
	else
		if ( test "$varValEnc" = "$varValEsp" ); then 
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi			
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.3.12
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.3.13
	varItem="2.3"
	varItemStandard="2.3.13"		
	varCriticidad="Alto"
	varPath="/etc/shadow"
	varValEsp="svctag *LK*"
	varParm="svctag"
	varDetalle="ITEM $varItemStandard Validar que la cuenta $varParm esta deshabilitada con el *LK* en el campo del usuario"
	varValEnc=` cat /etc/shadow | grep "^svctag" | awk -F: '/LK/{print $1, $2}' | tr -d "NP" | tail -1`	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		varValEnc="Not exist"		
	else
		if ( test "$varValEnc" = "$varValEsp" ); then 
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi			
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.3.13
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.3.14
	varItem="2.3"
	varItemStandard="2.3.14"		
	varCriticidad="Alto"
	varPath="/etc/shadow"
	varValEsp="sys *LK*"
	varParm="sys"
	varDetalle="ITEM $varItemStandard Validar que la cuenta $varParm esta deshabilitada con el *LK* en el campo del usuario"
	varValEnc=` cat /etc/shadow | grep "^sys" | awk -F: '/LK/{print $1, $2}' | tr -d "NP" | tail -1`	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		varValEnc="Not exist"		
	else
		if ( test "$varValEnc" = "$varValEsp" ); then 
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi			
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.3.14
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.3.15
	varItem="2.3"
	varItemStandard="2.3.15"		
	varCriticidad="Alto"
	varPath="/etc/shadow"
	varValEsp="uucp *LK*"
	varParm="uucp"
	varDetalle="ITEM $varItemStandard Validar que la cuenta $varParm esta deshabilitada con el *LK* en el campo del usuario"
	varValEnc=` cat /etc/shadow | grep "^uucp" | awk -F: '/LK/{print $1, $2}' | tr -d "NP" | tail -1`	
	if ( test "$varValEnc" = "" ) ; then
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		varValEnc="Not exist"		
	else
		if ( test "$varValEnc" = "$varValEsp" ); then 
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
		fi			
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.3.15
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.4.1
	varItem="2.4"
	varItemStandard="2.4.1"		
	varCriticidad="Alto"
	varPath="/etc/default/passwd"
	varValEsp="MINALPHA=1"
	varParm="MINALPHA"
	varDetalle="ITEM $varItemStandard Configurar contrasenas seguras $varParm "
	varValEnc=` cat /etc/default/passwd | grep "^MINALPHA" | tail -1 | awk -F= '{print $1,"=", $2}' | tr -d " "`	

	if ( test "$varValEnc" = "$varValEsp" ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.4.1
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.4.2
	varItem="2.4"
	varItemStandard="2.4.2"		
	varCriticidad="Alto"
	varPath="/etc/default/passwd"
	varValEsp="MINDIGIT=1"
	varParm="MINDIGIT"
	varDetalle="ITEM $varItemStandard Configurar contrasenas seguras $varParm "
	varValEnc=` cat /etc/default/passwd | grep "^MINDIGIT" | tail -1 | awk -F= '{print $1,"=", $2}' | tr -d " "`	
	if ( test "$varValEnc" = "$varValEsp" ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.4.2
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.4.3
	varItem="2.4"
	varItemStandard="2.4.3"		
	varCriticidad="Alto"
	varPath="/etc/default/passwd"
	varValEsp="MINSPECIAL=1"
	varParm="MINSPECIAL"
	varDetalle="ITEM $varItemStandard Configurar contrasenas seguras $varParm "
	varValEnc=` cat /etc/default/passwd | grep "^MINSPECIAL" | tail -1 | awk -F= '{print $1,"=", $2}' | tr -d " "`	
	if ( test "$varValEnc" = "$varValEsp" ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.4.3
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.4.4
	varItem="2.4"
	varItemStandard="2.4.4"		
	varCriticidad="Alto"
	varPath="/etc/default/passwd"
	varValEsp="PASSLENGTH=12"
	varParm="PASSLENGTH"
	varDetalle="ITEM $varItemStandard Configurar contrasenas seguras $varParm "
	varValEnc=` cat /etc/default/passwd | grep "^PASSLENGTH" | tail -1 | awk -F= '{print $1,"=", $2}' | tr -d " "`	
	if ( test "$varValEnc" = "$varValEsp" ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.4.4
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.4.5
	varItem="2.4"
	varItemStandard="2.4.5"		
	varCriticidad="Alto"
	varPath="/etc/default/passwd"
	varValEsp="MAXWEEKS=8"
	varParm="MAXWEEKS"
	varDetalle="ITEM $varItemStandard Configurar contrasenas seguras $varParm "
	varValEnc=` cat /etc/default/passwd | grep "^MAXWEEKS" | tail -1 | awk -F= '{print $1,"=", $2}' | tr -d " "`	
	if ( test "$varValEnc" = "$varValEsp" ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.4.5
#------------------------------------------



#------------------------------------------
# [INICIO] 	ÍTEM 2.4.6
	varItem="2.4"
	varItemStandard="2.4.6"		
	varCriticidad="Alto"
	varPath="/etc/default/passwd"
	varValEsp="MINWEEKS=4"
	varParm="MINWEEKS"
	varDetalle="ITEM $varItemStandard Configurar contrasenas seguras $varParm "
	varValEnc=` cat /etc/default/passwd | grep "^MINWEEKS" | tail -1 | awk -F= '{print $1,"=", $2}' | tr -d " "`	
	if ( test "$varValEnc" = "$varValEsp" ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.4.6
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.4.7
	varItem="2.4"
	varItemStandard="2.4.7"		
	varCriticidad="Alto"
	varPath="/etc/default/passwd"
	varValEsp="HISTORY=6"
	varParm="HITORY"
	varDetalle="ITEM $varItemStandard Configurar contrasenas seguras $varParm "
	varValEnc=` cat /etc/default/passwd | grep "^HISTORY" | tail -1 | awk -F= '{print $1,"=", $2}' | tr -d " "`	
	if ( test "$varValEnc" = "$varValEsp" ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.4.7
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.4.8
	varItem="2.4"
	varItemStandard="2.4.8"		
	varCriticidad="Alto"
	varPath="/etc/default/passwd"
	varValEsp="MINDIFF=2"
	varParm="MINDIFF"
	varDetalle="ITEM $varItemStandard Configurar contrasenas seguras $varParm "
	varValEnc=` cat /etc/default/passwd | grep "^MINDIFF" | tail -1 | awk -F= '{print $1,"=", $2}' | tr -d " "`	
	if ( test "$varValEnc" = "$varValEsp" ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.4.8
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.4.9
	varItem="2.4"
	varItemStandard="2.4.9"		
	varCriticidad="Alto"
	varPath="/etc/default/passwd"
	varValEsp="MINUPPER=1"
	varParm="MINUPPER"
	varDetalle="ITEM $varItemStandard Configurar contrasenas seguras $varParm "
	varValEnc=` cat /etc/default/passwd | grep "^MINUPPER" | tail -1 | awk -F= '{print $1,"=", $2}' | tr -d " "`	
	if ( test "$varValEnc" = "$varValEsp" ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.4.9
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.4.10
	varItem="2.4"
	varItemStandard="2.4.10"		
	varCriticidad="Alto"
	varPath="/etc/default/passwd"
	varValEsp="MINLOWER=1"
	varParm="MINLOWER"
	varDetalle="ITEM $varItemStandard Configurar contrasenas seguras $varParm "
	varValEnc=` cat /etc/default/passwd | grep "^MINLOWER" | tail -1 | awk -F= '{print $1,"=", $2}' | tr -d " "`	
	if ( test "$varValEnc" = "$varValEsp" ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.4.10
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.4.11
	varItem="2.4"
	varItemStandard="2.4.11"		
	varCriticidad="Alto"
	varPath="/etc/default/passwd"
	varValEsp="NAMECHECK=YES"
	varParm="NAMECHECK"
	varDetalle="ITEM $varItemStandard Configurar contrasenas seguras $varParm "
	varValEnc=` cat /etc/default/passwd | grep "^NAMECHECK" | tail -1 | awk -F= '{print $1,"=", $2}' | tr -d " "`	
	if ( test "$varValEnc" = "$varValEsp" ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.4.11
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.4.12
	varItem="2.4"
	varItemStandard="2.4.12"		
	varCriticidad="Alto"
	varPath="/etc/default/passwd"
	varValEsp="WARNWEEKS=2"
	varParm="WARNWEEKS"
	varDetalle="ITEM $varItemStandard Configurar contrasenas seguras $varParm "
	varValEnc=` cat /etc/default/passwd | grep "^WARNWEEKS" | tail -1 | awk -F= '{print $1,"=", $2}' | tr -d " "`	
	if ( test "$varValEnc" = "$varValEsp" ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.4.12
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.4.13
	varItem="2.4"
	varItemStandard="2.4.13"		
	varCriticidad="Alto"
	varPath="/etc/default/passwd"
	varValEsp="MAXREPEATS=2"
	varParm="MAXREPEATS"
	varDetalle="ITEM $varItemStandard Configurar contrasenas seguras $varParm "
	varValEnc=` cat /etc/default/passwd | grep "^MAXREPEATS" | tail -1 | awk -F= '{print $1,"=", $2}' | tr -d " "`	
	if ( test "$varValEnc" = "$varValEsp" ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.4.13
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.4.14
	varItem="2.4"
	varItemStandard="2.4.14"		
	varCriticidad="Alto"
	varPath="/etc/default/passwd"
	varValEsp="WHITESPACE=YES"
	varParm="WHITESPACE"
	varDetalle="ITEM $varItemStandard Configurar contrasenas seguras $varParm "
	varValEnc=` cat /etc/default/passwd | grep "^WHITESPACE" | tail -1 | awk -F= '{print $1,"=", $2}' | tr -d " "`	
	if ( test "$varValEnc" = "$varValEsp" ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.4.14
#------------------------------------------



#------------------------------------------
# [INICIO] 	ÍTEM 2.5.1
	varItem="2.5"
	varItemStandard="2.5.1"		
	varCriticidad="Alto"
	varPath="/etc/security/policy.conf"
	varValEsp="Pendiente"
	varParm="Pendiente"
	varDetalle="ITEM $varItemStandard Esquema RBAC $varParm "
	varValEnc="Pendiente"
	if ( test "$varValEnc" = "$varValEsp" ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.5.1	
#------------------------------------------



#------------------------------------------
# [INICIO] 	ÍTEM 2.6.1
	varItem="2.6"
	varItemStandard="2.6.1"		
	varCriticidad="Alto"
	varPath="/etc/security/policy.conf"
	varValEsp="LOCK_AFTER_RETRIES=YES"
	varParm="LOCK_AFTER_RETRIES"
	varDetalle="ITEM $varItemStandard Configurar bloqueo de cuentas para usuarios $varParm "
	varValEnc=` cat /etc/security/policy.conf | grep "^LOCK_AFTER_RETRIES" | tail -1 | awk -F= '{print $1,"=", $2}' | tr -d " "`	
	if ( test "$varValEnc" = "$varValEsp" ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.6.1	
#------------------------------------------



#------------------------------------------
# [INICIO] 	ÍTEM 2.6.2
	varItem="2.6"
	varItemStandard="2.6.2"		
	varCriticidad="Alto"
	varPath="/etc/default/login"
	varValEsp="RETRIES=3"
	varParm="RETRIES"
	varDetalle="ITEM $varItemStandard Configurar bloqueo de cuentas para usuarios $varParm "
	varValEnc=` cat /etc/default/login | grep "^RETRIES" | tail -1 | awk -F= '{print $1,"=", $2}' | tr -d " "`	
	if ( test "$varValEnc" = "$varValEsp" ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.6.2	
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.7.1
	varItem="2.7"
	varItemStandard="2.7.1"		
	varCriticidad="Bajo"
	varPath="/etc/pam.conf"
	varValEsp="login auth requisite pam_authtok_get.so.1"
	varParm="pam_authtok_get.so.1"
	varDetalle="ITEM $varItemStandard Configuracion de parametros $varParm "
	varValEnc=`cat /etc/pam.conf | grep "^login" | awk '/requisite/{print $1, $2, $3, $4}'`	
	if ( test "$varValEnc" = "$varValEsp" ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.7.1	
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.8.1
	varItem="2.8"
	varItemStandard="2.8.1"		
	varCriticidad="Alto"
	varPath=""
	varValEsp="E:all I:basic P:all L:all"
	varParm="ppriv $$"
	varDetalle="ITEM $varItemStandard Eliminar privilegios basicos no necestiados a los usuarios $varParm "
	varValEnc=`ppriv $$ | tail -4 | tr -d "\t" | tr -d " " | tr -s "\n" " "| awk '{print $1, $2, $3, $4}'`	
	if ( test "$varValEnc" = "$varValEsp" ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.8.1	
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.9.1
	varItem="2.9"
	varItemStandard="2.9.1"		
	varCriticidad="Alto"
	varPath=""
	varValEsp="umask 027"
	varParm="umask"
	varDetalle="ITEM $varItemStandard Establecer permisos para usuarios $varParm "
	varValEnc=`cat /etc/profile | grep "^umask"`	
	if ( test "$varValEnc" = "$varValEsp" ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.9.1	
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.9.2
	varItem="2.9"
	varItemStandard="2.9.2"		
	varCriticidad="Alto"
	varPath=""
	varValEsp="TMOUT=300"
	varParm="TMOUT"
	varDetalle="ITEM $varItemStandard Establecer permisos para usuarios $varParm "
	varValEnc=`cat /etc/profile | grep "^TMOUT" | awk -F= '{print $1"="$2}'`	
	if ( test "$varValEnc" = "$varValEsp" ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.9.2	
#------------------------------------------



#------------------------------------------
# [INICIO] 	ÍTEM 2.10.1
	varItem="2.10"
	varItemStandard="2.10.1"		
	varCriticidad="Alto"
	varPath=""
	varValEsp="0"
	varParm="inactive"
	varDetalle="ITEM $varItemStandard Bloquear cuentas de usuarios inactivos $varParm "
	varValEnc=` useradd -D | xargs -n 1 | grep "inactive" | awk -F= '{print $2}' `	
	if ( test $varValEnc -eq 0 ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna   ---	Validar si deben existir o no usuarios"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error   ---	Validar si deben existir o no usuarios"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.10.1	
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.11.1
	varItem="2.11"
	varItemStandard="2.11.1"		
	varCriticidad="Alto"
	varPath=""
	varValEsp="0"
	varParm="NP"
	varDetalle="ITEM $varItemStandard Validacion de usuarios sin password $varParm "
	varValEnc=`passwd -s -a | grep 'NP' | wc -l | tr -d " "`	
	if ( test $varValEnc -eq 0 ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.11.1	
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.12.1
	varItem="2.12"
	varItemStandard="2.12.1"		
	varCriticidad="Alto"
	varPath=""
	varValEsp="DICTIONLIST=/var/wrdrestrict"
	varParm="DICTIONLIST"
	varDetalle="ITEM $varItemStandard Restriccion de claves dediles con diccionario $varParm "
	varValEnc=`cat /etc/default/passwd | grep "^DICTIONLIST" | awk -F= '{print $1,"=",$2}' | tr -d " " | tail -1`	
	if ( test "$varValEnc" = "$varValEsp" ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.12.1	
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 2.13.1
	varItem="2.13"
	varItemStandard="2.13.1"		
	varCriticidad="Alto"
	varPath=""
	varValEsp="disabled"
	varParm="svc:/network/login:rlogin"
	varDetalle="ITEM $varItemStandard Inicio de sesion en un escritorio remoto $varParm "
	varValEnc=`svcs -Ho state svc:/network/login:rlogin`	
	if ( test "$varValEnc" = "$varValEsp" ); then 
		varCumplimiento="Cumple"	
		varObservaciones="Ninguna"
	else
		varCumplimiento="No Cumple"	
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ) ; then 
			varValEnc="S/D"	
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 2.13.1	
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 3.1.1
	varItem="3.1.1"
	varItemStandard="3.1.1"		
	varCriticidad="Alto"
	varPath=""
	varValEsp="audit condition = auditing"
	varParm="auditconfig -getcond"
	varDetalle="ITEM $varItemStandard Parametro de Auditoria $varParm"
	if ( test "$constVersion" = "Solaris 10"); then 
		varCumplimiento="Cumple"	
		varObservaciones="Only SunOS 11"
		varValEnc="Does not apply"
	else
		varValEnc=`svcs -Ho state svc:/system/auditd:default`	
		if ( test "$varValEnc" = "disabled" ); then 
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
			varValEnc="Service Audit is disabled"
		else
			varValEnc=`auditconfig -getcond`
			if ( test "$varValEnc" = "$varValEsp" ); then
				varCumplimiento="Cumple"	
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"	
				varObservaciones="Error"
				if ( test "$varValEnc" = "" ) ; then 
					varValEnc="S/D"	
				fi
			fi
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 3.1.1	
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 3.1.2
	varItem="3.1.2"
	varItemStandard="3.1.2"		
	varCriticidad="Alto"
	varPath=""
	varValEsp="configured audit policies = argv,cnt,zonename active audit policies = argv,cnt,zonename"
	varParm="auditconfig -getpolicy"
	varDetalle="ITEM $varItemStandard Parametro de Auditoria $varParm"
	if ( test "$constVersion" = "Solaris 10"); then 
	varCumplimiento="Cumple"	
	varObservaciones="Only SunOS 11"
	varValEnc="Does not apply"
	else
		varValEnc=`svcs -Ho state svc:/system/auditd:default`	
		if ( test "$varValEnc" = "disabled" ); then 
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
			varValEnc="Service Audit is disabled"
		else
			varValUno=`auditconfig -getpolicy | grep "configured"`
			varValDos=`auditconfig -getpolicy | grep "active"`
			varValEnc="$varValUno $varValDos"
			if ( test "$varValEnc" = "$varValEsp" ); then
				varCumplimiento="Cumple"	
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"	
				varObservaciones="Error"
				if ( test "$varValEnc" = "" ) ; then 
					varValEnc="S/D"	
				fi
			fi
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 3.1.2	
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 3.1.3
	varItem="3.1.3"
	varItemStandard="3.1.3"		
	varCriticidad="Alto"
	varPath=""
	varValEsp="configured user default audit flags = ex,aa,ua,as,ss,lo,ft(0x1000000800f1080,0x1000000800f1080) active user default audit flags = ex,aa,ua,as,ss,lo,ft(0x1000000800f1080,0x1000000800f1080)"
	varParm="auditconfig -getflags"
	varDetalle="ITEM $varItemStandard Parametro de Auditoria $varParm"

	if ( test "$constVersion" = "Solaris 10"); then 
	varCumplimiento="Cumple"	
	varObservaciones="Only SunOS 11"
	varValEnc="Does not apply"
	else
		varValEnc=`svcs -Ho state svc:/system/auditd:default`	
		if ( test "$varValEnc" = "disabled" ); then 
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
			varValEnc="Service Audit is disabled"
		else
			varValUno=`auditconfig -getflags | grep "configured"`
			varValDos=`auditconfig -getflags | grep "active"`
			varValEnc="$varValUno $varValDos"
			if ( test "$varValEnc" = "$varValEsp" ); then
				varCumplimiento="Cumple"	
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"	
				varObservaciones="Error"
				if ( test "$varValEnc" = "" ) ; then 
					varValEnc="S/D"	
				fi
			fi
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 3.1.3	
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 3.1.4
	varItem="3.1.4"
	varItemStandard="3.1.4"		
	varCriticidad="Alto"
	varPath=""
	varValEsp="configured non-attributable audit flags = lo(0x1000,0x1000) active non-attributable audit flags = lo(0x1000,0x1000)"
	varParm="auditconfig -getnaflags"
	varDetalle="ITEM $varItemStandard Parametro de Auditoria $varParm"

	if ( test "$constVersion" = "Solaris 10"); then 
	varCumplimiento="Cumple"	
	varObservaciones="Only SunOS 11"
	varValEnc="Does not apply"
	else
		varValEnc=`svcs -Ho state svc:/system/auditd:default`	
		if ( test "$varValEnc" = "disabled" ); then 
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
			varValEnc="Service Audit is disabled"
		else
			varValUno=`auditconfig -getnaflags | grep "configured"`
			varValDos=`auditconfig -getnaflags | grep "active"`
			varValEnc="$varValUno $varValDos"
			if ( test "$varValEnc" = "$varValEsp" ); then
				varCumplimiento="Cumple"	
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"	
				varObservaciones="Error"
				if ( test "$varValEnc" = "" ) ; then 
					varValEnc="S/D"	
				fi
			fi
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 3.1.4	
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 3.1.5
	varItem="3.1.5"
	varItemStandard="3.1.5"		
	varCriticidad="Alto"
	varPath=""
	varValEsp="Plugin: audit_binfile (active) Attributes: p_dir=/var/share/audit p_fsize=0 p_minfree=1"
	varParm="auditconfig -getplugin audit_binfile"
	varDetalle="ITEM $varItemStandard Parametro de Auditoria $varParm"

	if ( test "$constVersion" = "Solaris 10"); then 
	varCumplimiento="Cumple"	
	varObservaciones="Only SunOS 11"
	varValEnc="Does not apply"
	else
		varValEnc=`svcs -Ho state svc:/system/auditd:default`	
		if ( test "$varValEnc" = "disabled" ); then 
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
			varValEnc="Service Audit is disabled"
		else
			varValUno=`auditconfig -getplugin audit_binfile | grep "Plugin" | tr -d "\t" | tr ";" " " | tr -d ":"`
			varValDos=`auditconfig -getplugin audit_binfile | grep "Attributes" | tr -d "\t" | tr ";" " " | tr -d ":"`
			varValEnc="$varValUno $varValDos"
			if ( test "$varValEnc" = "$varValEsp" ); then
				varCumplimiento="Cumple"	
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"	
				varObservaciones="Error"
				if ( test "$varValEnc" = "" ) ; then 
					varValEnc="S/D"	
				fi
			fi
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 3.1.5	
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 3.1.6
	varItem="3.1.6"
	varItemStandard="3.1.6"		
	varCriticidad="Alto"
	varPath=""
	varValEsp="lo,ad,ft,ex:no"
	varParm="userattr audit_flags root"
	varDetalle="ITEM $varItemStandard Parametro de Auditoria $varParm"
	if ( test "$constVersion" = "Solaris 10"); then 
	varCumplimiento="Cumple"	
	varObservaciones="Only SunOS 11"
	varValEnc="Does not apply"
	else
		varValEnc=`svcs -Ho state svc:/system/auditd:default`	
		if ( test "$varValEnc" = "disabled" ); then 
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
			varValEnc="Service Audit is disabled"
		else
			varValEnc=`userattr audit_flags root`
			if ( test "$varValEnc" = "$varValEsp" ); then
				varCumplimiento="Cumple"	
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"	
				varObservaciones="Error"
				if ( test "$varValEnc" = "" ) ; then 
					varValEnc="S/D"	
				fi
			fi
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 3.1.6	
#------------------------------------------


#------------------------------------------
# [INICIO] 	ÍTEM 3.1.7
	varItem="3.1.7"
	varItemStandard="3.1.7"		
	varCriticidad="Alto"
	varPath=""
	varValEsp="Logs Audits"
	varParm="/var/share/audit/"
	varDetalle="ITEM $varItemStandard Parametro de Auditoria $varParm"
	if ( test "$constVersion" = "Solaris 10"); then 
	varCumplimiento="Cumple"	
	varObservaciones="Only SunOS 11"
	varValEnc="Does not apply"
	else
		varValEnc=`svcs -Ho state svc:/system/auditd:default`	
		if ( test "$varValEnc" = "disabled" ); then 
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
			varValEnc="Service Audit is disabled"
		else
			varValEnc=`ls -l /var/share/audit/*.not_terminated.*| wc -C`
			#varValEnc=`ls -l /var/share/audit/*.dasdasdas.*| wc -C`
			if ( test "$varValEnc" = "0" ); then
				varCumplimiento="No Cumple"	
				varObservaciones="Error"
				if ( test "$varValEnc" = "" ) ; then 
					varValEnc="S/D"	
				fi
			else
				varCumplimiento="Cumple"	
				varObservaciones="Ninguna"
				
			fi
		fi
	fi			
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] 	ÍTEM 3.1.7	
#------------------------------------------



echo		
if (test -f  $constPathClb/CLB_$constServer.$oMonth.csv ); then
	echo [*] El archivo CLB fue creado de manera satisfactoria  $constPathClb/CLB_$constServer.$oMonth.csv
else
	echo [*] No se pudo crear el archivo CLB $constPathClb/CLB_$constServer.$oMonth.csv 
	echo [*] Error al ejecutasr el control de linea base 
fi

echo 	 
echo [FIN PROCESO] - $dateTime 
echo