# Scritp de control de linea base para Red Hat 8
# CREADO POR: 		ALEXANDER GONZALEZ
# AUTORIZADO POR: 	NELSON PORRAS

clear

# --------------------------------------
# VARIABLES LOCALES DE ENTORNO
# --------------------------------------
dateTime=$(date "+%Y-%m-%d %H:%M:%S")
oDate=$(date "+%Y-%m-%d")
oMonth=$(date "+-%m%Y")
constPathTmp=/tmp
constPathClbRH=$constPathTmp/ClbUnix/RHEL
#constPathClbRH=$constPathTmp
constServer=$(hostname | cut -d "." -f 1)
constVersion="Red Hat 8"
constIP=$(hostname -I | cut -d " " -f 1)
constHeader="Fecha|Server|Version|IP|Item|Item_Standar|Criticidad|Detalle|Valor_Esperado|Valor_Encontrado|Cumplimiento|Observaciones"

varValEsp=""
varValEnc=""
varCumplimiento=""
varItem=""
varItemStandard=""
varItemReg=""
varCriticidad=""
varAuditLog=""
varObservaciones=""

echo "Fecha_Hora|Servidor|Item|Valor_Encontrado" > $constPathClbRH/LOG_$constServer.$oMonth.log
echo > $constPathClbRH/CLB_$constServer.$oMonth.csv
# --------------------------------------
# MAIN: SHELL PRINCIPAL
# --------------------------------------
echo -e "\n"
echo -e "\e[33m[INICIO PROCESO] - $dateTime \e[0m"
echo -e "\n"
	[ -d "$constPathClbRH" ]
	if [ $? -eq 0 ]; then
		echo -e "\e[1;32m 	[*] Ruta encontrada \e[0m" "\e[32m \t $constPathClbRH \e[0m"
	else
		echo -e "\e[1;31m 	[*] Ruta no encontrada \e[0m" "\e[31m \t $constPathClbRH \e[0m"
		echo -e "\e[1;33m 	[*] Creando la ruta \e[0m" "\e[33m \t $constPathClbRH \e[0m"
		mkdir /tmp/ClbUnix/RHEL -p
		echo -e "\e[1;32m 	[*] La ruta ha sido creada correctamente \e[0m" "\e[32m \t $constPathClbRH \e[0m"
		
	fi
	echo -e "\n"
	echo -e "\n $constHeader"
	echo $constHeader > $constPathClbRH/CLB_$constServer.$oMonth.csv

	#------------------------------------------
	# [INICIO] iTEM 1.1.1
		varItem="1.1.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar que este instalado la proteccion antimalware"
		varValEsp="falcon-sensor.service loaded active"
		varValEnc=$(systemctl list-units --type service -all | grep "falcon-sensor.service" | awk '{print $1,$2,$3}')
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.1.1 
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 2.2.1
		varItem="2.2.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validacion de particiones tmp"
		varValEsp="/tmp"
		varValEnc=$(df -lh | awk '{print $NF}' | grep "^/tmp$")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.2.1 
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 2.2.2
		varItem="2.2.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validacion de particiones var"
		varValEsp="/var"
		varQuery=$(df -lh | awk '{print $NF}' | grep "^/var$")
		varValEnc=${varQuery:0:4}
		if [[ $varValEsp = $varValEnc ]]; then		 	
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.2.2 
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 2.2.3
		varItem="2.2.3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validacion de particiones var/log"
		varValEsp="/var/log"
		varValEnc=$(df -lh | awk '{print $NF}' | grep "^/var/log$")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.2.3 
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 2.2.4
		varItem="2.2.4"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validacion de particiones home"
		varValEsp="/home"
		varValEnc=$(df -lh | awk '{print $NF}' | grep "^/home$")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.2.4 
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 2.2.5
		varItem="2.2.5"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validacion de particiones usr"
		varValEsp="/usr"
		varValEnc=$(df -lh | awk '{print $NF}' | grep "^/usr$")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.2.5 
	#------------------------------------------

	
	#------------------------------------------
	# [INICIO] iTEM 2.2.6
		varPart=/tmp
		varItem="2.2.6"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validacion de opciones de montaje noexec, nosuid y nodev en la particion $varPart"
		varValEsp=(nosuid nodev noexec)
		varQuery=($(grep $varPart /etc/fstab | awk '{print $4,$2}' | grep $varPart$))
		varQueryPart=${varQuery[1]}
		varQueryMount=($(echo ${varQuery[0]} | awk -F"," '{print $1, $2, $3}' ))
		varCont=0
		for i in ${varValEsp[*]}; do
			if [[ $i = ${varQueryMount[0]} ]]; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQueryMount[1]} ]]; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQueryMount[2]} ]]; then
				varCont=$((varCont+1))
			fi
		done
		varValEnc="$varQueryPart --- ${varQueryMount[*]}"
		if [[ $varQueryPart = $varPart && $varCont -eq 3 ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.2.6 
	#------------------------------------------

	
	#------------------------------------------
	# [INICIO] iTEM 2.2.7
		varPart=/var
		varItem="2.2.7"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validacion de opciones de montaje noexec, nosuid y nodev en la particion $varPart"
		varValEsp=(nosuid nodev noexec)
		varQuery=($(grep $varPart /etc/fstab | awk '{print $4,$2}' | grep $varPart$))
		varQueryPart=${varQuery[1]}
		varQueryMount=($(echo ${varQuery[0]} | awk -F"," '{print $1, $2, $3}' ))
		varCont=0
		for i in ${varValEsp[*]}; do
			if [[ $i = ${varQueryMount[0]} ]]; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQueryMount[1]} ]]; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQueryMount[2]} ]]; then
				varCont=$((varCont+1))
			fi
		done
		varValEnc="$varQueryPart --- ${varQueryMount[*]}"
		if [[ $varQueryPart = $varPart && $varCont -eq 3 ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|${varValEsp[*]}|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.2.7 
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 2.2.8
		varPart=/var/log
		varItem="2.2.8"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validacion de opciones de montaje noexec, nosuid y nodev en la particion $varPart"
		varValEsp=(nosuid nodev noexec)
		varQuery=($(grep $varPart /etc/fstab | awk '{print $4,$2}' | grep $varPart$))
		varQueryPart=${varQuery[1]}
		varQueryMount=($(echo ${varQuery[0]} | awk -F"," '{print $1, $2, $3}' ))
		varCont=0
		for i in ${varValEsp[*]}; do
			if [[ $i = ${varQueryMount[0]} ]]; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQueryMount[1]} ]]; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQueryMount[2]} ]]; then
				varCont=$((varCont+1))
			fi
		done
		varValEnc="$varQueryPart --- ${varQueryMount[*]}"
		if [[ $varQueryPart = $varPart && $varCont -eq 3 ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|${varValEsp[*]}|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.2.8 
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 2.2.9
		varPart=/dev/shm
		varItem="2.2.9"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validacion de opciones de montaje noexec, nosuid y nodev en la particion $varPart"
		varValEsp=(nosuid nodev noexec)
		varQuery=($(grep $varPart /etc/fstab | awk '{print $4, $2}' | grep $varPart$))
		varQueryPart=${varQuery[1]}
		varQueryMount=($(echo ${varQuery[0]} | awk -F"," '{print $1, $2, $3}' ))
		varCont=0
		for i in ${varValEsp[*]}; do
			if [[ $i = ${varQueryMount[0]} ]]; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQueryMount[1]} ]]; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQueryMount[2]} ]]; then
				varCont=$((varCont+1))
			fi
		done
		varValEnc="$varQueryPart --- ${varQueryMount[*]}"
		if [[ $varQueryPart = $varPart && $varCont -eq 3 ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|${varValEsp[*]}|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.2.9 
	#------------------------------------------

	
	#------------------------------------------
	# [INICIO] iTEM 2.2.10
		varPart=/home
		varItem="2.2.10"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validacion de opciones de montaje home en la particion $varPart"
		varValEsp=(nodev)
		varQuery=($(grep $varPart /etc/fstab | awk '{print $2, $4}' | grep "nodev"))
		varQueryPart=($(echo ${varQuery[1]} | awk -F"," '{print $1, $2, $3}' ))
		varQueryMount=($(echo ${varQuery[0]}))
		varCont=0
		for i in ${varQueryPart[*]}; do
			if [[ $i = "nodev" ]]; then
				varCont=$((varCont + 1))
			fi
		done
		varValEnc="$varQueryMount --- ${varQueryPart[*]}"
		if [[ $varCont -ge 1 ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|${varValEsp[*]}|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.2.10 
	#------------------------------------------
	

	#------------------------------------------
	# [INICIO] iTEM 2.2.11
		varPart=/usr
		varItem="2.2.11"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validacion de opciones de montaje usr en la particion $varPart"
		varValEsp=(nodev)
		varQuery=($(grep $varPart /etc/fstab | awk '{print $2, $4}' | grep "nodev"))
		varQueryPart=($(echo ${varQuery[1]} | awk -F"," '{print $1, $2, $3}' ))
		varQueryMount=($(echo ${varQuery[0]}))
		varCont=0
		for i in ${varQueryPart[*]}; do
			if [[ $i = "nodev" ]]; then
				varCont=$((varCont + 1))
			fi
		done
		varValEnc="$varQueryMount --- ${varQueryPart[*]}"
		if [[ $varCont -ge 1 ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|${varValEsp[*]}|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.2.11 
	#------------------------------------------
	


	#------------------------------------------
	# [INICIO] iTEM 2.3.1
		varItem="2.3.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="plugin-sec"
		varDetalle="ITEM $varItem Validacion de las ultimas actualizaciones instaladas"
		varValEnc=($( rpm -qa --last | grep plugin-sec | wc -l))
		if [[ $varValEnc -eq 1 ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.3.1
	#------------------------------------------
	
	
	#------------------------------------------
	# [INICIO] iTEM 2.4.1
		varItem="2.4.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Medio"
		varDetalle="ITEM $varItem Validar que los servicios cups de impresora este desactivado"
		varValEsp="inactive (dead)"
		varService=cups
		varExistService=$(systemctl status cups | grep active | awk '{print $2, $3}')	
		if [[ $varExistService = "inactive (dead)" ]]; then		 
			varCumplimiento="Cumple"
			varValEnc="$varExistService"
			varObservaciones="Ninguna"
		else		
			varQuery=($(whereis $varService | awk '{print $1, $2}'))
			if [[  $varQuery = "" ]]; then
				varCumplimiento="Cumple"
				varValEnc="not installed"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				varValEnc="${varQuery[0]} --- ${varQuery[1]}"
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.4.1
	#------------------------------------------

	
	#------------------------------------------
	# [INICIO] iTEM 2.5.1
		varItem="2.5.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Medio"
		varDetalle="ITEM $varItem Validar que el sistema de integridad de archivos AIDE este instalado"
		varValEsp=/usr/sbin/aide
		varService=aide
		varValEnc=$(whereis $varService | awk '{print $2}')	
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|"$varValEnc"|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.5.1
	#------------------------------------------	
	
	
	#------------------------------------------
	# [INICIO] iTEM 2.5.2
		varItem="2.5.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Medio"
		varDetalle="ITEM $varItem Validacion integridad del sistema de archivos crontab "
		varValEsp="0 5 /usr/sbin/aide --check"
		varService=/usr/sbin/aide
		varValEnc=$(crontab -l | grep "$varService" | sed -e "s/*/\\\*/g" | tr -s "0")	
		if [[ $varValEnc = "0 5 \* \* \* /usr/sbin/aide --check" ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="0 5 /usr/sbin/aide --check"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			varValEnc=$(crontab -l | grep "$varService" | sed -e "s/*/\\\*/g" | tr -s "0" | tr -d "\*")	
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.5.2
	#------------------------------------------	

	
	#------------------------------------------
	# [INICIO] iTEM 2.6.1
		varItem="2.6.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Configuracion de inicio seguro root"
		varValEsp="root root"
		varPath=/boot/grub2/grub.cfg
		varValEnc=$(ls -l $varPath | awk '{print $3, $4}')	
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.6.1
	#------------------------------------------	
	
	
	#------------------------------------------
	# [INICIO] iTEM 2.6.2
		varItem="2.6.2"
		varItemStandard=${varItem:0:3}
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Configuracion de inicio seguro og-rwx 600"
		varValEsp="600"
		varPath=/boot/grub2/grub.cfg
		varValEnc=$(stat -c "%a" $varPath)	
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.6.2
	#------------------------------------------	
	

	#------------------------------------------
	# [INICIO] iTEM 2.6.3
		varItem="2.6.3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Configuracion de inicio seguro password "
		varValEsp="pbkdf2 sha512"
		varPath=/boot/grub2/grub.cfg
		varValEnc=$(grep sha512 /boot/grub2/grub.cfg | tail -1 | tr -d " " | awk -F"." '/password_pbkdf2/{print $2, $3}' | grep "pbkdf2 sha512")	
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.6.3
	#------------------------------------------	


	#------------------------------------------
	# [INICIO] iTEM 2.6.4
		varItem="2.6.4"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Establecer contrasena del gestor de arranque en archivo"
		varValEsp="password_pbkdf2 root"
		varPath=/etc/grub.d/01_users
		varValEnc=$(cat /boot/grub2/grub.cfg | awk '/password_pbkdf2/{print $1, $2}')	
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="Cumple"
			varObservaciones="Pendiente Validacion de diseno"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.6.4
	#------------------------------------------


		#------------------------------------------
	# [INICIO] iTEM 2.6.5
		varItem="2.6.5"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Establecer contrasena del gestor de arranque en archivo "
		varValEsp="password_pbkdf2 root"
		varPath=/boot/grub2/grub.cfg
		varValEnc=$(cat /boot/grub2/grub.cfg | awk -F"grub" '/password_pbkdf2/{print $1}' | awk '{print $1, $2}' | tail -1)	
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.6.5
	#------------------------------------------



	
	#------------------------------------------
	# [INICIO] iTEM 2.6.6
		varItem="2.6.6"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Deshabilitar el sistema X Window"
		varValEsp=multi-user
		varValEnc=$(systemctl get-default | awk -F. '/^multi-user/{print $1}')	
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi	
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.6.6
	#------------------------------------------	

	
	#------------------------------------------
	# [INICIO] iTEM 2.7.1
		varItem="2.7.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varPath=/etc/security/limits.conf
		varDetalle="ITEM $varItem Validacion de que los core dumps se encuentren restringidos configurar el archivo /etc/security/limits.conf"
		varValEsp="* hard core 0"
		varValEnc=$(cat $varPath | awk '{print $1, $2, $3, $4}' | grep "^\* hard" | grep "core" | tail -1)	
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi	
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.7.1
	#------------------------------------------	

	
	#------------------------------------------
	# [INICIO] iTEM 2.7.2
		varItem="2.7.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validacion de que los core dumps se encuentren restringidos, archivo sysctl.conf"
		varValEsp="fs.suid_dumpable=0"
		varValEnc=$(grep ^fs.suid_dumpable /etc/sysctl.conf -n | tail -1 | tr -d " " | awk -F":" '{print $2}')	
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.7.2
	#------------------------------------------	

	
	#------------------------------------------
	# [INICIO] iTEM 2.7.3
		varItem="2.7.3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validacion del parametro del kernel activo"
		varValEsp="fs.suid_dumpable=0"
		varValEnc=$(sysctl -n fs.suid_dumpable)	
		if [[ $varValEnc -eq 0 ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.7.3
	#------------------------------------------	

		
	#------------------------------------------
	# [INICIO] iTEM 2.7.4
		varItem="2.7.4"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validacion de la asignacion aleatoria del espacio de direcciones ASLR este habilitada configurar /etc/sysctl.conf"
		varValEsp="kernel.randomize_va_space=2"
		varValEnc=$(grep ^kernel.randomize_va_space /etc/sysctl.conf -n | tail -1 | tr -d " "| awk -F":" '{print $2}')	
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.7.4
	#------------------------------------------	

	
	#------------------------------------------
	# [INICIO] iTEM 2.7.5
		varItem="2.7.5"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validacion de la asignacion aleatoria del espacio de direcciones ASLR este habilitada configurar /etc/sysctl.conf"
		varValEsp="kernel.randomize_va_space=2"
		varValEnc=$(sysctl -n kernel.randomize_va_space)	
		if [[ $varValEnc -eq 2 ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.7.5
	#------------------------------------------	
	

	#------------------------------------------
	# [INICIO] iTEM 2.7.6
		# varItem="2.7.6"
		# varItemStandard=${varItem:0:4}
		# if [[ ${varItemStandard:3:1} = "." ]]; then
		# 	varItemStandard=${varItem:0:3}
		# fi
		# varCriticidad="Alto"
		# varDetalle="ITEM $varItem Asegurese de que prelink este desactivado"
		# varValEsp="Not Installed"
		# varValEnc=$(rpm -qa prelink)	
		# if [[ $varValEnc -eq "" ]]; then		 
		# 	varCumplimiento="Cumple"
		# 	varValEnc="Not Installed"
		# 	varObservaciones="Ninguna"
		# else		
		# 	varCumplimiento="No Cumple"
		# 	varObservaciones="Error"
		# 	if [[ $varValEnc = "" ]]; then 
		# 		varValEnc="S/D"	
		# 	fi
		# fi
		# varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		# echo -e "\n $varItemReg "
		# echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		# echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.7.6
	#------------------------------------------		
	
	
	#------------------------------------------
	# [INICIO] iTEM 2.8.1
		varItem="2.8.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validacion de que el estado del SELINUX esta aplicado"
		varParameter="SELINUX="
		varValEsp="SELINUX=enforcing"
		varValEnc=$(grep ^$varParameter /etc/selinux/config | tr -d " ")	
		if [[ $varValEnc = $varValEsp ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
			
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.8.1
	#------------------------------------------	
	
	
	#------------------------------------------
	# [INICIO] iTEM 2.8.2
		varItem="2.8.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validacion de que el estado del SELINUX esta aplicado valor SELINUXTYPE"
		varParameter="SELINUXTYPE="
		varValEsp="SELINUXTYPE=targeted"
		varValEnc=$(grep ^$varParameter /etc/selinux/config | tr -d " ")	
		if [[ $varValEnc = $varValEsp ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
			
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.8.12
	#------------------------------------------	
	
	 
	#------------------------------------------
	# [INICIO] iTEM 2.9.1
		varItem="2.9.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Asegurese de que el mensaje de sesion este configurado correctamente"
		varParameter="BANCO PICHINCHA"
		varValEsp="BANCO PICHINCHA"
		varValEnc=$(grep "$varParameter" /etc/motd | tr -d "*" | tr -s " " | awk '{print $1, $2}')	
		if [[ $varValEnc = $varValEsp ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
			
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.9.1	
	#------------------------------------------	
	
	#------------------------------------------
	# [INICIO] iTEM 2.9.2
		varItem="2.9.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Asegurese de que el banner de advertencia este configurado correctamente"
		varParameter="BANNER"
		varValEsp="BANNER"
		varValEnc=$(cat /etc/issue)	
		if [[ ${#varValEnc} -ge 10 ]]; then		 
			varCumplimiento="Cumple"
			varValEnc="BANNER"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
			
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.9.2	
	#------------------------------------------	

	
	#------------------------------------------
	# [INICIO] iTEM 2.9.3
		varItem="2.9.3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Asegurese de que el banner de advertencia de inicio de sesion remota este configurado correctamente"
		varParameter="BANNER"
		varValEsp="BANNER"
		varValEnc=$(cat /etc/issue.net)
		if [[ ${#varValEnc} -ge 10 ]]; then		 
			varCumplimiento="Cumple"
			varValEnc="BANNER"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
			
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.9.3	
	#------------------------------------------	
	

	#------------------------------------------
	# [INICIO] iTEM 2.9.4
		varItem="2.9.4"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar que los permisos en /etc/motd estan configurados"
		varValEsp="root root"
		varValEnc=$(ls -l /etc/motd | tr -s " " | awk '{print $3, $4}')
		if [[ $varValEnc = $varValEsp ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
			
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.9.4	
	#------------------------------------------	
	
	
	#------------------------------------------
	# [INICIO] iTEM 2.9.5
		varItem="2.9.5"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar que los permisos en /etc/issue estan configurados"
		varValEsp="root root"
		varValEnc=$(ls -l /etc/issue | tr -s " " | awk '{print $3, $4}')
		if [[ $varValEnc = $varValEsp ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
			
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.9.5	
	#------------------------------------------	
	
	
	#------------------------------------------
	# [INICIO] iTEM 2.9.6
		varItem="2.9.6"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar que los permisos en /etc/issue.net estan configurados"
		varValEsp="root root"
		varValEnc=$(ls -l /etc/issue.net | tr -s " " | awk '{print $3, $4}')
		if [[ $varValEnc = $varValEsp ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
			
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.9.6	
	#------------------------------------------	

	
	#------------------------------------------
	# [INICIO] iTEM 2.9.7
		varItem="2.9.7"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar que los permisos en /etc/motd perm 644 estan configurados"
		varParameter=/etc/motd
		varValEsp="644"
		varValEnc=$(stat -c '%a' $varParameter)
		if [[ $varValEnc -eq 644 ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
			
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.9.7	
	#------------------------------------------	
	
	
	#------------------------------------------
	# [INICIO] iTEM 2.9.8
		varItem="2.9.8"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar que los permisos en /etc/issue perm 644 estan configurados"
		varParameter=/etc/issue
		varValEsp="644"
		varValEnc=$(stat -c '%a' $varParameter)
		if [[ $varValEnc -eq 644 ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
			
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.9.8	
	#------------------------------------------	

	
	#------------------------------------------
	# [INICIO] iTEM 2.9.9
		varItem="2.9.9"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar que los permisos en /etc/issue.net perm 644 estan configurados"
		varParameter=/etc/issue.net
		varValEsp="644"
		varValEnc=$(stat -c '%a' $varParameter)
		if [[ $varValEnc -eq 644 ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
			
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 2.9.9	
	#------------------------------------------	


	#	Solo aplica a redhat8
	if [[ $constVersion = "Red Hat 8" ]]; then 

		#------------------------------------------
		# [INICIO] iTEM 2.10.1
		varItem="2.10.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar las politicas por default instaladas en el sistema"
		varValEsp="DEFAULT"
		varValEnc=$(update-crypto-policies --show)
		if [[ $varValEnc = $varValEsp ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
			
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
		# [FIN] iTEM 2.10.1	
		#------------------------------------------	
		
		
		#------------------------------------------
		# [INICIO] iTEM 2.10.2
		varItem="2.10.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar las politicas por default instaladas en el sistema"
		varValEsp="DEFAULT"
		varValEnc=$(update-crypto-policies --show)
		if [[ $varValEnc = $varValEsp ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna   ---   Pendiente Diseno"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
			
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
		# [FIN] iTEM 2.10.2	
		#------------------------------------------	

	fi

	#------------------------------------------
	# [INICIO] iTEM 3.1.1
		varItem="3.1.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar si xinetd esta habilitado"
		varValEsp="not installed"
		varService=xinetd
		
		varExistService=$(rpm -q $varService)	
		if [[ $? -eq 1 ]]; then		 	 
			varCumplimiento="Cumple"
			varValEnc="$varExistService"
			varObservaciones="Ninguna"
		else		
			varQuery=($(whereis $varService | awk '{print $1, $2}'))
			if [[  $varQuery = "" ]]; then
				varCumplimiento="Cumple"
				varValEnc="not installed"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				varValEnc="${varQuery[0]} --- ${varQuery[1]}"
			fi
		fi



		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.1.1
	#------------------------------------------
	
	
	#------------------------------------------
	# [INICIO] iTEM 3.1.2
		varItem="3.1.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Asegurese de que el agente de transferencia de correo electronico postfix se encuentre desinstalado"
		varValEsp="not installed"
		varService=postfix
		varExistService=$(rpm -q $varService)	
		if [[ $? -eq 1 ]]; then		 	 
			varCumplimiento="Cumple"
			varValEnc="$varExistService"
			varObservaciones="Ninguna"
		else		
			varQuery=($(whereis $varService | awk '{print $1, $2}'))
			if [[  $varQuery = "" ]]; then
				varCumplimiento="Cumple"
				varValEnc="not installed"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				varValEnc="${varQuery[0]} --- ${varQuery[1]}"
			fi
		fi

		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.1.2
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 3.1.3
		varItem="3.1.3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar la eliminacion de los siguientes clientes de servicio ypbind"
		varValEsp="not installed"
		varService=ypbind
		varExistService=$(rpm -q $varService)	
		if [[ $? -eq 1 ]]; then		 	 
			varCumplimiento="Cumple"
			varValEnc="$varExistService"
			varObservaciones="Ninguna"
		else		
			varQuery=($(whereis $varService | awk '{print $1, $2}'))
			if [[  $varQuery = "" ]]; then
				varCumplimiento="Cumple"
				varValEnc="not installed"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				varValEnc="${varQuery[0]} --- ${varQuery[1]}"
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.1.3
	#------------------------------------------


	#----------------------------------------------
	# [INICIO] iTEM 3.1.4
		varItem="3.1.4"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar la eliminacion de los siguientes clientes de servicio rsh"
		varValEsp="not installed"
		varService=rsh
		varExistService=$(rpm -q $varService)	
		if [[ $? -eq 1 ]]; then		 	 
			varCumplimiento="Cumple"
			varValEnc="$varExistService"
			varObservaciones="Ninguna"
		else		
			varQuery=($(whereis $varService | awk '{print $1, $2}'))
			if [[  $varQuery = "" ]]; then
				varCumplimiento="Cumple"
				varValEnc="not installed"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				varValEnc="${varQuery[0]} --- ${varQuery[1]}"
			fi
		fi

		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.1.4
	#------------------------------------------
	
	
	#------------------------------------------
	# [INICIO] iTEM 3.1.5
		varItem="3.1.5"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar la eliminacion de los siguientes clientes de servicio talk"
		varValEsp="not installed"
		varService=talk
		varExistService=$(rpm -q $varService)	
		if [[ $? -eq 1 ]]; then		 	 
			varCumplimiento="Cumple"
			varValEnc="$varExistService"
			varObservaciones="Ninguna"
		else		
			varQuery=($(whereis $varService | awk '{print $1, $2}'))
			if [[  $varQuery = "" ]]; then
				varCumplimiento="Cumple"
				varValEnc="not installed"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				varValEnc="${varQuery[0]} --- ${varQuery[1]}"
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.1.5
	#------------------------------------------
	
	
	#------------------------------------------
	# [INICIO] iTEM 3.1.6
		varItem="3.1.6"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar la eliminacion de los siguientes clientes de servicio telnet"
		varValEsp="Telnet"
		varService=telnet
		varExistService=$(rpm -q $varService)	
		if [[ $? -eq 1 ]]; then		 	 
			varCumplimiento="Cumple"
			varValEnc="$varExistService"
			varObservaciones="Ninguna"
		else		
			varQuery=($(whereis $varService | awk '{print $1, $2}'))
			if [[  $varQuery = "" ]]; then
				varCumplimiento="Cumple"
				varValEnc="not installed"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				varValEnc="${varQuery[0]} --- ${varQuery[1]}"
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.1.6
	#------------------------------------------

	
	#------------------------------------------
	# [INICIO] iTEM 3.1.7
		varItem="3.1.7"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar la eliminacion de los siguientes clientes de servicio openldap-clients"
		varValEsp="not installed"
		varService=openldap-clients
		varExistService=$(rpm -q $varService)	
		if [[ $? -eq 1 ]]; then		 	 
			varCumplimiento="Cumple"
			varValEnc="$varExistService"
			varObservaciones="Ninguna"
		else		
			varQuery=($(whereis $varService | awk '{print $1, $2}'))
			if [[  $varQuery = "" ]]; then
				varCumplimiento="Cumple"
				varValEnc="not installed"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				varValEnc="${varQuery[0]} --- ${varQuery[1]}"
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.1.7
	#------------------------------------------

	
	#------------------------------------------
	# [INICIO] iTEM 3.1.8
		varItem="3.1.8"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar la eliminacion de los siguientes clientes de servicio  inetd"
		varValEsp="not installed"
		varService=inetd
		varExistService=$(rpm -q $varService)	
		if [[ $? -eq 1 ]]; then		 	 
			varCumplimiento="Cumple"
			varValEnc="$varExistService"
			varObservaciones="Ninguna"
		else		
			varQuery=($(whereis $varService | awk '{print $1, $2}'))
			if [[  $varQuery = "" ]]; then
				varCumplimiento="Cumple"
				varValEnc="not installed"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				varValEnc="${varQuery[0]} --- ${varQuery[1]}"
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.1.8
	#------------------------------------------

	
	#------------------------------------------
	# [INICIO] iTEM 3.1.9
		varItem="3.1.9"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar la eliminacion de los siguientes clientes de servicio chargen"
		varValEsp="not installed"
		varService=chargen
		varExistService=$(rpm -q $varService)	
		if [[ $? -eq 1 ]]; then		 	 
			varCumplimiento="Cumple"
			varValEnc="$varExistService"
			varObservaciones="Ninguna"
		else		
			varQuery=($(whereis $varService | awk '{print $1, $2}'))
			if [[  $varQuery = "" ]]; then
				varCumplimiento="Cumple"
				varValEnc="not installed"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				varValEnc="${varQuery[0]} --- ${varQuery[1]}"
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.1.9
	#------------------------------------------

	
    #------------------------------------------
	# [INICIO] iTEM 3.1.10
		varItem="3.1.10"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar la eliminacion de los siguientes clientes de servicio daytime"
		varValEsp="not installed"
		varService=daytime
		varExistService=$(rpm -q $varService)	
		if [[ $? -eq 1 ]]; then		 	 
			varCumplimiento="Cumple"
			varValEnc="$varExistService"
			varObservaciones="Ninguna"
		else		
			varQuery=($(whereis $varService | awk '{print $1, $2}'))
			if [[  $varQuery = "" ]]; then
				varCumplimiento="Cumple"
				varValEnc="not installed"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				varValEnc="${varQuery[0]} --- ${varQuery[1]}"
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.1.10
	#------------------------------------------
	
	
	#------------------------------------------
	# [INICIO] iTEM 3.1.11
		varItem="3.1.11"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar la eliminacion de los siguientes clientes de servicio discard"
		varValEsp="not installed"
		varService=discard
		varExistService=$(rpm -q $varService)	
		if [[ $? -eq 1 ]]; then		 	 
			varCumplimiento="Cumple"
			varValEnc="$varExistService"
			varObservaciones="Ninguna"
		else		
			varQuery=($(whereis $varService | awk '{print $1, $2}'))
			if [[  $varQuery = "" ]]; then
				varCumplimiento="Cumple"
				varValEnc="not installed"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				varValEnc="${varQuery[0]} --- ${varQuery[1]}"
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.1.11
	#------------------------------------------
	
	
	#------------------------------------------
	# [INICIO] iTEM 3.1.12
		varItem="3.1.12"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar la eliminacion de los siguientes clientes de servicio echo"
		varValEsp="not installed"
		varService=echo
		varExistService=$(rpm -q $varService)	
		if [[ $? -eq 1 ]]; then		 	 
			varCumplimiento="Cumple"
			varValEnc="$varExistService"
			varObservaciones="Ninguna"
		else		
			varQuery=($(whereis $varService | awk '{print $1, $2}'))
			if [[  $varQuery = "" ]]; then
				varCumplimiento="Cumple"
				varValEnc="not installed"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				varValEnc="${varQuery[0]} --- ${varQuery[1]}"
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.1.12
	#------------------------------------------
	
	
	#------------------------------------------
	# [INICIO] iTEM 3.1.13
		varItem="3.1.13"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar la eliminacion de los siguientes clientes de servicio time"
		varValEsp="not installed"
		varService=time
		varExistService=$(rpm -q $varService)	
		if [[ $? -eq 1 ]]; then		 	 
			varCumplimiento="Cumple"
			varValEnc="$varExistService"
			varObservaciones="Ninguna"
		else		
			varQuery=($(whereis $varService | awk '{print $1, $2}'))
			if [[  $varQuery = "" ]]; then
				varCumplimiento="Cumple"
				varValEnc="not installed"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				varValEnc="${varQuery[0]} --- ${varQuery[1]}"
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.1.13
	#------------------------------------------
	
	
	#------------------------------------------
	# [INICIO] iTEM 3.1.14
		varItem="3.1.14"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar la eliminacion de los siguientes clientes de servicio tftp"
		varValEsp="not installed"
		varService=tftp
		varExistService=$(rpm -q $varService)	
		if [[ $? -eq 1 ]]; then		 	 
			varCumplimiento="Cumple"
			varValEnc="$varExistService"
			varObservaciones="Ninguna"
		else		
			varQuery=($(whereis $varService | awk '{print $1, $2}'))
			if [[  $varQuery = "" ]]; then
				varCumplimiento="Cumple"
				varValEnc="not installed"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				varValEnc="${varQuery[0]} --- ${varQuery[1]}"
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.1.14
	#------------------------------------------
	
	
	#------------------------------------------
	# [INICIO] iTEM 3.1.15
		varItem="3.1.15"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar la eliminacion de los siguientes clientes de servicio finger"
		varValEsp="not installed"
		varService=finger
		varExistService=$(rpm -q $varService)	
		if [[ $? -eq 1 ]]; then		 	 
			varCumplimiento="Cumple"
			varValEnc="$varExistService"
			varObservaciones="Ninguna"
		else		
			varQuery=($(whereis $varService | awk '{print $1, $2}'))
			if [[  $varQuery = "" ]]; then
				varCumplimiento="Cumple"
				varValEnc="not installed"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				varValEnc="${varQuery[0]} --- ${varQuery[1]}"
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.1.15
	#------------------------------------------
	

	#------------------------------------------
	# [INICIO] iTEM 3.1.16
		varItem="3.1.16"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar la eliminacion de los siguientes clientes de servicio snmp"
		varValEsp="not installed"
		varService=snmp
		varExistService=$(rpm -q $varService)	
		if [[ $? -eq 1 ]]; then		 	 
			varCumplimiento="Cumple"
			varValEnc="$varExistService"
			varObservaciones="Ninguna"
		else		
			varQuery=($(whereis $varService | awk '{print $1, $2}'))
			if [[  $varQuery = "" ]]; then
				varCumplimiento="Cumple"
				varValEnc="not installed"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				varValEnc="${varQuery[0]} --- ${varQuery[1]}"
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.1.16
	#------------------------------------------

	
	#------------------------------------------
	# [INICIO] iTEM 3.1.17
		varItem="3.1.17"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar la eliminacion de los siguientes clientes de servicio ftp"
		varValEsp="not installed"
		varService=ftp
		varExistService=$(rpm -q $varService)	
		if [[ $? -eq 1 ]]; then		 
			varCumplimiento="Cumple"
			varValEnc="$varExistService"
			varObservaciones="Ninguna"
		else		
			varQuery=($(whereis $varService | awk '{print $1, $2}'))
			if [[  $varQuery = "" ]]; then
				varCumplimiento="Cumple"
				varValEnc="not installed"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				varValEnc="${varQuery[0]} --- ${varQuery[1]}"
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.1.17
	#------------------------------------------
	
	
	#------------------------------------------
	# [INICIO] iTEM 3.1.18
		varItem="3.1.18"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar la eliminacion de los siguientes clientes de servicio nis"
		varValEsp="not installed"
		varService=nis
		varExistService=$(rpm -q $varService)	
		if [[ $? -eq 1 ]]; then		 	 
			varCumplimiento="Cumple"
			varValEnc="$varExistService"
			varObservaciones="Ninguna"
		else		
			varQuery=($(whereis $varService | awk '{print $1, $2}'))
			if [[  $varQuery = "" ]]; then
				varCumplimiento="Cumple"
				varValEnc="not installed"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				varValEnc="${varQuery[0]} --- ${varQuery[1]}"
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.1.18
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 3.1.19
		varItem="3.1.19"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar la eliminacion de los siguientes clientes de servicio rlogin"
		varValEsp="not installed"
		varService=rlogin
		varExistService=$(rpm -q $varService)	
		if [[ $? -eq 1 ]]; then		 	 
			varCumplimiento="Cumple"
			varValEnc="$varExistService"
			varObservaciones="Ninguna"
		else		
			varQuery=($(whereis $varService | awk '{print $1, $2}'))
			if [[  $varQuery = "" ]]; then
				varCumplimiento="Cumple"
				varValEnc="not installed"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				varValEnc="${varQuery[0]} --- ${varQuery[1]}"
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.1.19
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 3.1.20
		varItem="3.1.20"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar la eliminacion de los siguientes clientes de servicio rexec"
		varValEsp="not installed"
		varService=rexec
		varExistService=$(rpm -q $varService)	
		if [[ $? -eq 1 ]]; then		 	 
			varCumplimiento="Cumple"
			varValEnc="$varExistService"
			varObservaciones="Ninguna"
		else		
			varQuery=($(whereis $varService | awk '{print $1, $2}'))
			if [[  $varQuery = "" ]]; then
				varCumplimiento="Cumple"
				varValEnc="not installed"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				varValEnc="${varQuery[0]} --- ${varQuery[1]}"
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.1.20
	#------------------------------------------
	

	#------------------------------------------
	# [INICIO] iTEM 3.2.1
		varPar="restrict -4"
		varItem="3.2.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar que el NTP se encuentre configurado. Restrict -4"
		varValEsp=(default kod nomodify notrap nopeer noquery)
		varQuery=($(cat /etc/ntp.conf | grep "$varPar" | awk '{print $3,$4,$5,$6,$7,$8}'))
		varCont=0
		for i in ${varValEsp[*]}; do
			if [[ $i = ${varQuery[0]} ]]; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQuery[1]} ]]; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQuery[2]} ]]; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQuery[3]} ]]; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQuery[4]} ]]; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQuery[5]} ]]; then
				varCont=$((varCont+1))
			fi
		done

		if [[ $constVersion = "Red Hat 8" ]]; then
			varCumplimiento="Cumple"
			varObservaciones="No Aplica"
		else
			varValEnc="${varQuery[*]}"
			if [[ $varCont -eq 6 ]]; then		 
				varCumplimiento="Cumple"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				if [[ $varValEnc = "" ]]; then 
					varValEnc="S/D"	
				fi
			fi
		fi
		
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.2.1 
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 3.2.2
		varPar="restrict -6"
		varItem="3.2.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar que el NTP se encuentre configurado. Restrict -6"
		varValEsp=(default kod nomodify notrap nopeer noquery)
		varQuery=($(cat /etc/ntp.conf | grep "$varPar" | awk '{print $3,$4,$5,$6,$7,$8}'))
		varCont=0
		for i in ${varValEsp[*]}; do
			if [[ $i = ${varQuery[0]} ]]; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQuery[1]} ]]; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQuery[2]} ]]; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQuery[3]} ]]; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQuery[4]} ]]; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQuery[5]} ]]; then
				varCont=$((varCont+1))
			fi
		done

		if [[ $constVersion = "Red Hat 8" ]]; then
			varCumplimiento="Cumple"
			varObservaciones="No Aplica"
		else
			varValEnc="${varQuery[*]}"
			if [[ $varCont -eq 6 ]]; then		 
				varCumplimiento="Cumple"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				if [[ $varValEnc = "" ]]; then 
					varValEnc="S/D"	
				fi
			fi
		fi

	
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.2.2 
	#------------------------------------------
	
	
	#------------------------------------------
	# [INICIO] iTEM 3.2.3
		varItem="3.2.3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Anadir el nombre del servidor al archivo /etc/ntp.conf"
		varValEsp=("10.0.0.163" "ecuio012d04")
		varQuery=($(grep -E '10.0.0.163|ecuio012d04' /etc/ntp.conf | tail -1))
		varCont=0
		for i in ${varValEsp[*]}; do
			if [[ $i = ${varQuery[1]} ]]; then
				varCont=$((varCont+1))
			fi		
		done

		if [[ $constVersion = "Red Hat 8" ]]; then
			varCumplimiento="Cumple"
			varObservaciones="No Aplica"
		else

			varValEnc="${varQuery[*]}"
			if [[ $varCont -eq 1 ]]; then		 
				varCumplimiento="Cumple"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				if [[ $varValEnc = "" ]]; then 
					varValEnc="S/D"	
				fi
			fi
		fi
		
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.2.3 
	#------------------------------------------	
	
	
	#------------------------------------------
	# [INICIO] iTEM 3.2.4
		varItem="3.2.4"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Editar OPTIONS en /etc/sysconfig/ntpd"
		varValEsp="OPTIONS=-u ntp:ntp"
		varValEnc=$(grep "ntp:ntp" /etc/sysconfig/ntpd | tr -d "\"")

		if [[ $constVersion = "Red Hat 8" ]]; then
			varCumplimiento="Cumple"
			varObservaciones="No Aplica"
		else
			if [[ $varValEnc = $varValEsp ]]; then		 
				varCumplimiento="Cumple"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				if [[ $varValEnc = "" ]]; then 
					varValEnc="S/D"	
				fi
			fi
		fi

		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.2.4 
	#------------------------------------------	


	#------------------------------------------
	# [INICIO] iTEM 3.2.5
		varItem="3.2.5"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Anadir el nombre del servidor al archivo /etc/chrony.conf"
		varValEsp=("10.0.0.163" "ecuio012d04")
		varQuery=($(grep -E '10.0.0.163|ecuio012d04' /etc/chrony.conf | tail -1))
		varCont=0
		for i in ${varValEsp[*]}; do
			if [[ $i = ${varQuery[1]} ]]; then
				varCont=$((varCont+1))
			fi		
		done
		varValEnc="${varQuery[*]}"
		if [[ $varCont -eq 1 ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
	2.2.11	echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.2.5 
	#------------------------------------------	
	
	
	#------------------------------------------
	# [INICIO] iTEM 3.2.6
		varItem="3.2.6"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Editar OPTIONS en /etc/sysconfig/chronyd"
		varValEsp="OPTIONS=-u chrony"
		varValEnc=$(grep "u chrony" /etc/sysconfig/chronyd | tr -d "\"" | tail -1)
		if [[ $varValEnc = $varValEsp ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 3.2.6 
	#------------------------------------------		

	
	#------------------------------------------
	# [INICIO] iTEM 4.2.1
		varItem="4.2.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="net.ipv4.ip_forward=0"
		varDetalle="ITEM $varItem Configurar parametros de red /etc/sysctl.conf, Asegurese de que el reenvio IP este deshabilitado"		
		varValEnc=$(grep "net.ipv4.ip_forward" /etc/sysctl.conf | tail -1 | tr -d "\t" | tr -d " " | awk '{print $1}')
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 4.2.1 
	#------------------------------------------		

	
	#------------------------------------------
	# [INICIO] iTEM 4.2.2
		varItem="4.2.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="net.ipv4.conf.default.send_redirects=0"
		varDetalle="ITEM $varItem Configurar parametros de red /etc/sysctl.conf, Asegurese de que el envio de redirigir paquetes esta deshabilitado"		
		varValEnc=$( grep "net.ipv4.conf.default.send_redirects" /etc/sysctl.conf | tr -d " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 4.2.2 
	#------------------------------------------		

	
	#------------------------------------------
	# [INICIO] iTEM 4.2.3
		varItem="4.2.3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="net.ipv4.conf.all.send_redirects=0"
		varDetalle="ITEM $varItem Configurar parametros de red /etc/sysctl.conf, Asegurese de que el envio de redirigir paquetes esta deshabilitado"		
		varValEnc=$( grep "net.ipv4.conf.all.send_redirects" /etc/sysctl.conf | tr -d " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 4.2.3 
	#------------------------------------------			
	
	
	#------------------------------------------
	# [INICIO] iTEM 4.2.4
		varItem="4.2.4"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="net.ipv4.conf.default.accept_source_route=0"
		varDetalle="ITEM $varItem Configurar parametros de red /etc/sysctl.conf, Asegurese de que no se aceptan paquetes enrutados de origen"		
		varValEnc=$( grep "^net.ipv4.conf.default.accept_source_route" /etc/sysctl.conf | tr -d " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 4.2.4
	#------------------------------------------			
		
	
	#------------------------------------------
	# [INICIO] iTEM 4.2.5
		varItem="4.2.5"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="net.ipv4.conf.all.accept_source_route=0"
		varDetalle="ITEM $varItem Configurar parametros de red /etc/sysctl.conf, Asegurese de que no se aceptan paquetes enrutados de origen"		
		varValEnc=$( grep "^net.ipv4.conf.all.accept_source_route" /etc/sysctl.conf | tr -d " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 4.2.5
	#------------------------------------------	


	#------------------------------------------
	# [INICIO] iTEM 4.2.6
		varItem="4.2.6"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="net.ipv4.conf.default.accept_redirects=0"
		varDetalle="ITEM $varItem Configurar parametros de red /etc/sysctl.conf, Asegurese de que los redireccionamientos ICMP no se aceptan"		
		varValEnc=$(grep "^net.ipv4.conf.default.accept_redirects" /etc/sysctl.conf | tr -d " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 4.2.6
	#------------------------------------------			
	

	#------------------------------------------
	# [INICIO] iTEM 4.2.7
		varItem="4.2.7"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="net.ipv4.conf.all.accept_redirects=0"
		varDetalle="ITEM $varItem Configurar parametros de red /etc/sysctl.conf, Asegurese de que los redireccionamientos ICMP no se aceptan"		
		varValEnc=$( grep "^net.ipv4.conf.all.accept_redirects" /etc/sysctl.conf | tr -d " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 4.2.7
	#------------------------------------------			
		
	
	#------------------------------------------
	# [INICIO] iTEM 4.2.8
		varItem="4.2.8"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="net.ipv4.conf.default.secure_redirects=0"
		varDetalle="ITEM $varItem Configurar parametros de red /etc/sysctl.conf, Asegurese de que no se aceptan redirecciones ICMP seguras"		
		varValEnc=$( grep "net.ipv4.conf.default.secure_redirects" /etc/sysctl.conf | tr -d " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 4.2.8
	#------------------------------------------				
	
	
	#------------------------------------------
	# [INICIO] iTEM 4.2.9
		varItem="4.2.9"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="net.ipv4.conf.all.secure_redirects=0"
		varDetalle="ITEM $varItem Configurar parametros de red /etc/sysctl.conf, Asegurese de que no se aceptan redirecciones ICMP seguras"		
		varValEnc=$(grep "net.ipv4.conf.all.secure_redirects" /etc/sysctl.conf | tr -d " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 4.2.9
	#------------------------------------------			
	
	
	#------------------------------------------
	# [INICIO] iTEM 4.2.10
		varItem="4.2.10"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="net.ipv4.conf.default.log_martians=1"
		varDetalle="ITEM $varItem Configurar parametros de red /etc/sysctl.conf, Asegurese de que los paquetes sospechosos se registren"
		varValEnc=$(grep "net.ipv4.conf.default.log_martians" /etc/sysctl.conf | tr -d " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 4.2.10
	#------------------------------------------		
	
	
	#------------------------------------------
	# [INICIO] iTEM 4.2.11
		varItem="4.2.11"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="net.ipv4.conf.all.log_martians=1"
		varDetalle="ITEM $varItem Configurar parametros de red /etc/sysctl.conf, Asegurese de que los paquetes sospechosos se registren"
		varValEnc=$(grep "net.ipv4.conf.all.log_martians" /etc/sysctl.conf | tr -d " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 4.2.11
	#------------------------------------------		
	
	
	#------------------------------------------
	# [INICIO] iTEM 4.2.12
		varItem="4.2.12"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="net.ipv4.icmp_echo_ignore_broadcasts=1"
		varDetalle="ITEM $varItem Configurar parametros de red /etc/sysctl.conf, Asegurese de que las solicitudes ICMP de difusion no se tengan en cuenta"
		varValEnc=$(grep "^net.ipv4.icmp_echo_ignore_broadcasts" /etc/sysctl.conf | tr -d " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 4.2.12
	#------------------------------------------		


	#------------------------------------------
	# [INICIO] iTEM 4.2.13
		varItem="4.2.13"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="net.ipv4.icmp_ignore_bogus_error_responses=1"
		varDetalle="ITEM $varItem Configurar parametros de red /etc/sysctl.conf, Asegurar que las respuestas ICMP falsas se ignoran"
		varValEnc=$(grep "net.ipv4.icmp_ignore_bogus_error_responses" /etc/sysctl.conf | tr -d " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 4.2.13
	#------------------------------------------		

	
	#------------------------------------------
	# [INICIO] iTEM 4.2.4
		varItem="4.2.14"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="net.ipv4.conf.default.rp_filter=1"
		varDetalle="ITEM $varItem Configurar parametros de red /etc/sysctl.conf, Asegurese de que el Filtrado de ruta inversa esta habilitado"
		varValEnc=$(grep "net.ipv4.conf.default.rp_filter" /etc/sysctl.conf | tr -d " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 4.2.14
	#------------------------------------------		


	#------------------------------------------
	# [INICIO] iTEM 4.2.15
		varItem="4.2.15"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="net.ipv4.conf.all.rp_filter=1"
		varDetalle="ITEM $varItem Configurar parametros de red /etc/sysctl.conf, Asegurese de que el Filtrado de ruta inversa esta habilitado"
		varValEnc=$(grep "net.ipv4.conf.all.rp_filter" /etc/sysctl.conf | tr -d " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 4.2.15
	#------------------------------------------		
	
	
	#------------------------------------------
	# [INICIO] iTEM 4.2.16
		varItem="4.2.16"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="net.ipv4.tcp_syncookies=1"
		varDetalle="ITEM $varItem Configurar parametros de red /etc/sysctl.conf,Asegurese de que TCP SYN Cookies esta habilitado"
		varValEnc=$(grep "net.ipv4.tcp_syncookies" /etc/sysctl.conf | tr -d " " | tail -1)
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 4.2.16
	#------------------------------------------		


	#------------------------------------------
	# [INICIO] iTEM 5.1.1
		varItem="5.1.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar System Accounting auditd este instalado"
		varValEsp="auditd.service enabled"
		varService=auditd.service
		varValEnc=$(systemctl list-unit-files --type service --all | grep "$varService" | tr -s " " | awk '{print  $1, $2}')	
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 5.1.1
	#------------------------------------------	
	
	
	#------------------------------------------
	# [INICIO] iTEM 5.2.1
		varItem="5.2.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Medio"
		varDetalle="ITEM $varItem Validar que rsyslog este instalado"
		varValEsp="rsyslog \"OR\" syslog-ng"
		varService=rsyslog
		varExistService=$(rpm -q rsyslog | awk -F"." '{print $1}' || rpm -q rsyslog-ng | awk -F"." '{print $1}')	
		if [[ ${#varExistService} -gt 1 ]]; then		 
			varCumplimiento="Cumple"
			varValEnc="$varExistService"
			varObservaciones="Ninguna"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 5.2.1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 5.2.2
		varItem="5.2.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Medio"
		varValEsp="enabled"
		varDetalle="ITEM $varItem Habilitar y configurar rsyslog"
		varValEnc=$(systemctl is-enabled rsyslog.service)
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 5.2.2
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 5.2.3
		varItem="5.2.3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Medio"
		varValEsp="*.debug @10.70.72.56"
		varDetalle="ITEM $varItem Asegurese de que rsyslog esta configurado para enviar registros a un host de registro remoto *.debug"
		varValEnc=$(grep "^*.debug" /etc/rsyslog.conf | awk '{print $1, $2}' | tail -1)
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 5.2.3
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 5.2.4
		varItem="5.2.4"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Medio"
		varValEsp="does not apply"
		varDetalle="ITEM $varItem Habilitar y configurar syslog-ng"
		varValEnc=$(systemctl is-enabled syslog-ng)
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="does not apply"
		else
			varCumplimiento="Cumple"
			varObservaciones="does not apply"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="does not apply"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 5.2.4
	#------------------------------------------


	#---------------------------------------
	# [INICIO] iTEM 6.1.1
		varItem="6.1.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="Not exist file"
		varPath=/etc/cron.deny
		varDetalle="ITEM $varItem Restringir el acceso a los archivos cron. Validar que no existan los archivos /etc/cron.deny"
		[ -f $varPath ]
		if [[ $? -eq 1 ]]; then		 
			varCumplimiento="Cumple"
			varValEnc="Not exist"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			varValEnc=$(ls -l $varPath | awk '{print $NF}')

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.1.1
	#------------------------------------------


	#---------------------------------------
	# [INICIO] iTEM 6.1.2
		varItem="6.1.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="No Existe"
		varPath=/etc/at.deny
		varDetalle="ITEM $varItem Restringir el acceso a los archivos cron. Validar que no existan los archivos /etc/at.deny"
		[ -f $varPath ]
		if [[ $? -eq 1 ]]; then		 
			varCumplimiento="Cumple"
			varValEnc="Not exist"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			varValEnc=$(ls -l $varPath)

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.1.2
	#-----------------------------------------


	#---------------------------------------
	# [INICIO] iTEM 6.1.3
		varItem="6.1.3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="(0600/-rw-------)"
		varPath=/etc/cron.allow
		varDetalle="ITEM $varItem Validar los permisos con los que fueron creados el archivo $varPath"
		[ -f $varPath ]
		if [[ $? -eq 1 ]]; then		 
			varCumplimiento="No Cumple"
			varValEnc="No existe"
			varObservaciones="Error"
		else
			varValEnc=$(stat $varPath | grep -E "Acces.*Uid" | awk '{print $2}')
			if [[ $varValEsp = $varValEnc ]]; then
				varCumplimiento="Cumple"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				if [[ $varValEnc = "" ]]; then 
					varValEnc="S/D"	
				fi
			fi

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.1.3
	#-----------------------------------------
	
	
	#-----------------------------------------
	# [INICIO] iTEM 6.1.4
		varItem="6.1.4"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="root root"
		varPath=/etc/cron.allow
		varDetalle="ITEM $varItem Validar el propietario y grupo del archivo $varPath, $varValEsp"	
		varValEnc=$(ls -la /etc/cron.allow | awk '{print $3, $4}')
		if [[ $varValEsp = $varValEnc ]]; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi

		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.1.4
	#-----------------------------------------

	
	#-----------------------------------------
	# [INICIO] iTEM 6.1.5
		varItem="6.1.5"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="(0600/-rw-------)"
		varPath=/etc/at.allow
		varDetalle="ITEM $varItem Validar los permisos con los que fueron creados el archivo $varPath"
		[ -f $varPath ]
		if [[ $? -eq 1 ]]; then		 
			varCumplimiento="No Cumple"
			varValEnc="No existe"
			varObservaciones="Error"
		else
			varValEnc=$(stat $varPath | grep -E "Acces.*Uid" | awk '{print $2}')
			if [[ $varValEsp = $varValEnc ]]; then
				varCumplimiento="Cumple"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				if [[ $varValEnc = "" ]]; then 
					varValEnc="S/D"	
				fi
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.1.5
	#-----------------------------------------

	
	#-----------------------------------------
	# [INICIO] iTEM 6.1.6
		varItem="6.1.6"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="root root"
		varPath=/etc/at.allow
		varDetalle="ITEM $varItem Validar el propietario y grupo del archivo $varPath, $varValEsp"	
		varValEnc=$(ls -la /etc/at.allow | awk '{print $3, $4}')
		if [[ $varValEsp = $varValEnc ]]; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.1.6
	#-----------------------------------------
	
	
	#-----------------------------------------
	# [INICIO] iTEM 6.2.1
		varItem="6.2.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="no"
		varParm="PermitRootLogin"
		varPath=/etc/ssh/sshd_config
		varDetalle="ITEM $varItem Deshabilite el inicio de sesion de root directo mediante SSH $varPath, $varParm"	
		varValEnc=$(cat $varPath | grep ^$varParm | tail -1 | awk '{print $2}')
		if [[ ($varValEnc = "yes") || ($varValEnc = "no") ]]; then
			varCumplimiento="Cumple"
			varObservaciones="Justificado Cybeark"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.2.1
	#-----------------------------------------


	#-----------------------------------------
	# [INICIO] iTEM 6.2.2
		varItem="6.2.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="yes"
		varParm="UsePrivilegeSeparation"
		varPath=/etc/ssh/sshd_config
		varDetalle="ITEM $varItem Validar que este habilitada la separacion de privilegios donde el demonio se divide en dos partes SSH $varPath, $varParm"	
		varValEnc=$(cat $varPath | grep ^$varParm | tail -1 | awk '{print $2}')
		if [[ ($varValEnc = $varValEsp)]]; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.2.2
	#-----------------------------------------
	
	
	#-----------------------------------------
	# [INICIO] iTEM 6.2.3
		varItem="6.2.3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="2"
		varParm="Protocol"
		varPath=/etc/ssh/sshd_config
		varDetalle="ITEM $varItem Validar que el protocolo SSH se limite a la version $varPath, $varParm"	
		varValEnc=$(cat $varPath | grep ^$varParm | tail -1 | awk '{print $2}')
		if [[ ($varValEnc = $varValEsp )]]; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.2.3
	#-----------------------------------------


	#-----------------------------------------
	# [INICIO] iTEM 6.2.4
		varItem="6.2.4"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="no"
		varParm="PermitEmptyPasswords"
		varPath=/etc/ssh/sshd_config
		varDetalle="ITEM $varItem Validar que no se permita el acceso remoto a las cuentas que tienen una contrasena vacia  $varPath, $varParm"	
		varValEnc=$(cat $varPath | grep ^$varParm | tail -1 | awk '{print $2}')
		if [[ $varValEnc = $varValEsp ]]; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.2.4
	#-----------------------------------------


	#-----------------------------------------
	# [INICIO] iTEM 6.2.5
		varItem="6.2.5"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="LogLevel verbose"
		varParm="verbose"
		varPath=/etc/ssh/sshd_config
		varDetalle="ITEM $varItem Validar que este habilitado el registro para sesiones SSH  $varPath, $varParm"	
		varValEnc=$(cat $varPath | grep $varParm | tail -1)
		if [[ $varValEnc = $varValEsp ]]; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.2.5
	#-----------------------------------------
	
	
	#-----------------------------------------
	# [INICIO] iTEM 6.2.6
		varItem="6.2.6"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="no"
		varParm="AllowTcpForwarding"
		varPath=/etc/ssh/sshd_config
		varDetalle="ITEM $varItem Validar que se evite que SSH configure el puerto TCP  $varPath, $varParm"	
		varValEnc=$(cat $varPath | grep ^$varParm | tail -1 | awk '{print $2}')
		if [[ $varValEnc = $varValEsp ]]; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.2.6
	#-----------------------------------------


	#-----------------------------------------
	# [INICIO] iTEM 6.2.7
		varItem="6.2.7"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="no"
		varParm="X11Forwarding"
		varPath=/etc/ssh/sshd_config
		varDetalle="ITEM $varItem Validar que se evite que SSH configure elreenvio X11  $varPath, $varParm"	
		varValEnc=$(cat $varPath | grep ^$varParm | tail -1 | awk '{print $2}')
		if [[ $varValEnc = $varValEsp ]]; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.2.7
	#-----------------------------------------
	
	
	#-----------------------------------------
	# [INICIO] iTEM 6.2.8
		varItem="6.2.8"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="yes"
		varParm="StrictModes"
		varPath=/etc/ssh/sshd_config
		varDetalle="ITEM $varItem Validar de que la directiva StrictModes este habilitada $varPath, $varParm"	
		varValEnc=$(cat $varPath | grep ^$varParm | tail -1 | awk '{print $2}')
		if [[ $varValEnc = $varValEsp ]]; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.2.8
	#-----------------------------------------
	
	
	#-----------------------------------------
	# [INICIO] iTEM 6.2.9
		varItem="6.2.9"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="yes"
		varParm="IgnoreRhosts"
		varPath=/etc/ssh/sshd_config
		varDetalle="ITEM $varItem Validar que todas las autenticaciones basadas en host esten deshabilitadas $varPath, $varParm"	
		varValEnc=$(cat $varPath | grep ^$varParm | tail -1 | awk '{print $2}')
		if [[ $varValEnc = $varValEsp ]]; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.2.9
	#-----------------------------------------
	

	#-----------------------------------------
	# [INICIO] iTEM 6.2.10
		varItem="6.2.10"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="no"
		varParm="HostbasedAuthentication"
		varPath=/etc/ssh/sshd_config
		varDetalle="ITEM $varItem Validar que todas las autenticaciones basadas en host esten deshabilitadas $varPath, $varParm"	
		varValEnc=$(cat $varPath | grep ^$varParm | tail -1 | awk '{print $2}')
		if [[ $varValEnc = $varValEsp ]]; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.2.10
	#-----------------------------------------
	

	#-----------------------------------------
	# [INICIO] iTEM 6.2.11
		varItem="6.2.11"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="no"
		varParm="RhostsRSAAuthentication"
		varPath=/etc/ssh/sshd_config
		varDetalle="ITEM $varItem Validar que todas las autenticaciones basadas en host esten deshabilitadas $varPath, $varParm"	
		varValEnc=$(cat $varPath | grep ^$varParm | tail -1 | awk '{print $2}')
		if [[ $varValEnc = $varValEsp ]]; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.2.11
	#-----------------------------------------
	

	#-----------------------------------------
	# [INICIO] iTEM 6.2.12
		varItem="6.2.12"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="#Subsystem sftp /usr/libexec/openssh/sftp-server"
		varParm="Subsystem sftp /usr/libexec/openssh/sftp-server"
		varPath=/etc/ssh/sshd_config
		varDetalle="ITEM $varItem Validar que este deshabilitado el sftp $varPath, $varParm"	
		varValEnc=$(cat $varPath | awk '/Subsystem/{print $1, $2, $3}')
		
		if [[ ${#varValEnc} -eq 0 ]]; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="Configuration not exist"
			else
			if [[ $varValEnc = $varParm ]]; then
				varCumplimiento="No Cumple"
				varObservaciones="Error"
			else
				if [[ $varValEnc != $varValEsp ]]; then
					varValEnc="Configuration not exist"
				fi
				
				varCumplimiento="Cumple"
				varObservaciones="Ninguna"
				
			fi
		fi		
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.2.12
	#-----------------------------------------


	#-----------------------------------------
	# [INICIO] iTEM 6.3.1
		varItem="6.3.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="password requisite pam_pwquality.so"
		varPath=/etc/pam.d/password-auth
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados en $varPath"
		varValEnc=$(grep requisite $varPath | grep password | tail -1 | awk '{print $1, $2, $3}')
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.1
	#-----------------------------------------	
	
	
	#-----------------------------------------
	# [INICIO] iTEM 6.3.2
		varItem="6.3.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="retry=3"
		varPath=/etc/pam.d/system-auth
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados try_first_pass retry $varPath"
		varValEnc=$(grep "pam_pwquality.so try_first_pass" $varPath | tr -d "\t" | tr -s " " | grep $varValEsp)
		if [[ $varValEsp = "" ]]; then		  
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		else	
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.2
	#-----------------------------------------	
	
	
	#-----------------------------------------
	# [INICIO] iTEM 6.3.3.1
		varItem="6.3.3.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="auth required pam_env.so"
		varPath=/etc/pam.d/system-auth
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados $varPath"
		varValEnc=$(grep "^auth" $varPath | awk '{print $1, $2, $3}' | grep "$varValEsp")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.3.1
	#-----------------------------------------	

	
	#---------------------------------------
	# [INICIO] iTEM 6.3.3.2
		varItem="6.3.3.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="auth required pam_env.so"
		varPath=/etc/pam.d/password-auth
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados $varPath"
		varValEnc=$(grep "^auth" $varPath | awk '{print $1, $2, $3}' | grep "$varValEsp")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.3.2
	#-----------------------------------------		
	
	
	#---------------------------------------
	# [INICIO] iTEM 6.3.4.1
		varItem="6.3.4.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm="pam_faillock.so preauth silent audit deny=3"
		varValEsp="auth required pam_faillock.so preauth silent audit deny=3"
		varPath=/etc/pam.d/system-auth
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados $varPath "
		varValEnc=$(grep "^auth" $varPath | grep "$varValParm" | tr -d "\t" | tr -s " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.4.1
	#-----------------------------------------
	
	
	#---------------------------------------
	# [INICIO] iTEM 6.3.4.2
		varItem="6.3.4.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm="pam_faillock.so preauth silent audit deny=3"
		varValEsp="auth required pam_faillock.so preauth silent audit deny=3"
		varPath=/etc/pam.d/password-auth
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados $varPath "
		varValEnc=$(grep "^auth" $varPath | grep "$varValParm" | tr -d "\t" | tr -s " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.4.2
	#-----------------------------------------
	
	
	#---------------------------------------
	# [INICIO] iTEM 6.3.5.1
		varItem="6.3.5.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm="pam_unix.so nullok try_first_pass"
		varValEsp="auth sufficient pam_unix.so nullok try_first_pass"
		varPath=/etc/pam.d/system-auth
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados $varPath "
		varValEnc=$(grep "^auth" $varPath | grep "$varValParm" | tr -d "\t" | tr -s " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.5.1
	#-----------------------------------------	
	

	#---------------------------------------
	# [INICIO] iTEM 6.3.5.2
		varItem="6.3.5.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm="pam_unix.so nullok try_first_pass"
		varValEsp="auth sufficient pam_unix.so nullok try_first_pass"
		varPath=/etc/pam.d/password-auth
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados $varPath "
		varValEnc=$(grep "^auth" $varPath | grep "$varValParm" | tr -d "\t" | tr -s " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.5.2
	#-----------------------------------------	

		
	#-----------------------------------------
	# [INICIO] iTEM 6.3.6.1
		varItem="6.3.6.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm="pam_faillock.so authfail audit deny=3"
		varValEsp="auth default=die pam_faillock.so authfail audit deny=3"
		varPath=/etc/pam.d/system-auth
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados $varPath "
		varValEnc=$(grep "\[default=die\]" $varPath | grep "$varValParm" | tr -d "\t" | tr -d "[]" | tr -s " ") 
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.6.1
	#-----------------------------------------	
	

	#-----------------------------------------
	# [INICIO] iTEM 6.3.6.2
		varItem="6.3.6.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm="pam_faillock.so authfail audit deny=3"
		varValEsp="auth default=die pam_faillock.so authfail audit deny=3"
		varPath=/etc/pam.d/password-auth
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados $varPath "
		varValEnc=$(grep "\[default=die\]" $varPath | grep "$varValParm" | tr -d "\t" | tr -d "[]" | tr -s " ") 

		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.6.2
	#-----------------------------------------	
	

	#---------------------------------------   
	# [INICIO] iTEM 6.3.7.1
		varItem="6.3.7.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm="pam_succeed_if.so uid >= 1000 quiet_success"
		varValEsp="auth requisite pam_succeed_if.so uid >= 1000 quiet_success"
		varPath=/etc/pam.d/system-auth
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados $varPath "
		varValEnc=$(grep "^auth" $varPath | grep "$varValParm" | tr -s " ") 
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.7.1
	#-----------------------------------------	
	

	#---------------------------------------	
	# [INICIO] iTEM 6.3.7.2
		varItem="6.3.7.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm="pam_succeed_if.so uid >= 1000 quiet_success"
		varValEsp="auth requisite pam_succeed_if.so uid >= 1000 quiet_success"
		varPath=/etc/pam.d/password-auth
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados $varPath "
		varValEnc=$(grep "^auth" $varPath | grep "$varValParm" | tr -s " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.7.2
	#-----------------------------------------	


	#---------------------------------------   
	# [INICIO] iTEM 6.3.8.1
		varItem="6.3.8.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm="pam_deny.so"
		varValEsp="auth required pam_deny.so"
		varPath=/etc/pam.d/system-auth
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados $varPath "
		varValEnc=$(grep "^auth" $varPath | grep "$varValParm" | tr -s " ") 
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.8.1
	#-----------------------------------------	
	

	#---------------------------------------	
	# [INICIO] iTEM 6.3.8.2
		varItem="6.3.8.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm="pam_deny.so"
		varValEsp="auth required pam_deny.so"
		varPath=/etc/pam.d/password-auth
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados $varPath "
		varValEnc=$(grep "^auth" $varPath | grep "$varValParm" | tr -s " ")

		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.8.2
	#-----------------------------------------	


	#---------------------------------------	
	# [INICIO] iTEM 6.3.9
		varItem="6.3.9"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm=minlen
		varValEsp="minlen=8"
		varPath=/etc/security/pwquality.conf
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados, por lo menos 8 caracteres $varPath "
		varValEnc=$(grep "$varValParm" $varPath | tail -1 | tr -d " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.9
	#-----------------------------------------	


	#---------------------------------------	
	# [INICIO] iTEM 6.3.10
		varItem="6.3.10"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm=minclass
		varValEsp="minclass=4"
		varPath=/etc/security/pwquality.conf
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados, requiere un caracter de cada clase $varPath "
		varValEnc=$(grep "$varValParm" $varPath | tail -1 | tr -d " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.10
	#-----------------------------------------	
	
	
	#---------------------------------------	
	# [INICIO] iTEM 6.3.11
		varItem="6.3.11"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm=dcredit
		varValEsp="dcredit=-1"
		varPath=/etc/security/pwquality.conf
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados, requiere por lo menos un digito $varPath "
		varValEnc=$(grep "$varValParm" $varPath | tail -1 | tr -d " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.11
	#-----------------------------------------		
	
	
	#---------------------------------------	
	# [INICIO] iTEM 6.3.12
		varItem="6.3.12"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm=lcredit
		varValEsp="lcredit=-1"
		varPath=/etc/security/pwquality.conf
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados, requiere por lo menos una letra minuscula $varPath "
		varValEnc=$(grep "$varValParm" $varPath | tail -1 | tr -d " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.12
	#-----------------------------------------	
	
	
	#---------------------------------------	
	# [INICIO] iTEM 6.3.13
		varItem="6.3.13"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm=ocredit
		varValEsp="ocredit=-1"
		varPath=/etc/security/pwquality.conf
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados, requiere por lo menos un caracter especial $varPath "
		varValEnc=$(grep "$varValParm" $varPath | tail -1 | tr -d " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.13
	#-----------------------------------------	
		
	
	#---------------------------------------	
	# [INICIO] iTEM 6.3.14
		varItem="6.3.14"
		varItemStandard=${varItem:0:3}
		varCriticidad="Alto"
		varValParm=ucredit
		varValEsp="ucredit=-1"
		varPath=/etc/security/pwquality.conf
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados, requiere por lo menos una letra mayuscula $varPath "
		varValEnc=$(grep "$varValParm" $varPath | tail -1 | tr -d " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.14
	#-----------------------------------------		
			
	
	#---------------------------------------	
	# [INICIO] iTEM 6.3.15
		varItem="6.3.15"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm=maxsequence
		varValEsp="maxsequence=3"
		varPath=/etc/security/pwquality.conf
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados, maximo de caracteres identicos consecutivos $varPath "
		varValEnc=$(grep "$varValParm" $varPath | tail -1 | tr -d " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.15
	#-----------------------------------------		
	
			
	#---------------------------------------	
	# [INICIO] iTEM 6.3.16
		varItem="6.3.16"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm=maxrepeat
		varValEsp="maxrepeat=3"
		varPath=/etc/security/pwquality.conf
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados, maximo repetido  $varPath "
		varValEnc=$(grep "$varValParm" $varPath | tail -1 | tr -d " ")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.16
	#-----------------------------------------		
	

	#---------------------------------------   
	# [INICIO] iTEM 6.3.17.1
		varItem="6.3.17.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm="remember=12"
		varValEsp="password sufficient pam_unix.so try_first_pass sha512 remember=12"
		varPath=/etc/pam.d/system-auth
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados, configurar la reutilizacion $varPath "
		varValEnc=$(grep $varValParm $varPath | grep "password" | grep "sufficient" | grep "pam_unix.so" | grep "try_first_pass" | grep "sha512" | tr -d "\t" |tr -s " ") 
		if [[ ${#varValEsp} -eq 0 ]]; then	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		
		else				
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.17.1
	#-----------------------------------------	
	

	#---------------------------------------	
	# [INICIO] iTEM 6.3.17.2
		varItem="6.3.17.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm="remember=12"
		varValEsp="password sufficient pam_unix.so sha512 remember=12"
		varPath=/etc/pam.d/password-auth
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados, configurar la reutilizacion $varPath "
		varValEnc=$(grep $varValParm $varPath | grep "password" | grep "sufficient" | grep "pam_unix.so" | grep "sha512" | tr -d "\t" |tr -s " ")

		if [[ ${#varValEsp} -eq 0 ]]; then	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		
		else				
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.17.2
	#-----------------------------------------		


	#---------------------------------------   
	# [INICIO] iTEM 6.3.18.1
		varItem="6.3.18.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm="sha512"
		varValEsp="password sufficient pam_unix.so try_first_pass sha512 remember=12"
		varPath=/etc/pam.d/system-auth
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados, configurar algoritmo de hash sha512 $varPath "
		varValEnc=$(grep $varValParm $varPath | grep "password" | grep "sufficient" | grep "pam_unix.so" | grep "try_first_pass" | grep "remember=12" | tr -d "\t" |tr -s " ") 
		if [[ ${#varValEsp} -eq 0 ]]; then	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		
		else				
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.18.1
	#-----------------------------------------	
	

	#-----------------------------------------	
	# [INICIO] iTEM 6.3.18.2
		varItem="6.3.18.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm="sha512"
		varValEsp="password sufficient pam_unix.so sha512 remember=12"
		varPath=/etc/pam.d/password-auth
		varDetalle="ITEM $varItem Validar que los requisitos de creacion de contrasenas estan configurados, configurar algoritmo de hash sha512 $varPath "
		varValEnc=$(grep $varValParm $varPath | grep "password" | grep "sufficient" | grep "pam_unix.so" | grep "remember=12" | tr -d "\t" |tr -s " ") 
		if [[ ${#varValEsp} -eq 0 ]]; then	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		
		else				
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.3.18.2
	#-----------------------------------------		


	#-----------------------------------------	
	# [INICIO] iTEM 6.4.1
		varItem="6.4.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="root"
		varPath=/etc/group 
		varDetalle="ITEM $varItem Validar los grupos $varValEsp se encuentren en el archivo $varPath"
		varValEnc=$(grep $varValEsp $varPath | awk -F: '{print $1}' | grep "^root$")
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.4.1
	#-----------------------------------------	


	#-----------------------------------------	
	# [INICIO] iTEM 6.4.2
		varItem="6.4.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="ing_adm"
		varPath=/etc/group 
		varDetalle="ITEM $varItem Validar los grupos $varValEsp se encuentren en el archivo $varPath"
		varValEnc=$(grep $varValEsp $varPath | awk -F: '{print $1}')
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.4.2
	#-----------------------------------------	
	
	
	#-----------------------------------------	
	# [INICIO] iTEM 6.4.3
		varItem="6.4.3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="lib_adm"
		varPath=/etc/group 
		varDetalle="ITEM $varItem Validar los grupos $varValEsp se encuentren en el archivo $varPath"
		varValEnc=$(grep $varValEsp $varPath | awk -F: '{print $1}')
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.4.3
	#-----------------------------------------	


	#-----------------------------------------	
	# [INICIO] iTEM 6.4.4
		varItem="6.4.4"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="des_adm"
		varPath=/etc/group 
		varDetalle="ITEM $varItem Validar los grupos $varValEsp se encuentren en el archivo $varPath"
		varValEnc=$(grep $varValEsp $varPath | awk -F: '{print $1}')
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.4.4
	#-----------------------------------------	
	
	
	#-----------------------------------------	
	# [INICIO] iTEM 6.4.5
		varItem="6.4.5"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="ssi_adm"
		varPath=/etc/group 
		varDetalle="ITEM $varItem Validar los grupos $varValEsp se encuentren en el archivo $varPath"
		varValEnc=$(grep $varValEsp $varPath | awk -F: '{print $1}')
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.4.5
	#-----------------------------------------	


	#-----------------------------------------	
	# [INICIO] iTEM 6.4.6
		varItem="6.4.6"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="log_adm"
		varPath=/etc/group 
		varDetalle="ITEM $varItem Validar los grupos $varValEsp se encuentren en el archivo $varPath"
		varValEnc=$(grep $varValEsp $varPath | awk -F: '{print $1}')
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.4.6
	#-----------------------------------------	


	#-----------------------------------------	
	# [INICIO] iTEM 6.4.7
		varItem="6.4.7"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="gen_adm"
		varPath=/etc/group 
		varDetalle="ITEM $varItem Validar los grupos $varValEsp se encuentren en el archivo $varPath"
		varValEnc=$(grep $varValEsp $varPath | awk -F: '{print $1}')
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.4.7
	#-----------------------------------------	
	
	
	#-----------------------------------------	
	# [INICIO] iTEM 6.4.8
		varItem="6.4.8"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="ope_adm"
		varPath=/etc/group 
		varDetalle="ITEM $varItem Validar los grupos $varValEsp se encuentren en el archivo $varPath"
		varValEnc=$(grep $varValEsp $varPath | awk -F: '{print $1}')
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.4.8
	#-----------------------------------------	


	#-----------------------------------------	
	# [INICIO] iTEM 6.4.9
		varItem="6.4.9"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="PASS_MAX_DAYS 30"
		varParm="PASS_MAX_DAYS"
		varPath=/etc/login.defs 
		varDetalle="ITEM $varItem Validar que este definido 30 como el numero maximo de dias que una contrasena es valida $varPath"
		varValEnc=$(grep ^$varParm $varPath | tail -1 | awk '{print $1, $2}')
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.4.9
	#-----------------------------------------	
	
	
	#-----------------------------------------	
	# [INICIO] iTEM 6.4.10
		varItem="6.4.10"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="PASS_MIN_DAYS 1"
		varParm="PASS_MIN_DAYS"
		varPath=/etc/login.defs 
		varDetalle="ITEM $varItem Validar que este definido 1 como el numero minimo de dias antes de que un usuario pueda cambiar la contrasena desde el ultimo cambio $varPath"
		varValEnc=$(grep ^$varParm $varPath | tail -1 | awk '{print $1, $2}')
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.4.10
	#-----------------------------------------	

	
	#-----------------------------------------	
	# [INICIO] iTEM 6.4.11
		varItem="6.4.11"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="PASS_WARN_AGE 7"
		varParm="PASS_WARN_AGE"
		varPath=/etc/login.defs 
		varDetalle="ITEM $varItem Validar que este definido 7 como el numero de dias en que comienza el recordatorio de cambio de contrasena $varPath"
		varValEnc=$(grep ^$varParm $varPath | tail -1 | awk '{print $1, $2}')
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.4.11
	#-----------------------------------------	


	#-----------------------------------------	
	# [INICIO] iTEM 6.4.12
		varItem="6.4.12"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="INACTIVE=30"
		varParm="INACTIVE"
		varPath=/etc/default/useradd
		varDetalle="ITEM $varItem Validar que este definido 30 como el numero de dias despues de la caducidad de la contrasena que la cuenta esta deshabilitada  $varPath"
		varValEnc=$(grep $varParm $varPath | tail -1 | awk '{print $1}')
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.4.12
	#-----------------------------------------	
	
	
	#-----------------------------------------	
	# [INICIO] iTEM 6.4.13
		varItem="6.4.13"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="umask 027"
		varParm="umask"
		varPath=/etc/bashrc 
		varDetalle="ITEM $varItem Validar que el usuario predeterminado posea un umask de 027 en el archivo bashrc $varPath"
		varValEnc=$(grep $varParm $varPath | tail -1 | awk '{print $1, $2}')
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.4.13
	#-----------------------------------------	


	#-----------------------------------------	
	# [INICIO] iTEM 6.4.14
		varItem="6.4.14"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="umask 027"
		varParm="umask"
		varPath=/etc/profile 
		varDetalle="ITEM $varItem Validar que el usuario predeterminado posea un umask de 027 en el archivo bashrc $varPath"
		varValEnc=$(grep $varParm $varPath | tail -1 | awk '{print $1, $2}')
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.4.14
	#-----------------------------------------


	#-----------------------------------------	
	# [INICIO] iTEM 6.4.15
		varItem="6.4.15"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="auth required pam_wheel.so use_uid"
		varParm="required"
		varPath=/etc/pam.d/su
		varDetalle="ITEM $varItem Validar que el acceso al comando su esta restringido $varPath"
		varValEnc=$(grep $varParm $varPath | grep "auth" | grep "pam_wheel.so" | grep "use_uid" | tr -d "\t" | tr -s " " | tail -1)
		if [[ ${#varValEsp} -eq 0 ]]; then	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
				
		else

			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.4.15
	#-----------------------------------------


	#-----------------------------------------	
	# [INICIO] iTEM 6.4.16
		varItem="6.4.16"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="auth required pam_wheel.so use_uid"
		varParm="wheel"
		varPath=/etc/group
		varDetalle="ITEM $varItem Validar que este creada una lista separada por comas de usuarios en la instruccion $varParm del archivo $varPath"
		varValEnc=$(grep $varParm $varPath | awk -F"," '{print $2}')
		if [[ ${#varValEnc} -eq 0 ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Validacion con diseno, utilizado por cyberarck"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="Utilizado por cyberarck"	
			fi
		else	
			varCumplimiento="Cumple"
			varObservaciones="Validacion con diseno, utilizado por cyberarck"
			
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.4.16
	#-----------------------------------------


	#-----------------------------------------	
	# [INICIO] iTEM 6.4.17
		varItem="6.4.17"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="ttyS0"
		varParm="ttyS0"
		varPath=/etc/securetty
		varDetalle="ITEM $varItem Validar que el inicio de sesion raiz esta restringido a la consola del sistema $varPath"
		varValEnc=$(grep $varParm $varPath | tail -1)
		if [[ $varValEnc = $varValEsp ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
			
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.4.17
	#-----------------------------------------


	#-----------------------------------------	
	# [INICIO] iTEM 6.4.18
		varItem="6.4.18"
		varItemStandard=${varItem:0:3}
		varCriticidad="Alto"
		varValEsp="ttyS1"
		varParm="ttyS1"
		varPath=/etc/securetty
		varDetalle="ITEM $varItem Validar que el inicio de sesion raiz esta restringido a la consola del sistema $varPath"
		varValEnc=$(grep $varParm $varPath | tail -1)
		if [[ $varValEnc = $varValEsp ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
			
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.4.18
	#-----------------------------------------
	
	
	#-----------------------------------------	
	# [INICIO] iTEM 6.4.19
		varItem="6.4.19"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="Users"
		varParm="nologin|shutdown|halt|sync"
		varPath=/etc/passwd
		varDetalle="ITEM $varItem Los usuarios personalizados deben acceder via cyberark y que ningun usuario personalizado debe existir localmente $varPath"
		varValEnc=($(egrep -v $varParm $varPath | awk -F':' '{print $1}'))
		if [[ ${#varValEnc} -eq 0 ]]; then		 
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		else	
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|${varValEnc[@]}|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|${varValEnc[@]} --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 6.4.19
	#-----------------------------------------


	#-----------------------------------------	
	# [INICIO] iTEM 7.1.1
		varItem="7.1.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm=root
		varValEsp="root"
		varPath=/etc/passwd
		varDetalle="ITEM $varItem Verificar que tenga como propietario root $varPath "
		varValEnc=$(ls -l "$varPath" | awk '{print $3}')
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 7.1.1
	#-----------------------------------------		
	
		
	#-----------------------------------------	
	# [INICIO] iTEM 7.1.2
		varItem="7.1.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm=root
		varValEsp="root"
		varPath=/etc/shadow
		varDetalle="ITEM $varItem Verificar que tenga como propietario root $varPath "
		varValEnc=$(ls -l "$varPath" | awk '{print $3}')
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 7.1.2
	#-----------------------------------------	

	
	#---------------------------------------	
	# [INICIO] iTEM 7.1.3
		varItem="7.1.3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValParm=root
		varValEsp="root"
		varPath=/etc/group
		varDetalle="ITEM $varItem Verificar que tenga como propietario root $varPath "
		varValEnc=$(ls -l "$varPath" | awk '{print $3}')
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 7.1.3
	#-----------------------------------------	

		
	#-----------------------------------------	
	# [INICIO] iTEM 7.1.4
		varItem="7.1.4"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="644"
		varPath=/etc/passwd
		varDetalle="ITEM $varItem Verificar que los permisos sobre sean 644 $varPath"
		varValEnc=$(stat -c '%a' $varPath)
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 7.1.4
	#-----------------------------------------	
	
		
	#-----------------------------------------	
	# [INICIO] iTEM 7.1.5
		varItem="7.1.5"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="644"
		varPath=/etc/group
		varDetalle="ITEM $varItem Verificar que los permisos sobre sean 644 $varPath"
		varValEnc=$(stat -c '%a' $varPath)
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 7.1.5
	#-----------------------------------------	


	#-----------------------------------------	
	# [INICIO] iTEM 7.1.6
		varItem="7.1.6"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="0"
		varPath=/etc/shadow
		varDetalle="ITEM $varItem Verificar que los permisos sobre sean 000 $varPath"
		varValEnc=$(stat -c '%a' $varPath)
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 7.1.6
	#-----------------------------------------		
	
	
	#---------------------------------------	
	# [INICIO] iTEM 7.1.7
		varItem="7.1.7"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="Total Archivos 0"
		varPath=/
		varDetalle="ITEM $varItem Asegurese de que no existen archivos disponibles para todo el mundo  permisos 0002  $varPath"
		varValEnc=$(df --local -P | awk '{if(NR!=1) print $6}' | xargs -I ARG find ARG -xdev -type f -perm -0002 2>/dev/null | wc -l)
		varValEnc="Total Archivos $varValEnc"
		if [[ $varValEnc = $varValEsp ]]; then		 
			varCumplimiento="Cumple"

			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 7.1.7
	#-----------------------------------------	


	#---------------------------------------	
	# [INICIO] iTEM 7.1.8
		varItem="7.1.8"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="Total Archivos 0"
		varPath=/
		varDetalle="ITEM $varItem Asegurese de que no existen archivos disponibles para todo el mundo -nouser $varPath"
		varValEnc=$(df --local -P | awk '{if(NR!=1) print $6}' | xargs -I ARG find ARG -xdev -nouser 2>/dev/null | wc -l)
		varValEnc="Total Archivos $varValEnc"
		if [[ $varValEnc = $varValEsp ]]; then		 
			varCumplimiento="Cumple"

			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 7.1.8
	#-----------------------------------------	
	
	
	#---------------------------------------	
	# [INICIO] iTEM 7.1.9
		varItem="7.1.9"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="Total Archivos 0"
		varPath=/
		varDetalle="ITEM $varItem Asegurese de que no existen archivos disponibles para todo el mundo -nogroup $varPath"
		varValEnc=$(df --local -P | awk '{if(NR!=1) print $6}' | xargs -I ARG find ARG -xdev -nogroup 2>/dev/null | wc -l)
		varValEnc="Total Archivos $varValEnc"
		if [[ $varValEnc = $varValEsp ]]; then		 
			varCumplimiento="Cumple"

			varObservaciones="Ninguna"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 7.1.9
	#-----------------------------------------	
	
	
	#-----------------------------------------	
	# [INICIO] iTEM 7.2.1
		varItem="7.2.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="Users"
		varParm="+:"
		varPath=/etc/passwd
		varDetalle="ITEM $varItem Validar que no existan entradas $varParm heredadas en $varPath"
		varValEnc=$(grep ^$varParm $varPath)
		if [[ ${#varValEnc} -eq 0 ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="No found"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi			
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 7.2.1
	#-----------------------------------------
	
	
	
	#-----------------------------------------	
	# [INICIO] iTEM 7.2.2
		varItem="7.2.2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="Password"
		varParm="+:"
		varPath=/etc/shadow
		varDetalle="ITEM $varItem Validar que no existan entradas $varParm heredadas en $varPath"
		varValEnc=$(grep ^$varParm $varPath)
		if [[ ${#varValEnc} -eq 0 ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="No found"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi			
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 7.2.2
	#-----------------------------------------
	
	
		#-----------------------------------------	
	# [INICIO] iTEM 7.2.3
		varItem="7.2.3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="Groups"
		varParm="+:"
		varPath=/etc/group
		varDetalle="ITEM $varItem Validar que no existan entradas $varParm heredadas en $varPath"
		varValEnc=$(grep ^$varParm $varPath)
		if [[ ${#varValEnc} -eq 0 ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="No found"
		else	
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi			
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 7.2.3
	#-----------------------------------------
		

	
	
	
echo -e "\n"		
[ -f "$constPathClbRH/CLB_$constServer.$oMonth.csv" ]
if [ $? -eq 0 ]; then
	echo -e "\e[1;32m 	[*] El archivo CLB fue creado de maneara satisfactoria \e[0m" "\e[32m \t $constPathClbRH/CLB_$constServer.$oMonth.csv \e[0m"
else
	echo -e "\e[1;31m 	[*] No se pudo crear el archivo CLB \e[0m" "\e[31m \t $constPathClbRH/CLB_$constServer.$oMonth.csv \e[0m"
	echo -e "\e[31m 	[*] Error al ejecutasr el control de linea base \e[0m"
fi

echo -e "\n"	 
echo -e "\e[33m[FIN PROCESO] - $dateTime \e[0m"
echo -e "\n"