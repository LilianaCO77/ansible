# Scritp de control de linea base para Red Hat 8
# CREADO POR: 		ALEXANDER GONZALEZ
# AUTORIZADO POR: 	GUSTAVO URQUIETA

clear

# --------------------------------------
# VARIABLES LOCALES DE ENTORNO
# --------------------------------------
dateTime=$(date "+%Y-%m-%d %H:%M:%S")
oDate=$(date "+%Y-%m-%d")
oMonth=$(date "+-%m%Y")
constPathTmp=/tmp
constPathClbRH=$constPathTmp/ClbUnix/RHEL
#constPathClbRH=$constPathTmp
constServer=$(hostname | cut -d "." -f 1)
constVersion="Red Hat 6"
constIP=$(hostname -I | cut -d " " -f 1)
constHeader="Fecha|Server|Version|IP|Item|Item_Standar|Criticidad|Detalle|Valor_Esperado|Valor_Encontrado|Cumplimiento|Observaciones"

varValEsp=""
varValEnc=""
varCumplimiento=""
varItem=""
varItemStandard=""
varItemReg=""
varCriticidad=""
varAuditLog=""
varObservaciones=""

echo "Fecha_Hora|Servidor|Item|Valor_Encontrado" > $constPathClbRH/LOG_$constServer.$oMonth.log
echo > $constPathClbRH/CLB_$constServer.$oMonth.csv
# --------------------------------------
# MAIN: SHELL PRINCIPAL
# --------------------------------------
echo -e "\n"
echo -e "\e[33m[INICIO PROCESO] - $dateTime \e[0m"
echo -e "\n"
	[ -d "$constPathClbRH" ]
	if [ $? -eq 0 ]; then
		echo -e "\e[1;32m 	[*] Ruta encontrada \e[0m" "\e[32m \t $constPathClbRH \e[0m"
	else
		echo -e "\e[1;31m 	[*] Ruta no encontrada \e[0m" "\e[31m \t $constPathClbRH \e[0m"
		echo -e "\e[1;33m 	[*] Creando la ruta \e[0m" "\e[33m \t $constPathClbRH \e[0m"
		mkdir /tmp/ClbUnix/RHEL -p
		echo -e "\e[1;32m 	[*] La ruta ha sido creada correctamente \e[0m" "\e[32m \t $constPathClbRH \e[0m"
		
	fi
	echo -e "\n"
	echo -e "\n $constHeader"
	echo $constHeader > $constPathClbRH/CLB_$constServer.$oMonth.csv

	#------------------------------------------
	# [INICIO] iTEM 0.0.0
		varItem="0.0.0"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Validar que este instalado la proteccion antimalware"
		varValEsp="falcond is running"
		varValEnc=$(service falcon-sensor status | awk '{print $1, $4 ,$5}' | tr -d ".")
		if [[ $varValEsp = $varValEnc ]] ; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]] ; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 0.0.0 
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.1.1-1
		varItem="1.1.1-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard="${varItem:0:3}"
		fi
		varCriticidad="Medio"
		varDetalle="ITEM $varItem Validacion de particiones filesystems, particion raiz /"
		varValEsp="/"
		varValEnc=$(df -lh | awk '{print $NF}' | grep "^/$")
		if [[ $varValEsp = $varValEnc ]] ; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]] ; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.1.1-1 
	#------------------------------------------
	

	#------------------------------------------
	# [INICIO] iTEM 1.1.1-2
		varItem="1.1.1-2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard="${varItem:0:3}"
		fi
		varCriticidad="Medio"
		varDetalle="ITEM $varItem Validacion de particiones filesystems, particion /boot"
		varValEsp="/boot"
		varValEnc=$(df -lh | awk '{print $NF}' | grep "^/boot$")
		if [[ $varValEsp = $varValEnc ]] ; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]] ; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.1.1-2 
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.1.1-3
		varItem="1.1.1-3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard="${varItem:0:3}"
		fi
		varCriticidad="Medio"
		varDetalle="ITEM $varItem Validacion de particiones filesystems, particion /home"
		varValEsp="/home"
		varValEnc=$(df -lh | awk '{print $NF}' | grep "^/home$")
		if [[ $varValEsp = $varValEnc ]] ; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]] ; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.1.1-3 
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.1.1-4
		varItem="1.1.1-4"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard="${varItem:0:3}"
		fi
		varCriticidad="Medio"
		varDetalle="ITEM $varItem Validacion de particiones filesystems, particion /var"
		varValEsp="/var"
		varValEnc=$(df -lh | awk '{print $NF}' | grep "^/var$")
		if [[ $varValEsp = $varValEnc ]] ; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]] ; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.1.1-4 
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.1.1-5
		varItem="1.1.1-5"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard="${varItem:0:3}"
		fi
		varCriticidad="Medio"
		varDetalle="ITEM $varItem Validacion de particiones filesystems, particion /usr"
		varValEsp="/usr"
		varValEnc=$(df -lh | awk '{print $NF}' | grep "^/usr$")
		if [[ $varValEsp = $varValEnc ]] ; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]] ; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.1.1-5 
	#------------------------------------------



	#------------------------------------------
	# [INICIO] iTEM 1.1.1-6
		varItem="1.1.1-6"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard="${varItem:0:3}"
		fi
		varCriticidad="Medio"
		varDetalle="ITEM $varItem Validacion de particiones filesystems, particion /tmp"
		varValEsp="/tmp"
		varValEnc=$(df -lh | awk '{print $NF}' | grep "^/tmp$")
		if [[ $varValEsp = $varValEnc ]] ; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]] ; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.1.1-6 
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.1.2-1
		varPart=/tmp
		varItem="1.1.2-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Medio"
		varDetalle="ITEM $varItem Validacion de opciones de montaje noexec, nosuid y nodev en la particion $varPart"
		varValEsp=(nosuid nodev noexec)
		varQuery=($(grep $varPart /etc/fstab | awk '{print $4,$2}' | grep $varPart$))
		varQueryPart=${varQuery[1]}
		varQueryMount=($(echo ${varQuery[0]} | awk -F"," '{print $1, $2, $3}' ))
		varCont=0
		for i in ${varValEsp[*]}; do
			if [[ $i = ${varQueryMount[0]} ]] ; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQueryMount[1]} ]] ; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQueryMount[2]} ]] ; then
				varCont=$((varCont+1))
			fi
		done
		varValEnc="$varQueryPart --- ${varQueryMount[*]}"
		if [[ $varQueryPart = $varPart && $varCont -eq 3 ]] ; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]] ; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|${varValEsp[*]}|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.1.2-1 
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.1.2-2
		varPart=/var
		varItem="1.1.2-2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Medio"
		varDetalle="ITEM $varItem Validacion de opciones de montaje noexec, nosuid y nodev en la particion $varPart"
		varValEsp=(nosuid nodev noexec)
		varQuery=($(grep $varPart /etc/fstab | awk '{print $4,$2}' | grep $varPart$))
		varQueryPart=${varQuery[1]}
		varQueryMount=($(echo ${varQuery[0]} | awk -F"," '{print $1, $2, $3}' ))
		varCont=0
		for i in ${varValEsp[*]}; do
			if [[ $i = ${varQueryMount[0]} ]] ; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQueryMount[1]} ]] ; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQueryMount[2]} ]] ; then
				varCont=$((varCont+1))
			fi
		done
		varValEnc="$varQueryPart --- ${varQueryMount[*]}"
		if [[ $varQueryPart = $varPart && $varCont -eq 3 ]] ; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]] ; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|${varValEsp[*]}|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.1.2-2 
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.1.2-3
		varPart=/home
		varItem="1.1.2-3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Medio"
		varDetalle="ITEM $varItem Validacion de opciones de montaje noexec, nosuid y nodev en la particion $varPart"
		varValEsp=(nosuid nodev)
		varQuery=($(grep $varPart /etc/fstab | awk '{print $4,$2}' | grep $varPart$))
		varQueryPart=${varQuery[1]}
		varQueryMount=($(echo ${varQuery[0]} | awk -F"," '{print $1, $2, $3}' ))
		varCont=0
		for i in ${varValEsp[*]}; do
			if [[ $i = ${varQueryMount[0]} ]] ; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQueryMount[1]} ]] ; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQueryMount[2]} ]] ; then
				varCont=$((varCont+1))
			fi

		done
		varValEnc="$varQueryPart --- ${varQueryMount[*]}"
		if [[ $varQueryPart = $varPart && $varCont -eq 2 ]] ; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]] ; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|${varValEsp[*]}|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.1.2-3 
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.1.2-4
		varPart=/usr
		varItem="1.1.2-4"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Medio"
		varDetalle="ITEM $varItem Validacion de opciones de montaje noexec, nosuid y nodev en la particion $varPart"
		varValEsp=(nodev)
		varQuery=($(grep $varPart /etc/fstab | awk '{print $4,$2}' | grep $varPart$))
		varQueryPart=${varQuery[1]}
		varQueryMount=($(echo ${varQuery[0]} | awk -F"," '{print $1, $2, $3}' ))
		varCont=0
		for i in ${varValEsp[*]}; do
			if [[ $i = ${varQueryMount[0]} ]] ; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQueryMount[1]} ]] ; then
				varCont=$((varCont+1))
			fi
			if [[ $i = ${varQueryMount[2]} ]] ; then
				varCont=$((varCont+1))
			fi
		
		done
		varValEnc="$varQueryPart --- ${varQueryMount[*]}"
		if [[ $varQueryPart = $varPart && $varCont -eq 1 ]] ; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]] ; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|${varValEsp[*]}|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.1.2-4 
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.2.1
		varItem="1.2.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varValEsp="plugin-sec"
		varDetalle="ITEM $varItem Validacion de las ultimas actualizaciones instaladas"
		varValEnc=($( rpm -qa --last | grep plugin-sec | grep "2020" | wc -l))
		if [[ $varValEnc -eq 1 ]] ; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]] ; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.2.1
	#------------------------------------------

	
	#------------------------------------------
	# [INICIO] iTEM 1.3.1
		varItem="1.3.1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varPath= /etc/grub.conf
		varDetalle="ITEM $varItem Sistema de Arranque, asegurese de que solo se utilice GRUB como cargador de arranque $varPath"
		varValEsp="password=md5 \"generatedpassword\""
		varValEnc=$(cat /etc/grub.conf | awk '/password=md5/{print $1, $2}')	
		if [[ $varValEnc = "" ]] ; then		 
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			varObservaciones="Not Configurated"

		else		
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="Configurated Correctly"
			
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.3.1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.4.1-1
		varItem="1.4.1-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="xinetd"
		varDetalle="ITEM $varItem Cierre de puertos de red y deshabilitacion de varService"
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.1-1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.4.2-1
		varItem="1.4.2-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="amanda"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.4.2-2
		varItem="1.4.2-2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="amandaidx"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-2
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.4.2-3
		varItem="1.4.2-3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="amidxtape"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-3
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.4.2-4
		varItem="1.4.2-4"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="auth"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-4
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.4.2-5
		varItem="1.4.2-5"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="chargen-dgram"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-5
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.4.2-6
		varItem="1.4.2-6"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="chargen-stream"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-6
	#------------------------------------------

	#------------------------------------------
	# [INICIO] iTEM 1.4.2-7
		varItem="1.4.2-7"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="cvs"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-7
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.4.2-8
		varItem="1.4.2-8"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="daytime-dgram"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-8
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.4.2-9
		varItem="1.4.2-9"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="daytime-stream"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-9
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.4.2-10
		varItem="1.4.2-10"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="discard-dgram"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-10
	#------------------------------------------

	#------------------------------------------
	# [INICIO] iTEM 1.4.2-11
		varItem="1.4.2-11"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="discard-stream"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-11
	#------------------------------------------

	#------------------------------------------
	# [INICIO] iTEM 1.4.2-12
		varItem="1.4.2-12"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="echo-dgram"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-12
	#------------------------------------------

	#------------------------------------------
	# [INICIO] iTEM 1.4.2-13
		varItem="1.4.2-13"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="echo-stream"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-13
	#------------------------------------------

	#------------------------------------------
	# [INICIO] iTEM 1.4.2-14
		varItem="1.4.2-14"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="eklogin"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-14
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.4.2-15
		varItem="1.4.2-15"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="ekrb5-telnet"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-15
	#------------------------------------------

	#------------------------------------------
	# [INICIO] iTEM 1.4.2-16
		varItem="1.4.2-16"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="gssftp"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-16
	#------------------------------------------

	#------------------------------------------
	# [INICIO] iTEM 1.4.2-17
		varItem="1.4.2-17"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="klogin"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-17
	#------------------------------------------

	#------------------------------------------
	# [INICIO] iTEM 1.4.2-18
		varItem="1.4.2-18"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="krb5-telnet"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-18
	#------------------------------------------

	#------------------------------------------
	# [INICIO] iTEM 1.4.2-19
		varItem="1.4.2-19"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="kshell"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-19
	#------------------------------------------

	#------------------------------------------
	# [INICIO] iTEM 1.4.2-20
		varItem="1.4.2-20"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="ktalk"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-20
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.4.2-21
		varItem="1.4.2-21"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="ntalk"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-21
	#------------------------------------------

	#------------------------------------------
	# [INICIO] iTEM 1.4.2-22
		varItem="1.4.2-22"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="rexec"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-22
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.4.2-23
		varItem="1.4.2-23"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="rlogin"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-23
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.4.2-24
		varItem="1.4.2-24"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="rsh"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-24
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.4.2-25
		varItem="1.4.2-25"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="rsync"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-25
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.4.2-26
		varItem="1.4.2-26"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="talk"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-26
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.4.2-27
		varItem="1.4.2-27"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="tcpmux"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-27
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.4.2-28
		varItem="1.4.2-28"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="telnet"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-28
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.4.2-29
		varItem="1.4.2-29"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="tftp"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-29
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.4.2-30
		varItem="1.4.2-30"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="time-dgram"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-30
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.4.2-31
		varItem="1.4.2-31"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="time-stream"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-31
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.4.2-32
		varItem="1.4.2-32"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="uucp"
		varDetalle="ITEM $varItem Cierre de puertos de red, el servicio $varService debe estar deshabilitado "
		varValEsp="$varService 0:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$2}')
		if [[ $varValEnc = "$varService 0:on" ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.4.2-32
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-1
		varItem="1.5.1-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="acpid"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-2
		varItem="1.5.1-2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="amd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-2
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-3
		varItem="1.5.1-3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="apmd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-3
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-4
		varItem="1.5.1-4"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="arptables_jf"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-4
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-5
		varItem="1.5.1-5"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="arpwatch"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-5
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-6
		varItem="1.5.1-6"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="atd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-6
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-7
		varItem="1.5.1-7"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="autofs"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-7
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-8
		varItem="1.5.1-8"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="avahi-daemon"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-8
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-9
		varItem="1.5.1-9"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="avahi-dnsconfd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-9
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-10
		varItem="1.5.1-10"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="bgpd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-10
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-11
		varItem="1.5.1-11"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="bluetooth"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-11
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-12
		varItem="1.5.1-12"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="bootparamd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-12
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-13
		varItem="1.5.1-13"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="capi"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-13
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-14
		varItem="1.5.1-14"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="conman"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-14
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-15
		varItem="1.5.1-15"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="cpuspeed"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-15
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-16
		varItem="1.5.1-16"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="cups"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-16
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-17
		varItem="1.5.1-17"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="cyrus-imapd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-17
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-18
		varItem="1.5.1-18"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="dc_client"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-18
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-19
		varItem="1.5.1-19"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="dc_server"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-19
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-20
		varItem="1.5.1-20"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="dhcdbd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-20
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-21
		varItem="1.5.1-21"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="dhcp6s"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-21
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-22
		varItem="1.5.1-22"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="dhcpd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-22
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-23
		varItem="1.5.1-23"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="dhcrelay"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-23
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-24
		varItem="1.5.1-24"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="dovecot"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-24
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-25
		varItem="1.5.1-25"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="dund"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-25
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-26
		varItem="1.5.1-26"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="gpm"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-26
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-27
		varItem="1.5.1-27"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="haldaemon"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-27
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-28
		varItem="1.5.1-28"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="hidd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-28
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-29
		varItem="1.5.1-29"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="hplip"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-29
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-30
		varItem="1.5.1-30"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="httpd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-30
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-31
		varItem="1.5.1-31"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="ibmasm"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-31
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-32
		varItem="1.5.1-32"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="innd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-32
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-33
		varItem="1.5.1-33"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="ip6tables"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-33
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-34
		varItem="1.5.1-34"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="ipmi"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-34
	#------------------------------------------









	#------------------------------------------
	# [INICIO] iTEM 1.5.1-35
		varItem="1.5.1-35"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="iptables"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-35
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-36
		varItem="1.5.1-36"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="irda"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-36
	#------------------------------------------

	
	#------------------------------------------
	# [INICIO] iTEM 1.5.1-37
		varItem="1.5.1-37"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="isdn"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-37
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-38
		varItem="1.5.1-38"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="kadmin"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-38
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-39
		varItem="1.5.1-39"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="kdump"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-39
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-40
		varItem="1.5.1-40"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="kprop"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-40
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-41
		varItem="1.5.1-41"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="krb524"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-41
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-42
		varItem="1.5.1-42"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="krb5kdc"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-42
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-43
		varItem="1.5.1-43"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="kudzu"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-43
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-44
		varItem="1.5.1-44"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="ldap"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-44
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-45
		varItem="1.5.1-45"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="lisa"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-45
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-46
		varItem="1.5.1-46"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="lm_sensors"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-46
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-47
		varItem="1.5.1-47"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="mailman"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-47
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-48
		varItem="1.5.1-48"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="mcstrans"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-48
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-49
		varItem="1.5.1-49"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="mdmonitor"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-49
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-50
		varItem="1.5.1-50"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="mdmpd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-50
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-51
		varItem="1.5.1-51"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="multipathd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-51
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-52
		varItem="1.5.1-52"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="mysqld"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-52
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-53
		varItem="1.5.1-53"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="named"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-53
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-54
		varItem="1.5.1-54"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="netfs"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-54
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-55
		varItem="1.5.1-55"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="netplugd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-55
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-56
		varItem="1.5.1-56"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="networkmanager"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-56
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-57
		varItem="1.5.1-57"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="nfs"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-57
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-58
		varItem="1.5.1-58"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="nfslock"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-58
	#------------------------------------------



		#------------------------------------------
	# [INICIO] iTEM 1.5.1-59
		varItem="1.5.1-59"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="nscd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-59
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-60
		varItem="1.5.1-60"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="openibd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-60
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-61
		varItem="1.5.1-61"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="ospf6d"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-61
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-62
		varItem="1.5.1-62"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="ospfd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-62
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-63
		varItem="1.5.1-63"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="pand"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-63
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-64
		varItem="1.5.1-64"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="pcscd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-64
	#------------------------------------------
	
	
	#------------------------------------------
	# [INICIO] iTEM 1.5.1-65
		varItem="1.5.1-65"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="portmap"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-65
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-66
		varItem="1.5.1-66"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="postfix"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-66
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-67
		varItem="1.5.1-67"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="postgresql"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-67
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-68
		varItem="1.5.1-68"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="privoxy"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-68
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-69
		varItem="1.5.1-69"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="psacct"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-69
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-70
		varItem="1.5.1-70"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="radiusd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-70
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-71
		varItem="1.5.1-71"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="radvd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-71
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-72
		varItem="1.5.1-72"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="rarpd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-72
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-73
		varItem="1.5.1-73"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="rdisc"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-73
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-74
		varItem="1.5.1-74"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="readahead_early"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-74
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-75
		varItem="1.5.1-75"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="readahead_later"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-75
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-76
		varItem="1.5.1-76"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="rhnsd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-76
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-77
		varItem="1.5.1-77"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="ripd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-77
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-78
		varItem="1.5.1-78"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="ripngd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-78
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-79
		varItem="1.5.1-79"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="rpcgssd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-79
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-80
		varItem="1.5.1-80"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="rpcidmapd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-80
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-81
		varItem="1.5.1-81"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="rpcsvcgssd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-81
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-82
		varItem="1.5.1-82"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="rstatd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-82
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-83
		varItem="1.5.1-83"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="rusersd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-83
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-84
		varItem="1.5.1-84"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="rwhod"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-84
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-85
		varItem="1.5.1-85"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="saslauthd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-85
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-86
		varItem="1.5.1-86"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="sendmail"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-86
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-87
		varItem="1.5.1-87"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="setroubleshoot"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-87
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-88
		varItem="1.5.1-88"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="smartd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-88
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-89
		varItem="1.5.1-89"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="smb"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-89
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-90
		varItem="1.5.1-90"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="snmpd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-90
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-91
		varItem="1.5.1-91"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="snmptrapd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-91
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-92
		varItem="1.5.1-92"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="spamassassin"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-92
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-93
		varItem="1.5.1-93"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="squid"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-93
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-94
		varItem="1.5.1-94"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="pegasus"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-94
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-95
		varItem="1.5.1-95"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="tomcat5"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-95
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-96
		varItem="1.5.1-96"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="rstatd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-96
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-97
		varItem="1.5.1-97"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="vncserver"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-97
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-98
		varItem="1.5.1-98"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="vsftpd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-98
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-99
		varItem="1.5.1-99"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="winbind"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-99
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-100
		varItem="1.5.1-100"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="wpa_supplicant"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-100
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-101
		varItem="1.5.1-101"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="xend"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-101
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-102
		varItem="1.5.1-102"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="xendomains"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-102
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-103
		varItem="1.5.1-103"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="xfs"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-103
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-104
		varItem="1.5.1-104"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="ypbind"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-104
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-105
		varItem="1.5.1-105"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="yppasswdd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-105
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-106
		varItem="1.5.1-106"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="ypserv"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-106
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-107
		varItem="1.5.1-107"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="ypxfrd"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-107
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.5.1-108
		varItem="1.5.1-108"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varService="zebra"
		varDetalle="ITEM $varItem Minimizar los servicios de arranque, deshabilitar los siguientes servicios en los niveles 3 y 5 $varService"
		varValEsp="$varService 3:off 5:off \"OR\" Not installed"		
		varValEnc=$(chkconfig --list  $varService | awk '{print $1,$5,$7}')
		if [[ ($varValEnc = "$varService 3:on 5:off") ||  ($varValEnc = "$varService 3:off 5:on") ||  ($varValEnc = "$varService 3:on 5:on") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="$varService Not installed"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.5.1-108
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.6.1-1
		varItem="1.6.1-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Revision de arranque e Inittab, El nivel de ejecucion predeterminado debe establecerse en 3"
		varValEsp="id:3:initdefault"		
		varValEnc=$( cat /etc/inittab | grep initdefault | grep -v "^#" | grep "^id" | awk -F":" '{print $1":"$2":"$3 }')
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.6.1-1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.7.1-1
		varItem="1.7.1-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Restriccion del acceso al sistema XINETD"
		varValEsp="Does not apply"		
		varValEnc="Does not apply"
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Controlado por Firewall"
		else		
			
			varCumplimiento="Cumple"
			varObservaciones="Controlado por Firewall"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.7.1-1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.8.1-1
		varItem="1.8.1-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Habilitacion de IPTABLES, Proteccion de firewall basada en host con iptables"
		varValEsp="Does not apply"		
		varValEnc="Does not apply"
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Controlado por Firewall"
		else		
			
			varCumplimiento="Cumple"
			varObservaciones="Controlado por Firewall"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.8.1-1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.9.1-1
		varItem="1.9.1-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="PermitRootLogin"
		varDetalle="ITEM $varItem Asegurar SSH, Utilice SSH y sus comandos relacionados para el acceso de todos los usuarios remotos. $varParameter"
		varValEsp="PermitRootLogin yes"		
		varValEnc=$(  cat /etc/ssh/sshd_config | grep  "^$varParameter" | awk '{print $1, $2}' | tail -1)
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.9.1-1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.9.1-2
		varItem="1.9.1-2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="UsePrivilegeSeparation"
		varDetalle="ITEM $varItem Asegurar SSH, Utilice SSH y sus comandos relacionados para el acceso de todos los usuarios remotos. $varParameter"
		varValEsp="UsePrivilegeSeparation yes"		
		varValEnc=$(  cat /etc/ssh/sshd_config | grep  "^$varParameter" | awk '{print $1, $2}' | tail -1)
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.9.1-2
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.9.1-3
		varItem="1.9.1-3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="Protocol"
		varDetalle="ITEM $varItem Asegurar SSH, Utilice SSH y sus comandos relacionados para el acceso de todos los usuarios remotos. $varParameter"
		varValEsp="Protocol 2"		
		varValEnc=$(  cat /etc/ssh/sshd_config | grep  "^$varParameter" | awk '{print $1, $2}' | tail -1)
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.9.1-3
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.9.1-4
		varItem="1.9.1-4"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="LogLevel"
		varDetalle="ITEM $varItem Asegurar SSH, Utilice SSH y sus comandos relacionados para el acceso de todos los usuarios remotos. $varParameter"
		varValEsp="LogLevel verbose"		
		varValEnc=$(  cat /etc/ssh/sshd_config | grep  "^$varParameter" | awk '{print $1, $2}' | tail -1)
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.9.1-4
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.9.1-5
		varItem="1.9.1-5"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="AllowTcpForwarding"
		varDetalle="ITEM $varItem Asegurar SSH, Utilice SSH y sus comandos relacionados para el acceso de todos los usuarios remotos. $varParameter"
		varValEsp="AllowTcpForwarding no"		
		varValEnc=$(  cat /etc/ssh/sshd_config | grep  "^$varParameter" | awk '{print $1, $2}' | tail -1)
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.9.1-5
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.9.1-6
		varItem="1.9.1-6"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="X11Forwarding"
		varDetalle="ITEM $varItem Asegurar SSH, Utilice SSH y sus comandos relacionados para el acceso de todos los usuarios remotos. $varParameter"
		varValEsp="X11Forwarding no"		
		varValEnc=$(  cat /etc/ssh/sshd_config | grep  "^$varParameter" | awk '{print $1, $2}' | tail -1)
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.9.1-6
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.9.1-7
		varItem="1.9.1-7"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="StrictModes"
		varDetalle="ITEM $varItem Asegurar SSH, Utilice SSH y sus comandos relacionados para el acceso de todos los usuarios remotos. $varParameter"
		varValEsp="StrictModes yes"		
		varValEnc=$(  cat /etc/ssh/sshd_config | grep  "^$varParameter" | awk '{print $1, $2}' | tail -1)
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.9.1-7
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.9.1-8
		varItem="1.9.1-8"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="IgnoreRhosts"
		varDetalle="ITEM $varItem Asegurar SSH, Utilice SSH y sus comandos relacionados para el acceso de todos los usuarios remotos. $varParameter"
		varValEsp="IgnoreRhosts yes"		
		varValEnc=$(  cat /etc/ssh/sshd_config | grep  "^$varParameter" | awk '{print $1, $2}' | tail -1)
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.9.1-8
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.9.1-9
		varItem="1.9.1-9"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="HostbasedAuthentication"
		varDetalle="ITEM $varItem Asegurar SSH, Utilice SSH y sus comandos relacionados para el acceso de todos los usuarios remotos. $varParameter"
		varValEsp="HostbasedAuthentication no"		
		varValEnc=$(  cat /etc/ssh/sshd_config | grep  "^$varParameter" | awk '{print $1, $2}' | tail -1)
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.9.1-9
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.9.1.10
		varItem="1.9.1.10"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="RhostsRSAAuthentication"
		varDetalle="ITEM $varItem Asegurar SSH, Utilice SSH y sus comandos relacionados para el acceso de todos los usuarios remotos. $varParameter"
		varValEsp="RhostsRSAAuthentication no"		
		varValEnc=$(  cat /etc/ssh/sshd_config | grep  "^$varParameter" | awk '{print $1, $2}' | tail -1)
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.9.1.10
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.9.1.11
		varItem="1.9.1.11"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="Subsystem sftp"
		varDetalle="ITEM $varItem Asegurar SSH, Utilice SSH y sus comandos relacionados para el acceso de todos los usuarios remotos. $varParameter"
		varValEsp="#Subsystem sftp /usr/libexec/openssh/sftp-server"		
		varValEnc=$( cat /etc/ssh/sshd_config | awk '{print $1, $2, $3}' | grep  "^$varParameter" | tail -1)
		if [[ ($varValEnc = "Subsystem sftp /usr/libexec/openssh/sftp-server") ]] ; then
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		else
			varValEnc=$( cat /etc/ssh/sshd_config | awk '{print $1, $2, $3}' | grep  "$varParameter" | tail -1)
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.9.1.11
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.9.1.12
		varItem="1.9.1.12"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="/etc/issue"
		varDetalle="ITEM $varItem Asegurar SSH, Utilice SSH y sus comandos relacionados para el acceso de todos los usuarios remotos. $varParameter"
		varValEsp="Banner=/etc/issue"		
		varValEnc=$(  cat /etc/ssh/sshd_config | grep  "$varParameter" | tr -d " " | awk -F"=" '{print $1"="$2}' | tail -1)
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.9.1.12
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.10.1-1
		varItem="1.10.1-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="net.ipv4.tcp_syncookies"
		varDetalle="ITEM $varItem Parametros de seguridad del kernel, Utilice SSH y sus comandos relacionados para el acceso de todos los usuarios remotos. $varParameter"
		varValEsp="net.ipv4.tcp_syncookies = 1"		
		varValEnc=$( cat /etc/sysctl.conf | grep  "^$varParameter" | tr -d " " | awk -F= '{print $1" = "$2}' | tail -1)
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.10.1-1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.10.1-2
		varItem="1.10.1-2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="net.ipv4.conf.all.accept_source_route"
		varDetalle="ITEM $varItem Parametros de seguridad del kernel, Utilice SSH y sus comandos relacionados para el acceso de todos los usuarios remotos. $varParameter"
		varValEsp="net.ipv4.conf.all.accept_source_route = 0"		
		varValEnc=$( cat /etc/sysctl.conf | grep  "^$varParameter" | tr -d " " | awk -F= '{print $1" = "$2}' | tail -1)
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.10.1-2
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.10.1-3
		varItem="1.10.1-3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="net.ipv4.conf.all.accept_redirects"
		varDetalle="ITEM $varItem Parametros de seguridad del kernel, Utilice SSH y sus comandos relacionados para el acceso de todos los usuarios remotos. $varParameter"
		varValEsp="net.ipv4.conf.all.accept_redirects = 0"		
		varValEnc=$( cat /etc/sysctl.conf | grep  "^$varParameter" | tr -d " " | awk -F= '{print $1" = "$2}' | tail -1)
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.10.1-3
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.10.1-4
		varItem="1.10.1-4"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="net.ipv4.conf.all.rp_filter"
		varDetalle="ITEM $varItem Parametros de seguridad del kernel, Utilice SSH y sus comandos relacionados para el acceso de todos los usuarios remotos. $varParameter"
		varValEsp="net.ipv4.conf.all.rp_filter = 1"		
		varValEnc=$( cat /etc/sysctl.conf | grep  "^$varParameter" | tr -d " " | awk -F= '{print $1" = "$2}' | tail -1)
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.10.1-4
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.10.1-5
		varItem="1.10.1-5"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="net.ipv4.icmp_echo_ignore_all"
		varDetalle="ITEM $varItem Parametros de seguridad del kernel, Utilice SSH y sus comandos relacionados para el acceso de todos los usuarios remotos. $varParameter"
		varValEsp="net.ipv4.icmp_echo_ignore_all = 1"		
		varValEnc=$( cat /etc/sysctl.conf | grep  "^$varParameter" | tr -d " " | awk -F= '{print $1" = "$2}' | tail -1)
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.10.1-5
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.10.1-6
		varItem="1.10.1-6"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="net.ipv4.icmp_echo_ignore_broadcasts"
		varDetalle="ITEM $varItem Parametros de seguridad del kernel, Utilice SSH y sus comandos relacionados para el acceso de todos los usuarios remotos. $varParameter"
		varValEsp="net.ipv4.icmp_echo_ignore_broadcasts = 1"		
		varValEnc=$( cat /etc/sysctl.conf | grep  "^$varParameter" | tr -d " " | awk -F= '{print $1" = "$2}' | tail -1)
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.10.1-6
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.10.1-7
		varItem="1.10.1-7"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="net.ipv4.conf.all.log_martians"
		varDetalle="ITEM $varItem Parametros de seguridad del kernel, Utilice SSH y sus comandos relacionados para el acceso de todos los usuarios remotos. $varParameter"
		varValEsp="net.ipv4.conf.all.log_martians = 1"		
		varValEnc=$( cat /etc/sysctl.conf | grep  "^$varParameter" | tr -d " " | awk -F= '{print $1" = "$2}' | tail -1)
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.10.1-7
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.10.1-8
		varItem="1.10.1-8"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="net.ipv4.icmp_ignore_bogus_error_responses"
		varDetalle="ITEM $varItem Parametros de seguridad del kernel, Utilice SSH y sus comandos relacionados para el acceso de todos los usuarios remotos. $varParameter"
		varValEsp="net.ipv4.icmp_ignore_bogus_error_responses = 1"		
		varValEnc=$( cat /etc/sysctl.conf | grep  "^$varParameter" | tr -d " " | awk -F= '{print $1" = "$2}' | tail -1)
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.10.1-8
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.11.1-1
		varItem="1.11.1-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="umask"
		varDetalle="ITEM $varItem Comprobacion de los permisos y la propiedad de los archivos /etc/bashrc $varParameter"
		varValEsp="umask 002"		
		varValEnc=$( cat /etc/bashrc  | awk '{print $1, $2}' | grep  "^$varParameter 002" | tail -1)
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.11.1-1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.11.1-2
		varItem="1.11.1-2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="umask"
		varDetalle="ITEM $varItem Comprobacion de los permisos y la propiedad de los archivos /etc/bashrc $varParameter"
		varValEsp="umask 027"		
		varValEnc=$( cat /etc/bashrc  | awk '{print $1, $2}' | grep  "^$varParameter 027" | tail -1)
		
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.11.1-2
	#------------------------------------------


 	#------------------------------------------
	# [INICIO] iTEM 1.11.2-1
		varItem="1.11.2-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="root"
		varDetalle="ITEM $varItem Comprobacion de los permisos y la propiedad de los archivos /etc/fstab $varParameter"
		varValEsp="root root -rw-r--r--"		
		varValEnc=$( ls -ltr /etc/fstab | awk '{print $3, $4, $1}' )
		
		test -f /etc/fstab
		if [[ $? -eq 1 ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="File not exists"
		else	
			if [[ ($varValEnc = $varValEsp) ]] ; then
				varCumplimiento="Cumple"
				varObservaciones="Ninguna"
			else		
				if [[  $varValEnc = "" ]] ; then
					varValEnc="Not configurated"
				fi
				varCumplimiento="No Cumple"
				varObservaciones="Error"

			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.11.2-1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.11.2-2
		varItem="1.11.2-2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="root"
		varDetalle="ITEM $varItem Comprobacion de los permisos y la propiedad de los archivos /etc/group $varParameter"
		varValEsp="root root -rw-r--r--"		
		varValEnc=$( ls -ltr /etc/group | awk '{print $3, $4, $1}' )
		
		test -f /etc/group
		if [[ $? -eq 1 ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="File not exists"
		else	
			if [[ ($varValEnc = $varValEsp) ]] ; then
				varCumplimiento="Cumple"
				varObservaciones="Ninguna"
			else		
				if [[  $varValEnc = "" ]] ; then
					varValEnc="Not configurated"
				fi
				varCumplimiento="No Cumple"
				varObservaciones="Error"

			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.11.2-2
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.11.2-3
		varItem="1.11.2-3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="root"
		varDetalle="ITEM $varItem Comprobacion de los permisos y la propiedad de los archivos /etc/passwd $varParameter"
		varValEsp="root root -rw-r--r--"		
		varValEnc=$( ls -ltr /etc/passwd | awk '{print $3, $4, $1}' )

		test -f /etc/passwd
		if [[ $? -eq 1 ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="File not exists"
		else	

			if [[ ($varValEnc = $varValEsp) ]] ; then
				varCumplimiento="Cumple"
				varObservaciones="Ninguna"
			else		
				if [[  $varValEnc = "" ]] ; then
					varValEnc="Not configurated"
				fi
				varCumplimiento="No Cumple"
				varObservaciones="Error"

			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.11.2-3
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.11.2-4
		varItem="1.11.2-4"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="root"
		varDetalle="ITEM $varItem Comprobacion de los permisos y la propiedad de los archivos /etc/shadow $varParameter"
		varValEsp="root root -r--------"		
		varValEnc=$( ls -ltr /etc/shadow | awk '{print $3, $4, $1}' )

		test -f /etc/shadow
		if [[ $? -eq 1 ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="File not exists"
		else	
			
			if [[ ($varValEnc = $varValEsp) ]] ; then
				varCumplimiento="Cumple"
				varObservaciones="Ninguna"
			else		
				if [[  $varValEnc = "" ]] ; then
					varValEnc="Not configurated"
				fi
				varCumplimiento="No Cumple"
				varObservaciones="Error"

			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.11.2-4
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.11.3-1
		varItem="1.11.3-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="root"
		varDetalle="ITEM $varItem Comprobacion de los permisos y la propiedad de los archivos /etc/cron.allow $varParameter"
		varValEsp="root root"		
		varValEnc=$( ls -ltr /etc/cron.allow | awk '{print $3, $4}' )

		test -f /etc/cron.allow
		if [[ $? -eq 1 ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="File not exists"
		else	

			if [[ ($varValEnc = $varValEsp) ]] ; then
				varCumplimiento="Cumple"
				varObservaciones="Ninguna"
			else		
				if [[  $varValEnc = "" ]] ; then
					varValEnc="Not configurated"
				fi
				varCumplimiento="No Cumple"
				varObservaciones="Error"

			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.11.3-1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.11.3-2
		varItem="1.11.3-2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="root"
		varDetalle="ITEM $varItem Comprobacion de los permisos y la propiedad de los archivos /etc/at.allow $varParameter"
		varValEsp="root root"		
		varValEnc=$( ls -ltr /etc/at.allow | awk '{print $3, $4}' )

		test -f /etc/at.allow
		if [[ $? -eq 1 ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="File not exists"
		else	
			if [[ ($varValEnc = $varValEsp) ]] ; then
				varCumplimiento="Cumple"
				varObservaciones="Ninguna"
			else		
				if [[  $varValEnc = "" ]] ; then
					varValEnc="Not configurated"
				fi
				varCumplimiento="No Cumple"
				varObservaciones="Error"

			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.11.3-2
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.12.1-1
		varItem="1.12.1-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="root"
		varDetalle="ITEM $varItem Restriccion del acceso a la cuenta ROOT Configure los permisos en el directorio de inicio raiz a 0700 $varParameter"
		varValEsp="root root drwx------"		
		varValEnc=$( ls -lad /root | awk '{print $3, $4, $1}' | tr -d "." )

	
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.12.1-1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.12.2-1
		varItem="1.12.2-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="auth required pam_wheel.so"
		varDetalle="ITEM $varItem Agregue las siguientes lineas de autenticacion al archivo /etc/pam.d/su $varParameter"
		varValEsp="auth required pam_wheel.so"
		varValEnc=$( cat /etc/pam.d/su | awk '{print $1, $2, $3}' | grep "^auth" | grep "required" | grep "pam_wheel.so" | tail -1 | wc -c)
		if [[ ($varValEnc -gt 25 ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc=$( cat /etc/pam.d/su | awk '{print $1, $2, $3}' | grep "^auth" | grep "required" | grep "pam_wheel.so" | tail -1 )
		else		
			if [[  $varValEnc -lt 20 ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.12.2-1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.12.2-2
		varItem="1.12.2-2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="auth required pam_deny.so"
		varDetalle="ITEM $varItem Agregue las siguientes lineas de autenticacion al archivo /etc/pam.d/su $varParameter"
		varValEsp="auth required pam_deny.so"
		varValEnc=$( cat /etc/pam.d/su | awk '{print $1, $2, $3}' | grep "^auth" | grep "required" | grep "pam_deny.so" | tail -1 | wc -c)
		if [[ ($varValEnc -gt 25 ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc=$( cat /etc/pam.d/su | awk '{print $1, $2, $3}' | grep "^auth" | grep "required" | grep "pam_deny.so" | tail -1 )
		else		
			if [[  $varValEnc -lt 20 ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.12.2-2
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.12.3-1
		varItem="1.12.3-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="auth required pam_deny.so"
		varDetalle="ITEM $varItem Agregue las siguientes lineas de autenticacion al archivo /etc/pam.d/other $varParameter"
		varValEsp="auth required pam_deny.so"
		varValEnc=$( cat /etc/pam.d/other | awk '{print $1, $2, $3}' | grep "^auth" | grep "required" | grep "pam_deny.so" | tail -1 | wc -c)
		if [[ ($varValEnc -gt 25 ) ]] ; then
			varValEnc=$( cat /etc/pam.d/other | awk '{print $1, $2, $3}' | grep "^auth" | grep "required" | grep "pam_deny.so" | tail -1 )
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc -lt 20 ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.12.3-1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.12.3-2
		varItem="1.12.3-2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="auth required pam_warn.so"
		varDetalle="ITEM $varItem Agregue las siguientes lineas de autenticacion al archivo /etc/pam.d/other $varParameter"
		varValEsp="auth required pam_warn.so"
		varValEnc=$( cat /etc/pam.d/other | awk '{print $1, $2, $3}' | grep "^auth" | grep "required" | grep "pam_warn.so" | tail -1 | wc -c)
		if [[ ($varValEnc -gt 25 ) ]] ; then
			varValEnc=$( cat /etc/pam.d/other | awk '{print $1, $2, $3}' | grep "^auth" | grep "required" | grep "pam_warn" | tail -1 )
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc -lt 20 ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.12.3-2
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.12.3-3
		varItem="1.12.3-3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="account required pam_deny.so"
		varDetalle="ITEM $varItem Agregue las siguientes lineas de autenticacion al archivo /etc/pam.d/other $varParameter"
		varValEsp="account required pam_deny.so"
		varValEnc=$( cat /etc/pam.d/other | awk '{print $1, $2, $3}' | grep "^account" | grep "required" | grep "pam_deny.so" | tail -1 | wc -c)
		if [[ ($varValEnc -gt 25 ) ]] ; then
			varValEnc=$( cat /etc/pam.d/other | awk '{print $1, $2, $3}' | grep "^account" | grep "required" | grep "pam_deny.so" | tail -1 )
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc -lt 20 ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.12.3-3
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.12.3-4
		varItem="1.12.3-4"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="account required pam_warn.so"
		varDetalle="ITEM $varItem Agregue las siguientes lineas de autenticacion al archivo /etc/pam.d/other $varParameter"
		varValEsp="account required pam_warn.so"
		varValEnc=$( cat /etc/pam.d/other | awk '{print $1, $2, $3}' | grep "^account" | grep "required" | grep "pam_warn.so" | tail -1 | wc -c)
		if [[ ($varValEnc -gt 25 ) ]] ; then
			varValEnc=$( cat /etc/pam.d/other | awk '{print $1, $2, $3}' | grep "^account" | grep "required" | grep "pam_warn.so" | tail -1 )
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc -lt 20 ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.12.3-4
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.12.3-5
		varItem="1.12.3-5"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="password required pam_deny.so"
		varDetalle="ITEM $varItem Agregue las siguientes lineas de autenticacion al archivo /etc/pam.d/other $varParameter"
		varValEsp="password required pam_deny.so"
		varValEnc=$( cat /etc/pam.d/other | awk '{print $1, $2, $3}' | grep "^password" | grep "required" | grep "pam_deny.so" | tail -1 | wc -c)
		if [[ ($varValEnc -gt 25 ) ]] ; then
			varValEnc=$( cat /etc/pam.d/other | awk '{print $1, $2, $3}' | grep "^password" | grep "required" | grep "pam_deny.so" | tail -1 )
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc -lt 20 ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.12.3-5
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.12.3-6
		varItem="1.12.3-6"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="password required pam_warn.so"
		varDetalle="ITEM $varItem Agregue las siguientes lineas de autenticacion al archivo /etc/pam.d/other $varParameter"
		varValEsp="password required pam_warn.so"
		varValEnc=$( cat /etc/pam.d/other | awk '{print $1, $2, $3}' | grep "^password" | grep "required" | grep "pam_warn.so" | tail -1 | wc -c)
		if [[ ($varValEnc -gt 25 ) ]] ; then
			varValEnc=$( cat /etc/pam.d/other | awk '{print $1, $2, $3}' | grep "^password" | grep "required" | grep "pam_warn.so" | tail -1 )
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc -lt 20 ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.12.3-6
	#------------------------------------------



	#------------------------------------------
	# [INICIO] iTEM 1.12.3-7
		varItem="1.12.3-7"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="session required pam_deny.so"
		varDetalle="ITEM $varItem Agregue las siguientes lineas de autenticacion al archivo /etc/pam.d/other $varParameter"
		varValEsp="session required pam_deny.so"
		varValEnc=$( cat /etc/pam.d/other | awk '{print $1, $2, $3}' | grep "^session" | grep "required" | grep "pam_deny.so" | tail -1 | wc -c)
		if [[ ($varValEnc -gt 25 ) ]] ; then
			varValEnc=$( cat /etc/pam.d/other | awk '{print $1, $2, $3}' | grep "^session" | grep "required" | grep "pam_deny.so" | tail -1 )
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc -lt 20 ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.12.3-7
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.12.3-8
		varItem="1.12.3-8"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="session required pam_deny.so"
		varDetalle="ITEM $varItem Agregue las siguientes lineas de autenticacion al archivo /etc/pam.d/other $varParameter"
		varValEsp="session required pam_deny.so"
		varValEnc=$( cat /etc/pam.d/other | awk '{print $1, $2, $3}' | grep "^session" | grep "required" | grep "pam_deny.so" | tail -1 | wc -c)
		if [[ ($varValEnc -gt 25 ) ]] ; then
			varValEnc=$( cat /etc/pam.d/other | awk '{print $1, $2, $3}' | grep "^session" | grep "required" | grep "pam_deny.so" | tail -1 )
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc -lt 20 ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.12.3-8
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.12.4-1
		varItem="1.12.4-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="session required pam_limits.so"
		varDetalle="ITEM $varItem Agregue las siguientes lineas de autenticacion al archivo /etc/pam.d/login $varParameter"
		varValEsp="session required pam_limits.so"
		varValEnc=$( cat /etc/pam.d/login | awk '{print $1, $2, $3}' | grep "^session" | grep "required" | grep "pam_limits.so" | tail -1 | wc -c)
		if [[ ($varValEnc -gt 25 ) ]] ; then
			varValEnc=$( cat /etc/pam.d/other | awk '{print $1, $2, $3}' | grep "^session" | grep "required" | grep "pam_limits.so" | tail -1 )
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc -lt 20 ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.12.4-1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.12.5-1
		varItem="1.12.5-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="ttyS0"
		varDetalle="ITEM $varItem Asegurese de que el archivo de seguridad del terminal este configurado para denegar el acceso privilegiado (raiz) desde cualquier conexion externa /etc/securetty $varParameter"
		varValEsp="ttyS0"
		varValEnc=$( cat /etc/securetty | grep "^$varParameter" | tail -1 )
		if [[ ($varValEnc = $varValEsp ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.12.5-1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.12.5-2
		varItem="1.12.5-2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="ttyS1"
		varDetalle="ITEM $varItem Asegurese de que el archivo de seguridad del terminal este configurado para denegar el acceso privilegiado (raiz) desde cualquier conexion externa /etc/securetty $varParameter"
		varValEsp="ttyS1"
		varValEnc=$( cat /etc/securetty | grep "^$varParameter" | tail -1 )
		if [[ ($varValEnc = $varValEsp ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else		
			if [[  $varValEnc = "" ]] ; then
				varValEnc="Not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.12.5-2
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.13.1-1
		varItem="1.13.1-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="bin"
		varDetalle="ITEM $varItem Cuentas, Comprobacion de cuentas desbloqueadas  /etc/shadow $varParameter"
		varValEsp="Locked Accounts"
		varValEnc=$( egrep -v '.*:\*|:\!' /etc/shadow | awk -F: '{print $1}'| grep $varParameter )
		if [[ ($varValEnc = "" ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Pendiente revision estandar"
			varValEnc="Locked"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.13.1-1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.13.1-2
		varItem="1.13.1-2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="daemon"
		varDetalle="ITEM $varItem Cuentas, Comprobacion de cuentas desbloqueadas  /etc/shadow $varParameter"
		varValEsp="Locked Accounts"
		varValEnc=$( egrep -v '.*:\*|:\!' /etc/shadow | awk -F: '{print $1}'| grep $varParameter )
		if [[ ($varValEnc = "" ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Pendiente revision estandar"
			varValEnc="Locked"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.13.1-2
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.13.1-3
		varItem="1.13.1-3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="adm"
		varDetalle="ITEM $varItem Cuentas, Comprobacion de cuentas desbloqueadas  /etc/shadow $varParameter"
		varValEsp="Locked Accounts"
		varValEnc=$( egrep -v '.*:\*|:\!' /etc/shadow | awk -F: '{print $1}'| grep $varParameter )
		if [[ ($varValEnc = "" ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Pendiente revision estandar"
			varValEnc="Locked"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.13.1-3
	#------------------------------------------


#------------------------------------------
	# [INICIO] iTEM 1.13.1-4
		varItem="1.13.1-4"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="lp"
		varDetalle="ITEM $varItem Cuentas, Comprobacion de cuentas desbloqueadas  /etc/shadow $varParameter"
		varValEsp="Locked Accounts"
		varValEnc=$( egrep -v '.*:\*|:\!' /etc/shadow | awk -F: '{print $1}'| grep $varParameter )
		if [[ ($varValEnc = "" ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Pendiente revision estandar"
			varValEnc="Locked"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.13.1-4
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.13.1-5
		varItem="1.13.1-5"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="sync"
		varDetalle="ITEM $varItem Cuentas, Comprobacion de cuentas desbloqueadas  /etc/shadow $varParameter"
		varValEsp="Locked Accounts"
		varValEnc=$( egrep -v '.*:\*|:\!' /etc/shadow | awk -F: '{print $1}'| grep $varParameter )
		if [[ ($varValEnc = "" ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Pendiente revision estandar"
			varValEnc="Locked"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.13.1-5
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.13.1-6
		varItem="1.13.1-6"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="shutdown"
		varDetalle="ITEM $varItem Cuentas, Comprobacion de cuentas desbloqueadas  /etc/shadow $varParameter"
		varValEsp="Locked Accounts"
		varValEnc=$( egrep -v '.*:\*|:\!' /etc/shadow | awk -F: '{print $1}'| grep $varParameter )
		if [[ ($varValEnc = "" ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Pendiente revision estandar"
			varValEnc="Locked"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.13.1-6
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.13.1-7
		varItem="1.13.1-7"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="adm"
		varDetalle="ITEM $varItem Cuentas, Comprobacion de cuentas desbloqueadas  /etc/shadow $varParameter"
		varValEsp="Locked Accounts"
		varValEnc=$( egrep -v '.*:\*|:\!' /etc/shadow | awk -F: '{print $1}'| grep $varParameter )
		if [[ ($varValEnc = "" ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Pendiente revision estandar"
			varValEnc="Locked"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.13.1-7
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.13.1-8
		varItem="1.13.1-8"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="mail"
		varDetalle="ITEM $varItem Cuentas, Comprobacion de cuentas desbloqueadas  /etc/shadow $varParameter"
		varValEsp="Locked Accounts"
		varValEnc=$( egrep -v '.*:\*|:\!' /etc/shadow | awk -F: '{print $1}'| grep $varParameter )
		if [[ ($varValEnc = "" ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Pendiente revision estandar"
			varValEnc="Locked"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.13.1-8
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.13.1-9
		varItem="1.13.1-9"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="uucp"
		varDetalle="ITEM $varItem Cuentas, Comprobacion de cuentas desbloqueadas  /etc/shadow $varParameter"
		varValEsp="Locked Accounts"
		varValEnc=$( egrep -v '.*:\*|:\!' /etc/shadow | awk -F: '{print $1}'| grep $varParameter )
		if [[ ($varValEnc = "" ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Pendiente revision estandar"
			varValEnc="Locked"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.13.1-9
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.13.1.10
		varItem="1.13.1.10"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="operator"
		varDetalle="ITEM $varItem Cuentas, Comprobacion de cuentas desbloqueadas  /etc/shadow $varParameter"
		varValEsp="Locked Accounts"
		varValEnc=$( egrep -v '.*:\*|:\!' /etc/shadow | awk -F: '{print $1}'| grep $varParameter )
		if [[ ($varValEnc = "" ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Pendiente revision estandar"
			varValEnc="Locked"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.13.1.10
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.13.1-11
		varItem="1.13.1-11"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="games"
		varDetalle="ITEM $varItem Cuentas, Comprobacion de cuentas desbloqueadas  /etc/shadow $varParameter"
		varValEsp="Locked Accounts"
		varValEnc=$( egrep -v '.*:\*|:\!' /etc/shadow | awk -F: '{print $1}'| grep $varParameter )
		if [[ ($varValEnc = "" ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Pendiente revision estandar"
			varValEnc="Locked"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.13.1-11
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.13.1-12
		varItem="1.13.1-12"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="gopher"
		varDetalle="ITEM $varItem Cuentas, Comprobacion de cuentas desbloqueadas  /etc/shadow $varParameter"
		varValEsp="Locked Accounts"
		varValEnc=$( egrep -v '.*:\*|:\!' /etc/shadow | awk -F: '{print $1}'| grep $varParameter )
		if [[ ($varValEnc = "" ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Pendiente revision estandar"
			varValEnc="Locked"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.13.1-12
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.13.1-13
		varItem="1.13.1-13"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="ftp"
		varDetalle="ITEM $varItem Cuentas, Comprobacion de cuentas desbloqueadas  /etc/shadow $varParameter"
		varValEsp="Locked Accounts"
		varValEnc=$( egrep -v '.*:\*|:\!' /etc/shadow | awk -F: '{print $1}'| grep $varParameter )
		if [[ ($varValEnc = "" ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Pendiente revision estandar"
			varValEnc="Locked"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.13.1-13
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.13.1-14
		varItem="1.13.1-14"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="nobody"
		varDetalle="ITEM $varItem Cuentas, Comprobacion de cuentas desbloqueadas  /etc/shadow $varParameter"
		varValEsp="Locked Accounts"
		varValEnc=$( egrep -v '.*:\*|:\!' /etc/shadow | awk -F: '{print $1}'| grep $varParameter )
		if [[ ($varValEnc = "" ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Pendiente revision estandar"
			varValEnc="Locked"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.13.1-14
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.13.1-15
		varItem="1.13.1-15"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="nfsnobody"
		varDetalle="ITEM $varItem Cuentas, Comprobacion de cuentas desbloqueadas  /etc/shadow $varParameter"
		varValEsp="Locked Accounts"
		varValEnc=$( egrep -v '.*:\*|:\!' /etc/shadow | awk -F: '{print $1}'| grep $varParameter )
		if [[ ($varValEnc = "" ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Pendiente revision estandar"
			varValEnc="Locked"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.13.1-15
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.13.1-16
		varItem="1.13.1-16"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="apache"
		varDetalle="ITEM $varItem Cuentas, Comprobacion de cuentas desbloqueadas  /etc/shadow $varParameter"
		varValEsp="Locked Accounts"
		varValEnc=$( egrep -v '.*:\*|:\!' /etc/shadow | awk -F: '{print $1}'| grep $varParameter )
		if [[ ($varValEnc = "" ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Pendiente revision estandar"
			varValEnc="Locked"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.13.1-16
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.13.1-17
		varItem="1.13.1-17"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="postfix"
		varDetalle="ITEM $varItem Cuentas, Comprobacion de cuentas desbloqueadas  /etc/shadow $varParameter"
		varValEsp="Locked Accounts"
		varValEnc=$( egrep -v '.*:\*|:\!' /etc/shadow | awk -F: '{print $1}'| grep $varParameter )
		if [[ ($varValEnc = "" ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Pendiente revision estandar"
			varValEnc="Locked"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.13.1-17
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.13.1-18
		varItem="1.13.1-18"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="mysql"
		varDetalle="ITEM $varItem Cuentas, Comprobacion de cuentas desbloqueadas  /etc/shadow $varParameter"
		varValEsp="Locked Accounts"
		varValEnc=$( egrep -v '.*:\*|:\!' /etc/shadow | awk -F: '{print $1}'| grep $varParameter )
		if [[ ($varValEnc = "" ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Pendiente revision estandar"
			varValEnc="Locked"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.13.1-18
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.13.1-19
		varItem="1.13.1-19"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="mailnull"
		varDetalle="ITEM $varItem Cuentas, Comprobacion de cuentas desbloqueadas  /etc/shadow $varParameter"
		varValEsp="Locked Accounts"
		varValEnc=$( egrep -v '.*:\*|:\!' /etc/shadow | awk -F: '{print $1}'| grep $varParameter )
		if [[ ($varValEnc = "" ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Pendiente revision estandar"
			varValEnc="Locked"
		else		
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.13.1-19
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.13.2-1
		varItem="1.13.2-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter=""
		varDetalle="ITEM $varItem Cuentas, Comprobacion de cuentas no utilizadas. $varParameter"
		varValEsp="accounts must not exist"
		varValEnc=$( cat /etc/passwd | grep -v ":x:" | awk -F":" '{print $1":"$2}' | wc -l )
		if [[ ($varValEnc -eq 0 ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="Pendiente scritps "
		else		
			varCumplimiento="No Cumple"
			varValEnc="Pendiente scritps "
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.13.2-1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.13.3-1
		varItem="1.13.3-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="/sbin/sulogin"
		varDetalle="ITEM $varItem Contrasena de modo de usuario unico para root $varParameter"
		varValEsp="~~:S:wait:/sbin/sulogin"
		varValEnc=$( cat /etc/inittab | tr -d " " | tr -d "\t" | grep "~~:S:wait:" | grep "/sbin/sulogin" )
		if [[ ( $varValEnc = $varValEsp ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			if [[ ($varValEnc = "") ]] ; then
				varValEnc="Does not configurated"
			fi		
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.13.3-1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.14.1-1
		varItem="1.14.1-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="PASS_MAX_DAYS"
		varDetalle="ITEM $varItem Habilitacion de la caducidad de la contrasena,  Nombre de archivo Parametro Valor Descripcion $varParameter"
		varValEsp="PASS_MAX_DAYS 30"
		varValEnc=$( cat /etc/login.defs | grep "^$varParameter"  | awk '{print $1, $2}' | tail -1 )
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			
		else		
			if [[ ($varValEnc = "") ]] ; then
				varValEnc="Does not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.14.1-1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.14.1-2
		varItem="1.14.1-2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="PASS_MIN_DAYS"
		varDetalle="ITEM $varItem Habilitacion de la caducidad de la contrasena,  Nombre de archivo Parametro Valor Descripcion $varParameter"
		varValEsp="PASS_MIN_DAYS 1"
		varValEnc=$( cat /etc/login.defs | grep "^$varParameter"  | awk '{print $1, $2}' | tail -1 )
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			
		else		
			if [[ ($varValEnc = "") ]] ; then
				varValEnc="Does not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.14.1-2
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.14.1-3
		varItem="1.14.1-3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="PASS_MIN_LEN"
		varDetalle="ITEM $varItem Habilitacion de la caducidad de la contrasena,  Nombre de archivo Parametro Valor Descripcion $varParameter"
		varValEsp="PASS_MIN_LEN 5"
		varValEnc=$( cat /etc/login.defs | grep "^$varParameter"  | awk '{print $1, $2}' | tail -1 )
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			
		else		
			if [[ ($varValEnc = "") ]] ; then
				varValEnc="Does not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.14.1-3
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.14.1-4
		varItem="1.14.1-4"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="PASS_WARN_AGE"
		varDetalle="ITEM $varItem Habilitacion de la caducidad de la contrasena,  Nombre de archivo Parametro Valor Descripcion $varParameter"
		varValEsp="PASS_WARN_AGE 7"
		varValEnc=$( cat /etc/login.defs | grep "^$varParameter"  | awk '{print $1, $2}' | tail -1 )
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			
		else		
			if [[ ($varValEnc = "") ]] ; then
				varValEnc="Does not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.14.1-4
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.14.2-1
		varItem="1.14.2-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="INACTIVE"
		varDetalle="ITEM $varItem Habilitacion de la caducidad de la contrasena,  Nombre de archivo Parametro Valor Descripcion $varParameter"
		varValEsp="INACTIVE=30"
		varValEnc=$( cat /etc/default/useradd | grep "^$varParameter"  | awk -F"=" '{print $1"="$2}' | tail -1 )
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			
		else		
			if [[ ($varValEnc = "") ]] ; then
				varValEnc="Does not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.14.2-1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.14.2-2
		varItem="1.14.2-2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="EXPIRE"
		varDetalle="ITEM $varItem Habilitacion de la caducidad de la contrasena,  Nombre de archivo Parametro Valor Descripcion $varParameter"
		varValEsp="EXPIRE="
		varValEnc=$( cat /etc/default/useradd | grep "^$varParameter"  | awk -F"=" '{print $1"="$2}' | tail -1 )
		if [[ ($varValEnc = $varValEsp) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			
		else		
			if [[ ($varValEnc = "") ]] ; then
				varValEnc="Does not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"

		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.14.2-2
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.15.1-1
		varItem="1.15.1-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varResult=""
		varCriticidad="Alto"
		varParameter="minlen"
		varParameterDos="8"
		varDetalle="ITEM $varItem Habilitacion de la caducidad de la contrasena,  Nombre de archivo Parametro Valor Descripcion $varParameter"
		varValEsp="minlen=8"
		varValEnc=$( cat /etc/pam.d/system-auth | tr -d '\t' | tr -d ' ' | grep "password" | grep "requisite"  | grep "pam_cracklib.so"| awk -F"minlen" '{print $2 }' )
		varResult=$( echo ${varValEnc:1:1} )
		if [[ ($varResult = $varParameterDos ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="$varParameter=$varResult"			
		else		
			if [[ ($varResult = "") ]] ; then
				varValEnc="Does not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.15.1-1
	#------------------------------------------



	#------------------------------------------
	# [INICIO] iTEM 1.15.1-2
		varItem="1.15.1-2"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varResult=""
		varCriticidad="Alto"
		varParameter="lcredit"
		varParameterDos="-1"
		varDetalle="ITEM $varItem Habilitacion de la caducidad de la contrasena,  Nombre de archivo Parametro Valor Descripcion $varParameter"
		varValEsp="lcredit=-1"
		varValEnc=$( cat /etc/pam.d/system-auth | tr -d '\t' | tr -d ' ' | grep "password" | grep "requisite"  | grep "pam_cracklib.so"| awk -F"lcredit" '{print $2 }' )
		varResult=$( echo ${varValEnc:1:2} )
		if [[ ($varResult = $varParameterDos ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="$varParameter=$varResult"			
		else		
			if [[ ($varResult = "") ]] ; then
				varValEnc="Does not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.15.1-2
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.15.1-3
		varItem="1.15.1-3"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varResult=""
		varCriticidad="Alto"
		varParameter="ucredit"
		varParameterDos="-1"
		varDetalle="ITEM $varItem Habilitacion de la caducidad de la contrasena,  Nombre de archivo Parametro Valor Descripcion $varParameter"
		varValEsp="ucredit=-1"
		varValEnc=$( cat /etc/pam.d/system-auth | tr -d '\t' | tr -d ' ' | grep "password" | grep "requisite"  | grep "pam_cracklib.so"| awk -F"ucredit" '{print $2 }' )
		varResult=$( echo ${varValEnc:1:2} )
		if [[ ($varResult = $varParameterDos ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="$varParameter=$varResult"			
		else		
			if [[ ($varResult = "") ]] ; then
				varValEnc="Does not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.15.1-3
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.15.1-4
		varItem="1.15.1-4"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varResult=""
		varCriticidad="Alto"
		varParameter="dcredit"
		varParameterDos="-1"
		varDetalle="ITEM $varItem Habilitacion de la caducidad de la contrasena,  Nombre de archivo Parametro Valor Descripcion $varParameter"
		varValEsp="dcredit=-1"
		varValEnc=$( cat /etc/pam.d/system-auth | tr -d '\t' | tr -d ' ' | grep "password" | grep "requisite"  | grep "pam_cracklib.so"| awk -F"dcredit" '{print $2 }' )
		varResult=$( echo ${varValEnc:1:2} )
		if [[ ($varResult = $varParameterDos ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="$varParameter=$varResult"			
		else		
			if [[ ($varResult = "") ]] ; then
				varValEnc="Does not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.15.1-4
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.15.1-5
		varItem="1.15.1-5"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varResult=""
		varCriticidad="Alto"
		varParameter="ocredit"
		varParameterDos="-1"
		varDetalle="ITEM $varItem Habilitacion de la caducidad de la contrasena,  Nombre de archivo Parametro Valor Descripcion $varParameter"
		varValEsp="ocredit=-1"
		varValEnc=$( cat /etc/pam.d/system-auth | tr -d '\t' | tr -d ' ' | grep "password" | grep "requisite"  | grep "pam_cracklib.so"| awk -F"ocredit" '{print $2 }' )
		varResult=$( echo ${varValEnc:1:2} )
		if [[ ($varResult = $varParameterDos ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="$varParameter=$varResult"			
		else		
			if [[ ($varResult = "") ]] ; then
				varValEnc="Does not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.15.1-5
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.15.1-6
		varItem="1.15.1-6"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="retry"
		varParameterDos="3"
		varDetalle="ITEM $varItem Habilitacion de la caducidad de la contrasena,  Nombre de archivo Parametro Valor Descripcion $varParameter"
		varValEsp="retry=3"
		varValEnc=$( cat /etc/pam.d/system-auth | tr -d '\t' | tr -d ' ' | grep "password" | grep "requisite"  | grep "pam_cracklib.so"| awk -F"retry" '{print $2 }' )
		varResult=$( echo ${varValEnc:1:1} )
		if [[ ($varResult = $varParameterDos ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="$varParameter=$varResult"			
		else		
			if [[ ($varResult = "") ]] ; then
				varValEnc="Does not configurated"

				echo ${varValEnc:1:1}
				echo ${varValEnc:1:1}
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.15.1-6
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.15.1-7
		varItem="1.15.1-7"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="remember"
		varParameterDos="12"
		varDetalle="ITEM $varItem Habilitacion de la caducidad de la contrasena,  Nombre de archivo Parametro Valor Descripcion $varParameter"
		varValEsp="remember=12"
		varValEnc=$( cat /etc/pam.d/system-auth | tr -d '\t' | tr -d ' ' | grep "password" | grep "sufficient"  | grep "pam_unix.so" | awk -F"remember" '{print $2 }' )
		varResult=$( echo ${varValEnc:1:2} )
		if [[ ($varResult = $varParameterDos ) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="$varParameter=$varResult"			
		else		
			if [[ ($varResult = "") ]] ; then
				varValEnc="Does not configurated"
			fi
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.15.1-7
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.16.1-1
		varItem="1.16.1-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]] ; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varParameter="/etc/issue"
		varDetalle="ITEM $varItem Visualizacion de banners de inicio de sesion, para SSH, edite el parametro Banner en el $varParameter"
		varValEsp="Banner"
		varValEnc=$( cat /etc/issue | wc -c )
		if [[ ($varValEnc -gt  100) ]] ; then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
			varValEnc="Exists banner"	
		else	
			varValEnc="Does not configurated"
			varCumplimiento="No Cumple"
			varObservaciones="Error"
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.16.1-1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.17.1-1
		varItem="1.17.1-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Medio"
		varValEsp="*.debug @10.70.72.56"
		varDetalle="ITEM $varItem Asegurese de que rsyslog esta configurado para enviar registros a un host de registro remoto *.debug"
		varValEnc=$(grep "^*.debug" /etc/rsyslog.conf | awk '{print $1, $2}' | tail -1)
		if [[ $varValEsp = $varValEnc ]]; then		 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error"
			if [[ $varValEnc = "" ]]; then 
				varValEnc="S/D"	
			fi
		fi
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.17.1-1
	#------------------------------------------


	#------------------------------------------
	# [INICIO] iTEM 1.18.1-1
		varItem="1.18.1-1"
		varItemStandard=${varItem:0:4}
		if [[ ${varItemStandard:3:1} = "." ]]; then
			varItemStandard=${varItem:0:3}
		fi
		varCriticidad="Alto"
		varDetalle="ITEM $varItem Anadir el nombre del servidor al archivo /etc/ntp.conf"
		varValEsp=("10.0.0.163" "ecuio012d04")
		varQuery=($(grep -E '10.0.0.163|ecuio012d04' /etc/ntp.conf | tail -1))
		varCont=0
		for i in ${varValEsp[*]}; do
			if [[ $i = ${varQuery[1]} ]]; then
				varCont=$((varCont+1))
			fi		
		done
			varValEnc="${varQuery[*]}"
			if [[ $varCont -eq 1 ]]; then		 
				varCumplimiento="Cumple"
				varObservaciones="Ninguna"
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				if [[ $varValEnc = "" ]]; then 
					varValEnc="S/D"	
				fi
			fi
		
		varItemReg="$oDate|$constServer|$constVersion|$constIP|$varItem|$varItemStandard|$varCriticidad|$varDetalle|${varValEsp[*]}|$varValEnc|$varCumplimiento|$varObservaciones"
		echo -e "\n $varItemReg "
		echo "$dateTime|$constServer|$varItem|$varValEnc --- $varObservaciones" >> $constPathClbRH/LOG_$constServer.$oMonth.log
		echo $varItemReg >> $constPathClbRH/CLB_$constServer.$oMonth.csv
	# [FIN] iTEM 1.18.1-1 
	#------------------------------------------	
	









echo -e "\n"		
[ -f "$constPathClbRH/CLB_$constServer.$oMonth.csv" ]
if [ $? -eq 0 ]; then
	echo -e "\e[1;32m 	[*] El archivo CLB fue creado de maneara satisfactoria \e[0m" "\e[32m \t $constPathClbRH/CLB_$constServer.$oMonth.csv \e[0m"
else
	echo -e "\e[1;31m 	[*] No se pudo crear el archivo CLB \e[0m" "\e[31m \t $constPathClbRH/CLB_$constServer.$oMonth.csv \e[0m"
	echo -e "\e[31m 	[*] Error al ejecutasr el control de linea base \e[0m"
fi

echo -e "\n"	 
echo -e "\e[33m[FIN PROCESO] - $dateTime \e[0m"
echo -e "\n"