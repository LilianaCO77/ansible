####################################################
# Scritp de control de linea base para AIX 7
# CREADO POR: 		ALEXANDER GONZALEZ
# AUTORIZADO POR: 	NELSON PORRAS
####################################################

clear

# --------------------------------------
# VARIABLES LOCALES
# --------------------------------------
dateTime=` date "+%Y-%m-%d %H:%M:%S" `
oDate=` date "+%Y-%m-%d" `
oMonth=` date "+%m%Y" `
constPathTmp=/tmp
constPathClb=$constPathTmp/ClbUnix/AIX
#constPathClb=$constPathTmp
constServer=` hostname `
constVersion="AIX"

constHeader="Fecha|Server|Version|Item|Item_Standar|Criticidad|Detalle|Valor_Esperado|Valor_Encontrado|Cumplimiento|Observaciones"

varValEsp=""
varValEnc=""
varCumplimiento=""
varItem=""
varItemStandard=""
varItemReg=""
varCriticidad=""
varAuditLog=""
varObservaciones=""

# --------------------------------------
# MAIN: SHELL PRINCIPAL
# --------------------------------------
echo 
echo [INICIO PROCESO] - $dateTime 
echo 

if (test -d  $constPathClb ); then
	echo 
	echo 	[*] Ruta encontrada  $constPathClb
	echo 
else
	echo 
	echo 	!Error! Ruta no encontrada $constPathClb
	echo	[*] Creando la ruta $constPathClb
	mkdir -p /tmp/ClbUnix/AIX
	echo 	[*] La ruta ha sido creada correctamente $constPathClb
	echo 	
fi

echo $constHeader
echo $constHeader > $constPathClb/CLB_$constServer.$oMonth.csv
	
echo "Fecha_Hora|Servidor|Item|Valor_Encontrado" > $constPathClb/LOG_$constServer.$oMonth.log
#------------------------------------------
# [INICIO] ÍTEM 0
	varItem="0"
	varItemStandard="0"		
	varCriticidad="Alto"
	varDetalle="ITEM $varItem Validar que se encuentre instalado el antivirus sophos"
	varValEsp="Sophos Anti-Virus is active"
	if ( test -d "/opt/sophos-av" ); then	
		varValEnc=`/opt/sophos-av/bin/savdstatus` 
		if (test "$varValEsp" = "$varValEnc" ) ; then	
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"						
		else
			if ( test "$varValEnc" = "" ); then 
				varCumplimiento="No Cumple"
				varObservaciones="Error"
				varValEnc="not configured"	
			else
				varCumplimiento="No Cumple"
				varObservaciones="Error"
			fi
		fi	
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		varValEnc="No se encontró la ruta /opt/sophos-av"
	fi	
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 0	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 1.5.1
	varItem="1.5"
	varItemStandard="1.5.1"		
	varCriticidad="Alto"
	varDetalle="ITEM $varItem Cambiar la pantalla de inicio del sistema: SAK (Security Attention Key)"
	varStanza="default"
	varAtributo="sak_enabled"
	varValEsp="true"
	varValEnc=`lssec -f /etc/security/login.cfg -s "$varStanza" -a "$varAtributo" | awk -F= '{print $2 }' ` 
	if ( test "$varValEsp" = "$varValEnc" ); then		
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"				
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="not configured"	
		fi
	fi	
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 1.5.1	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 1.5.2
	varItem="1.5"
	varItemStandard="1.5.2"		
	varCriticidad="Alto"
	varDetalle="ITEM $varItem Cambiar la pantalla de inicio del sistema: LoginTimes"
	varStanza="default"
	varAtributo="logindisable"
	varValEsp="5"
	varValEnc=` lssec -f /etc/security/login.cfg -s "$varStanza" -a "$varAtributo" | awk -F= '{print $2 }' ` 
	if ( test "$varValEsp" = "$varValEnc" ); then		
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"				
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="not configured"	
		fi
	fi	
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 1.5.2	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 1.5.3
	varItem="1.5"
	varItemStandard="1.5.3"		
	varCriticidad="Alto"
	varStanza="default"
	varAtributo="logininterval"
	varDetalle="ITEM $varItem Cambiar la pantalla de inicio del sistema: $varAtributo"
	varValEsp="60"
	varValEnc=` lssec -f /etc/security/login.cfg -s "$varStanza" -a "$varAtributo" | awk -F= '{print $2 }' ` 
	if ( test "$varValEsp" = "$varValEnc" ); then		
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"				
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="not configured"	
		fi
	fi	
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 1.5.3	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 1.5.4
	varItem="1.5"
	varItemStandard="1.5.4"		
	varCriticidad="Alto"
	varStanza="default"
	varAtributo="loginreenable"
	varDetalle="ITEM $varItem Cambiar la pantalla de inicio del sistema: $varAtributo"
	varValEsp="0"
	varValEnc=` lssec -f /etc/security/login.cfg -s "$varStanza" -a "$varAtributo" | awk -F= '{print $2 }' ` 
	if ( test "$varValEsp" = "$varValEnc" ); then		
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"				
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="not configured"	
		fi
	fi	
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 1.5.4	
#------------------------------------------



#------------------------------------------
# [INICIO] ÍTEM 1.5.5
	varItem="1.5"
	varItemStandard="1.5.5"		
	varCriticidad="Alto"
	varStanza="default"
	varAtributo="logindelay"
	varDetalle="ITEM $varItem Cambiar la pantalla de inicio del sistema: $varAtributo"
	varValEsp="5"
	varValEnc=` lssec -f /etc/security/login.cfg -s "$varStanza" -a "$varAtributo" | awk -F= '{print $2 }' ` 
	if ( test "$varValEsp" = "$varValEnc" ); then		
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"				
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="not configured"	
		fi
	fi	
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 1.5.5	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.1.1
	varItem="2.1"
	varItemStandard="2.1.1"		
	varCriticidad="Alto"
	varStanza="account_locked"
	varAtributo="adm"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Deshabilitar los siguientes usuarios innecesarios: $varAtributo"
	varValEsp="true"
	varValEnc=` lsuser -a "$varStanza" "$varAtributo" | awk -F= '{print $2 }' ` 
	if ( test "$varValEnc" = "false"); then		
		varCumplimiento="No Cumple"
		varObservaciones="Error"				
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="$varAtributo does not exist."	
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.1.1	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.1.2
	varItem="2.1"
	varItemStandard="2.1.2"		
	varCriticidad="Alto"
	varStanza="account_locked"
	varAtributo="bin"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Deshabilitar los siguientes usuarios innecesarios: $varAtributo"
	varValEsp="true"
	varValEnc=` lsuser -a "$varStanza" "$varAtributo" | awk -F= '{print $2 }' ` 
	if ( test "$varValEnc" = "false"); then		
		varCumplimiento="No Cumple"
		varObservaciones="Error"				
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="$varAtributo does not exist."	
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.1.2	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.1.3
	varItem="2.1"
	varItemStandard="2.1.3"		
	varCriticidad="Alto"
	varStanza="account_locked"
	varAtributo="daemon"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Deshabilitar los siguientes usuarios innecesarios: $varAtributo"
	varValEsp="true"
	varValEnc=` lsuser -a "$varStanza" "$varAtributo" | awk -F= '{print $2 }' ` 
	if ( test "$varValEnc" = "false"); then		
		varCumplimiento="No Cumple"
		varObservaciones="Error"				
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="$varAtributo does not exist."	
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.1.3	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.1.4
	varItem="2.1"
	varItemStandard="2.1.4"		
	varCriticidad="Alto"
	varStanza="account_locked"
	varAtributo="guest"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Deshabilitar los siguientes usuarios innecesarios: $varAtributo"
	varValEsp="true"
	varValEnc=` lsuser -a "$varStanza" "$varAtributo" | awk -F= '{print $2 }' ` 
	if ( test "$varValEnc" = "false"); then		
		varCumplimiento="No Cumple"
		varObservaciones="Error"				
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="$varAtributo does not exist."	
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.1.4	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.1.5
	varItem="2.1"
	varItemStandard="2.1.5"		
	varCriticidad="Alto"
	varStanza="account_locked"
	varAtributo="imnadm"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Deshabilitar los siguientes usuarios innecesarios: $varAtributo"
	varValEsp="true"
	varValEnc=` lsuser -a "$varStanza" "$varAtributo" | awk -F= '{print $2 }' ` 
	if ( test "$varValEnc" = "false"); then		
		varCumplimiento="No Cumple"
		varObservaciones="Error"				
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="$varAtributo does not exist."	
		fi
	fi	
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.1.5	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.1.6
	varItem="2.1"
	varItemStandard="2.1.6"		
	varCriticidad="Alto"
	varStanza="account_locked"
	varAtributo="lp"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Deshabilitar los siguientes usuarios innecesarios: $varAtributo"
	varValEsp="true"
	varValEnc=` lsuser -a "$varStanza" "$varAtributo" | awk -F= '{print $2 }' ` 
	if ( test "$varValEnc" = "false"); then		
		varCumplimiento="No Cumple"
		varObservaciones="Error"				
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="$varAtributo does not exist."	
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.1.6	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.1.7
	varItem="2.1"
	varItemStandard="2.1.7"		
	varCriticidad="Alto"
	varStanza="account_locked"
	varAtributo="lpd"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Deshabilitar los siguientes usuarios innecesarios: $varAtributo"
	varValEsp="true"
	varValEnc=` lsuser -a "$varStanza" "$varAtributo" | awk -F= '{print $2 }' ` 
	if ( test "$varValEnc" = "false"); then		
		varCumplimiento="No Cumple"
		varObservaciones="Error"				
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="$varAtributo does not exist."	
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.1.7	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.1.8
	varItem="2.1"
	varItemStandard="2.1.8"		
	varCriticidad="Alto"
	varStanza="account_locked"
	varAtributo="noaccess"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Deshabilitar los siguientes usuarios innecesarios: $varAtributo"
	varValEsp="true"
	varValEnc=` lsuser -a "$varStanza" "$varAtributo" | awk -F= '{print $2 }' ` 
	if ( test "$varValEnc" = "false"); then		
		varCumplimiento="No Cumple"
		varObservaciones="Error"				
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="$varAtributo does not exist."	
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.1.8	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.1.9
	varItem="2.1"
	varItemStandard="2.1.9"		
	varCriticidad="Alto"
	varStanza="account_locked"
	varAtributo="nobody"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Deshabilitar los siguientes usuarios innecesarios: $varAtributo"
	varValEsp="true"
	varValEnc=` lsuser -a "$varStanza" "$varAtributo" | awk -F= '{print $2 }' ` 
	if ( test "$varValEnc" = "false"); then		
		varCumplimiento="No Cumple"
		varObservaciones="Error"				
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="$varAtributo does not exist."	
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.1.9	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.1.10
	varItem="2.1"
	varItemStandard="2.1.10"		
	varCriticidad="Alto"
	varStanza="account_locked"
	varAtributo="nobody4"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Deshabilitar los siguientes usuarios innecesarios: $varAtributo"
	varValEsp="true"
	varValEnc=` lsuser -a "$varStanza" "$varAtributo" | awk -F= '{print $2 }' ` 
	if ( test "$varValEnc" = "false"); then		
		varCumplimiento="No Cumple"
		varObservaciones="Error"				
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="$varAtributo does not exist."	
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.1.10	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.1.11
	varItem="2.1"
	varItemStandard="2.1.11"		
	varCriticidad="Alto"
	varStanza="account_locked"
	varAtributo="nuucp"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Deshabilitar los siguientes usuarios innecesarios: $varAtributo"
	varValEsp="true"
	varValEnc=` lsuser -a "$varStanza" "$varAtributo" | awk -F= '{print $2 }' ` 
	if ( test "$varValEnc" = "false"); then		
		varCumplimiento="No Cumple"
		varObservaciones="Error"				
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="$varAtributo does not exist."	
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.1.11	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.1.12
	varItem="2.1"
	varItemStandard="2.1.12"		
	varCriticidad="Alto"
	varStanza="account_locked"
	varAtributo="sys"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Deshabilitar los siguientes usuarios innecesarios: $varAtributo"
	varValEsp="true"
	varValEnc=` lsuser -a "$varStanza" "$varAtributo" | awk -F= '{print $2 }' ` 
	if ( test "$varValEnc" = "false"); then		
		varCumplimiento="No Cumple"
		varObservaciones="Error"				
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="$varAtributo does not exist."	
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.1.12	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.1.13
	varItem="2.1"
	varItemStandard="2.1.13"		
	varCriticidad="Alto"
	varStanza="account_locked"
	varAtributo="uucp"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Deshabilitar los siguientes usuarios innecesarios: $varAtributo"
	varValEsp="true"
	varValEnc=` lsuser -a "$varStanza" "$varAtributo" | awk -F= '{print $2 }' ` 
	if ( test "$varValEnc" = "false"); then		
		varCumplimiento="No Cumple"
		varObservaciones="Error"				
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="$varAtributo does not exist."	
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.1.13	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.1.14
	varItem="2.1"
	varItemStandard="2.1.14"		
	varCriticidad="Alto"
	varStanza="account_locked"
	varAtributo="printq"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Deshabilitar los siguientes usuarios innecesarios: $varAtributo"
	varValEsp="true"
	varValEnc=` lsuser -a "$varStanza" "$varAtributo" | awk -F= '{print $2 }' ` 
	if ( test "$varValEnc" = "false"); then		
		varCumplimiento="No Cumple"
		varObservaciones="Error"				
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="$varAtributo does not exist."	
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.1.14	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.2.1
	varItem="2.2"
	varItemStandard="2.2.1"		
	varCriticidad="Alto"
	varStanza="/etc/group"
	varAtributo="uucp"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, No remover los siguientes grupos del sistema: $varAtributo"
	varValEsp="uucp"
	varValEnc=` cat "$varStanza" | grep "^$varAtributo" | awk -F: '{print $1 }' ` 
	if ( test "$varValEnc" = "$varValEsp" ); then		
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"				
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="$varAtributo does not exist."	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.2.1	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.2.2
	varItem="2.2"
	varItemStandard="2.2.2"		
	varCriticidad="Alto"
	varStanza="/etc/group"
	varAtributo="printq"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, No remover los siguientes grupos del sistema: $varAtributo"
	varValEsp="uucp"
	varValEnc=` cat "$varStanza" | grep "^$varAtributo" | awk -F: '{print $1 }' ` 
	if ( test "$varValEnc" = "$varValEsp" ); then		
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"				
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="$varAtributo does not exist."	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.2.2	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.2.3
	varItem="2.2"
	varItemStandard="2.2.3"		
	varCriticidad="Alto"
	varStanza="/etc/group"
	varAtributo="imnadm"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, No remover los siguientes grupos del sistema: $varAtributo"
	varValEsp="uucp"
	varValEnc=` cat "$varStanza" | grep "^$varAtributo" | awk -F: '{print $1 }' ` 
	if ( test "$varValEnc" = "$varValEsp" ); then		
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"				
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="$varAtributo does not exist."	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.2.3	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.4.1
	varItem="2.4"
	varItemStandard="2.4.1"		
	varCriticidad="Alto"
	varStanza="sugroups"
	varAtributo="root"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Garantizar que el acceso al root sea únicamente por los administradores del equipo: $varAtributo"
	varValEsp="ing_adm"
	varValEnc=` lsuser -a $varStanza $varAtributo | awk -F= '{print $2 }' ` 
	if ( test "$varValEnc" = "$varValEsp" ); then		
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"				
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="not configured"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.4.1	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.5.1
	varItem="2.5"
	varItemStandard="2.5.1"		
	varCriticidad="Medio"
	varStanza="/etc/security/user"
	varAtributo="sak_enabled=true"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Habilitar SAK (Security Attention Key) $varAtributo"
	varValEsp="true"
	varValEnc=`cat $varStanza | tr -d " " | tr -d "\t" | grep "sak_enabled=true" | tail -1 | awk -F= '{print $2}'` 
	if ( test "$varValEnc" = "$varValEsp" ); then		
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"				
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="not configured"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.5.1	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.6.1
	varItem="2.6"
	varItemStandard="2.6.1"		
	varCriticidad="Alto"
	varStanza="/etc/security/user"
	varAtributo="tpath=on"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Habilitar trusted shell $varAtributo"
	varValEsp="on"
	varValEnc=`cat $varStanza | tr -d " " | tr -d "\t" | grep "tpath=on" | tail -1 | awk -F= '{print $2}'` 
	if ( test "$varValEnc" = "$varValEsp" ); then		
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"				
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="not configured"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.6.1	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.7.1
	varItem="2.7"
	varItemStandard="2.7.1"		
	varCriticidad="Alto"
	varStanza="/etc/profile"
	varAtributo="logo"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Incluir las siguientes líneas en el archivo $varAtributo"
	varValEsp="cat -s /etc/logo"
	varValEnc=`cat $varStanza | tr -d "\t" | grep "cat -s /etc/logo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then		
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"				
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="not configured"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.7.1	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.7.2
	varItem="2.7"
	varItemStandard="2.7.2"		
	varCriticidad="Alto"
	varStanza="/etc/profile"
	varAtributo="BANCO"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Incluir las siguientes líneas en el archivo $varAtributo"
	varValEsp="BANCO"
	varValEnc=`cat $varStanza | tr -d "\t" | grep "BANCO" | tail -1 ` 
	if ( ! test "$varValEnc" = ""); then		
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"				
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="not configured"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.7.2	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.7.3
	varItem="2.7"
	varItemStandard="2.7.3"		
	varCriticidad="Alto"
	varStanza="/etc/profile"
	varAtributo="AMBIENTE"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Incluir las siguientes líneas en el archivo $varAtributo"
	varValEsp="AMBIENTE"
	varValEnc=`cat $varStanza | tr -d "\t" | grep "AMBIENTE" | tail -1 ` 
	if ( ! test "$varValEnc" = ""); then		
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"				
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="not configured"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.7.3	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.7.4
	varItem="2.7"
	varItemStandard="2.7.4"		
	varCriticidad="Alto"
	varStanza="/etc/profile"
	varAtributo="HOST"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Incluir las siguientes líneas en el archivo $varAtributo"
	varValEsp="HOST"
	varValEnc=`cat $varStanza | tr -d "\t" | grep "HOST" | tail -1 ` 
	if ( ! test "$varValEnc" = ""); then		
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"				
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="not configured"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.7.4	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.8.1
	varItem="2.8"
	varItemStandard="2.8.1"		
	varCriticidad="Alto"
	varStanza="/etc/logo"
	varAtributo="logo"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Copiar el archivo logo en la carpeta  $varAtributo"
	varValEsp="File exists"
	varValEnc=`test -e $varStanza` 
	if ( test "$?" -eq 0); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
		varValEnc="File exists"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="File not exists"	
		fi	
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.8.1	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.9.1
	varItem="2.9"
	varItemStandard="2.9.1"		
	varCriticidad="Alto"
	varStanza="/etc/issue"
	varAtributo="issue"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Respaldar y limpiar los archivos  $varAtributo"
	varValEsp="empty file"
	varValEnc=`test -e $varStanza` 
	if ( test -e $varStanza); then
		varValEnc=`cat $varStanza | wc -m | tr -d " " | tr -d "\t"` 	
		if ( test $varValEnc -eq 0 ); then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 
			varValEnc="empty file"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error" 
			varValEnc="file is not empty"	

		fi	
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
		varValEnc="File not exists"	
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.9.1	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.9.2
	varItem="2.9"
	varItemStandard="2.9.2"		
	varCriticidad="Alto"
	varStanza="/etc/motd"
	varAtributo="issue"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Respaldar y limpiar los archivos  $varAtributo"
	varValEsp="empty file"
	varValEnc=`test -e $varStanza` 
	if ( test "$?" -eq 0); then	
		varValEnc=` cat $varStanza | wc -l ` 	
		if ( test $varValEnc -eq 0 ); then
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 
			varValEnc="empty file"
		else
			varCumplimiento="No Cumple"
			varObservaciones="Error" 
			varValEnc="file is not empty"	

		fi				
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="File not exists"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.9.2	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.10.1
	varItem="2.10."
	varItemStandard="2.10.1"		
	varCriticidad="Alto"
	varStanza="/etc/hosts.equiv"
	varAtributo="hosts.equiv"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Remover los siguientes archivos de la carpeta /etc $varAtributo"
	varValEsp="File not exists"
	varValEnc=`test -e $varStanza` 
	if ( ! test "$?" -eq 0); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
		varValEnc="File not exists"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="File exists"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.10.1	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.10.2
	varItem="2.10."
	varItemStandard="2.10.2"		
	varCriticidad="Alto"
	varStanza="/etc/.rhosts"
	varAtributo=".rhosts"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Remover los siguientes archivos de la carpeta /etc $varAtributo"
	varValEsp="File not exists"
	varValEnc=`test -e $varStanza` 
	if ( ! test "$?" -eq 0); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
		varValEnc="File not exists"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="File exists"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.10.2	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 2.10.3
	varItem="2.10."
	varItemStandard="2.10.3"		
	varCriticidad="Alto"
	varStanza="/etc/.netrc"
	varAtributo=".netrc"
	varDetalle="ITEM $varItem Usuario y accesos al sistema, Remover los siguientes archivos de la carpeta /etc $varAtributo"
	varValEsp="File not exists"
	varValEnc=`test -e $varStanza` 
	if ( ! test "$?" -eq 0); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
		varValEnc="File not exists"
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="File exists"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 2.10.3	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 3.1.1
	varItem="3.1"
	varItemStandard="3.1.1"		
	varCriticidad="Alto"
	varStanza="/etc/security/audit/config"
	varAtributo="binmode"
	varDetalle="ITEM $varItem Parámetros de Auditoría, Configurar las siguientes auditorias de usuarios dentro del archivo en la stanza  $varAtributo"
	varValEsp="binmode = off"
	varValEnc=`cat $varStanza | grep "$varAtributo" | tr -d " " | tr -d "\t" | awk -F= '{print $1, "=", $2 }' | tail -1` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not configurated"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 3.1.1	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 3.1.2
	varItem="3.1"
	varItemStandard="3.1.2"		
	varCriticidad="Alto"
	varStanza="/etc/security/audit/config"
	varAtributo="streammode"
	varDetalle="ITEM $varItem Parámetros de Auditoría, Configurar las siguientes auditorias de usuarios dentro del archivo en la stanza  $varAtributo"
	varValEsp="streammode = off"
	varValEnc=`cat $varStanza | grep "$varAtributo" | tr -d " " | tr -d "\t" | awk -F= '{print $1, "=", $2 }' | tail -1` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not configurated"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 3.1.2	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 3.1.3
	varItem="3.1"
	varItemStandard="3.1.3"		
	varCriticidad="Alto"
	varStanza="/etc/security/audit/config"
	varAtributo="bytethreshold"
	varDetalle="ITEM $varItem Parámetros de Auditoría, Configurar las siguientes auditorias de usuarios dentro del archivo en la stanza  $varAtributo"
	varValEsp="bytethreshold = 0"
	varValEnc=`cat $varStanza | grep "$varAtributo" | tr -d " " | tr -d "\t" | awk -F= '{print $1, "=", $2 }' | tail -1` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not configurated"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 3.1.3	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 3.1.4
	varItem="3.1"
	varItemStandard="3.1.4"		
	varCriticidad="Alto"
	varStanza="/etc/security/audit/config"
	varAtributo="eventhreshold"
	varDetalle="ITEM $varItem Parámetros de Auditoría, Configurar las siguientes auditorias de usuarios dentro del archivo en la stanza  $varAtributo"
	varValEsp="eventhreshold = 1000"
	varValEnc=`cat $varStanza | grep "$varAtributo" | tr -d " " | tr -d "\t" | awk -F= '{print $1, "=", $2 }' | tail -1` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not configurated"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 3.1.4	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 3.1.5
	varItem="3.1"
	varItemStandard="3.1.5"		
	varCriticidad="Alto"
	varStanza="/etc/security/audit/config"
	varAtributo="default"
	varDetalle="ITEM $varItem Parámetros de Auditoría, Configurar las siguientes auditorias de usuarios dentro del archivo en la stanza  $varAtributo"
	varValEsp="default = login"
	varValEnc=`cat $varStanza  | tr -d "\t" | tr -d " " | awk -F"=" '/default/ {if ($2=="login") print $1, "=", $2}'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not configurated"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 3.1.5	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 3.1.6
	varItem="3.1"
	varItemStandard="3.1.6"		
	varCriticidad="Alto"
	varStanza="/etc/security/audit/config"
	varAtributo="login"
	varDetalle="ITEM $varItem Parámetros de Auditoría, Configurar las siguientes auditorias de usuarios dentro del archivo en la stanza  $varAtributo"
	varValEsp="Login = USER_SU,USER_Login,USER_Logout,TERM_Logout,USER_Exit"
	varValEnc=`cat $varStanza | grep "Login = USER_SU,USER_Login,USER_Logout,TERM_Logout,USER_Exit" | tr -d " " | tr -d "\t" | awk -F= '{print $1, "=", $2 }' | tail -1` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not configurated"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 3.1.6	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 3.2.1
	varItem="3.2"
	varItemStandard="3.2.1"		
	varCriticidad="Alto"
	varStanza="/etc/syslog.conf"
	varAtributo=""
	varDetalle="ITEM $varItem Parámetros de Auditoría, Verificar que los siguientes logs existan $varAtributo"
	varValEsp=$varStanza
	varValEnc=`ls -ltr $varStanza | awk '{print $9 }'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 3.2.1	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 3.2.2
	varItem="3.2"
	varItemStandard="3.2.2"		
	varCriticidad="Alto"
	varStanza="/etc/utmp"
	varAtributo=""
	varDetalle="ITEM $varItem Parámetros de Auditoría, Verificar que los siguientes logs existan $varAtributo"
	varValEsp=$varStanza
	varValEnc=`ls -ltr $varStanza | awk '{print $9 }'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 3.2.2	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 3.2.3
	varItem="3.2"
	varItemStandard="3.2.3"		
	varCriticidad="Alto"
	varStanza="/var/adm/wtmp"
	varAtributo=""
	varDetalle="ITEM $varItem Parámetros de Auditoría, Verificar que los siguientes logs existan $varAtributo"
	varValEsp=$varStanza
	varValEnc=`ls -ltr $varStanza | awk '{print $9 }'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 3.2.3	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 3.2.4
	varItem="3.2"
	varItemStandard="3.2.4"		
	varCriticidad="Alto"
	varStanza="/etc/security/failedlogin"
	varAtributo=""
	varDetalle="ITEM $varItem Parámetros de Auditoría, Verificar que los siguientes logs existan $varAtributo"
	varValEsp=$varStanza
	varValEnc=`ls -ltr $varStanza | awk '{print $9 }'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 3.2.4	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 3.2.5
	varItem="3.2"
	varItemStandard="3.2.5"		
	varCriticidad="Alto"
	varStanza="/etc/security/lastlog"
	varAtributo=""
	varDetalle="ITEM $varItem Parámetros de Auditoría, Verificar que los siguientes logs existan $varAtributo"
	varValEsp=$varStanza
	varValEnc=`ls -ltr $varStanza | awk '{print $9 }'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 3.2.5	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 3.2.6
	varItem="3.2"
	varItemStandard="3.2.6"		
	varCriticidad="Alto"
	varStanza="/var/adm/sulog"
	varAtributo=""
	varDetalle="ITEM $varItem Parámetros de Auditoría, Verificar que los siguientes logs existan $varAtributo"
	varValEsp=$varStanza
	varValEnc=`ls -ltr $varStanza | awk '{print $9 }'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 3.2.6	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 3.2.7
	varItem="3.2"
	varItemStandard="3.2.7"		
	varCriticidad="Alto"
	varStanza="/etc/security/portlog"
	varAtributo=""
	varDetalle="ITEM $varItem Parámetros de Auditoría, Verificar que los siguientes logs existan $varAtributo"
	varValEsp=$varStanza
	varValEnc=`ls -ltr $varStanza | awk '{print $9 }'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 3.2.7	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 3.3.1
	varItem="3.3"
	varItemStandard="3.3.1"		
	varCriticidad="Alto"
	varStanza="/etc/syslog.conf"
	varAtributo="mail.debug"
	varDetalle="ITEM $varItem Parámetros de Auditoría,Configurar las siguientes entradas en el archivo /etc/syslog.conf $varAtributo"
	varValEsp="mail.debug /var/log/mail"
	varValEnc=`cat $varStanza | grep "^$varAtributo" | awk '{print $1, $2}'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 3.3.1	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 3.3.2
	varItem="3.3"
	varItemStandard="3.3.2"		
	varCriticidad="Alto"
	varStanza="/etc/syslog.conf"
	varAtributo="user.debug"
	varDetalle="ITEM $varItem Parámetros de Auditoría,Configurar las siguientes entradas en el archivo /etc/syslog.conf $varAtributo"
	varValEsp="user.debug /var/log/user"
	varValEnc=`cat $varStanza | awk '/user.debug/{if ($2!="") print $1, $2}' | tail -1`
	varValCon=`echo $varValEnc | wc -m | tr -d " " | tr -d "\t"`
	if ( test $varValCon -gt 1 ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 3.3.2	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 3.3.3
	varItem="3.3"
	varItemStandard="3.3.3"		
	varCriticidad="Alto"
	varStanza="/etc/syslog.conf"
	varAtributo="kern.debug"
	varDetalle="ITEM $varItem Parámetros de Auditoría,Configurar las siguientes entradas en el archivo /etc/syslog.conf $varAtributo"
	varValEsp="kern.debug /var/log/kern"
	varValEnc=`cat $varStanza | awk '/kern.debug/{if ($2!="") print $1, $2}' | tail -1`
	varValCon=`echo $varValEnc | wc -m | tr -d " " | tr -d "\t"`
	if ( test $varValCon -gt 1 ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 3.3.3	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 3.3.4
	varItem="3.3"
	varItemStandard="3.3.4"		
	varCriticidad="Alto"
	varStanza="/etc/syslog.conf"
	varAtributo="syslog.debug"
	varDetalle="ITEM $varItem Parámetros de Auditoría,Configurar las siguientes entradas en el archivo /etc/syslog.conf $varAtributo"
	varValEsp="syslog.debug /var/log/syslog"
	varValEnc=`cat $varStanza | grep "^$varAtributo" | awk '{print $1, $2}'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 3.3.4	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 3.3.5
	varItem="3.3"
	varItemStandard="3.3.5"		
	varCriticidad="Alto"
	varStanza="/etc/syslog.conf"
	varAtributo="daemon.debug"
	varDetalle="ITEM $varItem Parámetros de Auditoría,Configurar las siguientes entradas en el archivo /etc/syslog.conf $varAtributo"
	varValEsp="daemon.debug /var/log/daemon"
	varValEnc=`cat $varStanza | awk '/daemon.debug/{if ($2!="") print $1, $2}' | tail -1`
	varValCon=`echo $varValEnc | wc -m | tr -d " " | tr -d "\t"`
	if ( test $varValCon -gt 1 ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 3.3.5	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 3.3.6
	varItem="3.3"
	varItemStandard="3.3.6"		
	varCriticidad="Alto"
	varStanza="/etc/syslog.conf"
	varAtributo="auth.debug"
	varDetalle="ITEM $varItem Parámetros de Auditoría,Configurar las siguientes entradas en el archivo /etc/syslog.conf $varAtributo"
	varValEsp="auth.debug /var/log/secure"
	varValEnc=`cat $varStanza | awk '/auth.debug/{if ($2!="") print $1, $2}' | tail -1`
	varValCon=`echo $varValEnc | wc -m | tr -d " " | tr -d "\t"`
	if ( test $varValCon -gt 1 ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 3.3.6	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 3.3.7
	varItem="3.3"
	varItemStandard="3.3.7"		
	varCriticidad="Alto"
	varStanza="/etc/syslog.conf"
	varAtributo="local2.debug"
	varDetalle="ITEM $varItem Parámetros de Auditoría,Configurar las siguientes entradas en el archivo /etc/syslog.conf $varAtributo"
	varValEsp="local2.debug /var/log/sudo"
	varValEnc=`cat $varStanza | grep "^$varAtributo" | awk '{print $1, $2}'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 3.3.7	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.1.1
	varItem="4.1"
	varItemStandard="4.1.1"		
	varCriticidad="Alto"
	varStanza="default"
	varAtributo="minlen"
	varDetalle="ITEM $varItem Políticas de Usuarios, Habilitar las políticas de passwords con los siguientes valores /etc/security/user $varStanza"
	varValEsp="minlen=8"
	varValEnc=`lssec -f /etc/security/user -s $varStanza -a $varAtributo | awk '{print $2}'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not configurated"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.1.1	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.1.2
	varItem="4.1"
	varItemStandard="4.1.2"		
	varCriticidad="Alto"
	varStanza="default"
	varAtributo="minother"
	varDetalle="ITEM $varItem Políticas de Usuarios, Habilitar las políticas de passwords con los siguientes valores /etc/security/user $varStanza"
	varValEsp="minother=2"
	varValEnc=`lssec -f /etc/security/user -s $varStanza -a $varAtributo | awk '{print $2}'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not configurated"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.1.2	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.1.3
	varItem="4.1"
	varItemStandard="4.1.3"		
	varCriticidad="Alto"
	varStanza="default"
	varAtributo="maxrepeats"
	varDetalle="ITEM $varItem Políticas de Usuarios, Habilitar las políticas de passwords con los siguientes valores /etc/security/user $varStanza"
	varValEsp="maxrepeats=3"
	varValEnc=`lssec -f /etc/security/user -s $varStanza -a $varAtributo | awk '{print $2}'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not configurated"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.1.3	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.1.4
	varItem="4.1"
	varItemStandard="4.1.4"		
	varCriticidad="Alto"
	varStanza="default"
	varAtributo="maxage"
	varDetalle="ITEM $varItem Políticas de Usuarios, Habilitar las políticas de passwords con los siguientes valores /etc/security/user $varStanza"
	varValEsp="maxage=4"
	varValEnc=`lssec -f /etc/security/user -s $varStanza -a $varAtributo | awk '{print $2}'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not configurated"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.1.4	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.1.5
	varItem="4.1"
	varItemStandard="4.1.5"		
	varCriticidad="Alto"
	varStanza="default"
	varAtributo="histexpire"
	varDetalle="ITEM $varItem Políticas de Usuarios, Habilitar las políticas de passwords con los siguientes valores /etc/security/user $varStanza"
	varValEsp="histexpire=52"
	varValEnc=`lssec -f /etc/security/user -s $varStanza -a $varAtributo | awk '{print $2}'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not configurated"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.1.5	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.1.6
	varItem="4.1"
	varItemStandard="4.1.6"		
	varCriticidad="Alto"
	varStanza="default"
	varAtributo="histsize"
	varDetalle="ITEM $varItem Políticas de Usuarios, Habilitar las políticas de passwords con los siguientes valores /etc/security/user $varStanza"
	varValEsp="histsize=20"
	varValEnc=`lssec -f /etc/security/user -s $varStanza -a $varAtributo | awk '{print $2}'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not configurated"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.1.6	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.1.7
	varItem="4.1"
	varItemStandard="4.1.7"		
	varCriticidad="Alto"
	varStanza="default"
	varAtributo="loginretries"
	varDetalle="ITEM $varItem Políticas de Usuarios, Habilitar las políticas de passwords con los siguientes valores /etc/security/user $varStanza"
	varValEsp="loginretries=3"
	varValEnc=`lssec -f /etc/security/user -s $varStanza -a $varAtributo | awk '{print $2}'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not configurated"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.1.7	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.1.8
	varItem="4.1"
	varItemStandard="4.1.8"		
	varCriticidad="Alto"
	varStanza="default"
	varAtributo="minage"
	varDetalle="ITEM $varItem Políticas de Usuarios, Habilitar las políticas de passwords con los siguientes valores /etc/security/user $varStanza"
	varValEsp="minage=0"
	varValEnc=`lssec -f /etc/security/user -s $varStanza -a $varAtributo | awk '{print $2}'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not configurated"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.1.8	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.1.9
	varItem="4.1"
	varItemStandard="4.1.9"		
	varCriticidad="Alto"
	varStanza="default"
	varAtributo="pwdwarntime"
	varDetalle="ITEM $varItem Políticas de Usuarios, Habilitar las políticas de passwords con los siguientes valores /etc/security/user $varStanza"
	varValEsp="pwdwarntime=7"
	varValEnc=`lssec -f /etc/security/user -s $varStanza -a $varAtributo | awk '{print $2}'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not configurated"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.1.9	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.1.10
	varItem="4.1"
	varItemStandard="4.1.10"		
	varCriticidad="Alto"
	varStanza="default"
	varAtributo="maxexpired"
	varDetalle="ITEM $varItem Políticas de Usuarios, Habilitar las políticas de passwords con los siguientes valores /etc/security/user $varStanza"
	varValEsp="maxexpired=-1"
	varValEnc=`lssec -f /etc/security/user -s $varStanza -a $varAtributo | awk '{print $2}'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not configurated"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.1.10	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.1.11
	varItem="4.1"
	varItemStandard="4.1.11"		
	varCriticidad="Alto"
	varStanza="default"
	varAtributo="minalpha"
	varDetalle="ITEM $varItem Políticas de Usuarios, Habilitar las políticas de passwords con los siguientes valores /etc/security/user $varStanza"
	varValEsp="minalpha=1"
	varValEnc=`lssec -f /etc/security/user -s $varStanza -a $varAtributo | awk '{print $2}'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not configurated"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.1.11	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.2.1
	varItem="4.2"
	varItemStandard="4.2.1"		
	varCriticidad="Alto"
	varStanza="default"
	varAtributo="registry"
	varDetalle="ITEM $varItem Políticas de Usuarios, Configurar el parámetro registry con el valor files dentro del archivo $varStanza"
	varValEsp="registry=files"
	varValEnc=`lssec -f /etc/security/user -s $varStanza -a $varAtributo | awk '{print $2}'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not configurated"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.2.1	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.3.1
	varItem="4.3"
	varItemStandard="4.3.1"		
	varCriticidad="Alto"
	varStanza="default"
	varAtributo="umask"
	varDetalle="ITEM $varItem Políticas de Usuarios, Configurar el parámetro umask con el valor 077 dentro del archivo $varStanza"
	varValEsp="umask=77"
	varValEnc=`lssec -f /etc/security/user -s $varStanza -a $varAtributo | awk '{print $2}'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.3.1	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.4.1
	varItem="4.4"
	varItemStandard="4.4.1"		
	varCriticidad="Alto"
	varStanza="/etc/profile"
	varAtributo="export readonly TMOUT TIMEOUT"
	varDetalle="ITEM $varItem Políticas de Usuarios, Forzar logoff automatico $varStanza"
	varValEsp="TMOUT=600 TIMEOUT=600 export readonly TMOUT TIMEOUT"
	varValEnc=`cat $varStanza | grep "$varAtributo" | tail -1 | tr -d ";"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.4.1	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.4.2
	varItem="4.4"
	varItemStandard="4.4.2"		
	varCriticidad="Alto"
	varStanza="/etc/security/.profile"
	varAtributo="export readonly TMOUT TIMEOUT"
	varDetalle="ITEM $varItem Políticas de Usuarios, Forzar logoff automatico $varStanza"
	varValEsp="TMOUT=600 TIMEOUT=600 export readonly TMOUT TIMEOUT"
	varValEnc=`cat $varStanza | grep "$varAtributo" | tail -1 | tr -d ";"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.4.2	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.5.1 PENDIENTE ***********************
	varItem="4.5"
	varItemStandard="4.5.1"		
	varCriticidad="Alto"
	varStanza="/etc/security/.profile"
	varAtributo="usrpsiux"
	varDetalle="ITEM $varItem Políticas de Usuarios, Verificar que el usuario: USRPSIUX se encuentre creado y pertenezca al grupo: adm $varStanza"
	varValEsp="usrpsiux groups=adm"
	varValEnc=`lsuser -a groups usrpsiux | grep "adm" | awk -F "groups=" '{print $2}'` 
	if ( test "$varValEnc" = "" ); then	
		varCumplimiento=" No Cumple"
		varValEnc="Does Not Configurated" 
		varObservaciones="Error"
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.5.1	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.5.2 
	varItem="4.5"
	varItemStandard="4.5.2"		
	varCriticidad="Alto"
	varStanza="/etc/security/.profile"
	varAtributo="TMOUT"
	varDetalle="ITEM $varItem Políticas de Usuarios, Verificar que el usuario: USRPDDAI se encuentre creado y con roles específicos: adm $varStanza"
	varValEsp="usrpddai  roles=default, ManageBasicUsers, ManageBackupRestore, ManageBackup, RunDiagnostics, ManageDiskQuota"
	varValEnc=`lsuser -a roles usrpddai | grep default | grep ManageBasicUsers | grep ManageBackupRestore | grep ManageBackup | grep RunDiagnostics | grep ManageDiskQuota | awk -F "roles=" '{print $2}'` 
	if ( test "$varValEnc" = "" ); then	
		varCumplimiento=" No Cumple"
		varValEnc="Does Not Configurated" 
		varObservaciones="Error"
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.5.1	
#------------------------------------------



#------------------------------------------
# [INICIO] ÍTEM 4.8.1
	varItem="4.8"
	varItemStandard="4.8.1"		
	varCriticidad="Alto"
	varStanza="/var/wrdrestrict"
	varAtributo="rootROOT"
	varDetalle="ITEM $varItem Políticas de Usuarios, Restringir claves débiles: $varStanza"
	varValEsp=$varAtributo
	varValEnc=`cat $varStanza | grep "^$varAtributo" | tail -1` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.8.1	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.8.2
	varItem="4.8"
	varItemStandard="4.8.2"		
	varCriticidad="Alto"
	varStanza="/var/wrdrestrict"
	varAtributo="ROOTroot"
	varDetalle="ITEM $varItem Políticas de Usuarios, Restringir claves débiles: $varStanza"
	varValEsp=$varAtributo
	varValEnc=`cat $varStanza | grep "^$varAtributo" | tail -1` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.8.2	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.8.3
	varItem="4.8"
	varItemStandard="4.8.3"		
	varCriticidad="Alto"
	varStanza="/var/wrdrestrict"
	varAtributo="testTEST"
	varDetalle="ITEM $varItem Políticas de Usuarios, Restringir claves débiles: $varStanza"
	varValEsp=$varAtributo
	varValEnc=`cat $varStanza | grep "^$varAtributo" | tail -1` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.8.3	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.8.4
	varItem="4.8"
	varItemStandard="4.8.4"		
	varCriticidad="Alto"
	varStanza="/var/wrdrestrict"
	varAtributo="12345678"
	varDetalle="ITEM $varItem Políticas de Usuarios, Restringir claves débiles: $varStanza"
	varValEsp=$varAtributo
	varValEnc=`cat $varStanza | grep "^$varAtributo" | tail -1` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.8.4	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.8.5
	varItem="4.8"
	varItemStandard="4.8.5"		
	varCriticidad="Alto"
	varStanza="/var/wrdrestrict"
	varAtributo="87654321"
	varDetalle="ITEM $varItem Políticas de Usuarios, Restringir claves débiles: $varStanza"
	varValEsp=$varAtributo
	varValEnc=`cat $varStanza | grep "^$varAtributo" | tail -1` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.8.5	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.8.6
	varItem="4.8"
	varItemStandard="4.8.6"		
	varCriticidad="Alto"
	varStanza="/var/wrdrestrict"
	varAtributo="qwerty12"
	varDetalle="ITEM $varItem Políticas de Usuarios, Restringir claves débiles: $varStanza"
	varValEsp=$varAtributo
	varValEnc=`cat $varStanza | grep "^$varAtributo" | tail -1` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.8.6	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.8.7
	varItem="4.8"
	varItemStandard="4.8.7"		
	varCriticidad="Alto"
	varStanza="/var/wrdrestrict"
	varAtributo="abcdefgh"
	varDetalle="ITEM $varItem Políticas de Usuarios, Restringir claves débiles: $varStanza"
	varValEsp=$varAtributo
	varValEnc=`cat $varStanza | grep "^$varAtributo" | tail -1` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.8.7	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.8.8
	varItem="4.8"
	varItemStandard="4.8.8"		
	varCriticidad="Alto"
	varStanza="/var/wrdrestrict"
	varAtributo="1234abcd"
	varDetalle="ITEM $varItem Políticas de Usuarios, Restringir claves débiles: $varStanza"
	varValEsp=$varAtributo
	varValEnc=`cat $varStanza | grep "^$varAtributo" | tail -1` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.8.8	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.8.9
	varItem="4.8"
	varItemStandard="4.8.9"		
	varCriticidad="Alto"
	varStanza="/var/wrdrestrict"
	varAtributo="1234ABCD"
	varDetalle="ITEM $varItem Políticas de Usuarios, Restringir claves débiles: $varStanza"
	varValEsp=$varAtributo
	varValEnc=`cat $varStanza | grep "^$varAtributo" | tail -1` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.8.9	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 4.8.10
	varItem="4.8"
	varItemStandard="4.8.10"		
	varCriticidad="Alto"
	varStanza="/etc/security/user"
	varAtributo="=/var/wrdrestrict"
	varDetalle="ITEM $varItem Políticas de Usuarios, Restringir claves débiles: $varStanza"
	varValEsp="dictionlist =/var/wrdrestrict"
	varValEnc=`cat $varStanza | grep "$varAtributo" | tr -d "\t" | tail -1 | awk '{print $1, $2 }'` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No Cumple"
		varObservaciones="Error"
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exists file"	
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 4.8.10	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 5.1.1
	varItem="5.1"
	varItemStandard="5.1.1"		
	varCriticidad="Alto"
	varStanza=""
	varAtributo=""
	varDetalle="ITEM $varItem Instalar y probar los últimos parches de seguridad autorizados para AIX $varStanza"
	varValEsp="7200-05-03-2148"
	varValEnc=`oslevel -s AIX | grep "2148"` 
	if ( test "$varValEnc" = "" ); then	
		varCumplimiento="no Cumple"
		varObservaciones="Error" 
	else
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		varValEnc="No Actualizado"
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 5.1.1	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.1
	varItem="6.1"
	varItemStandard="6.1.1"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="bootps dgram"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#bootps dgram udp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.1	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.2
	varItem="6.1"
	varItemStandard="6.1.2"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="chargen dgram"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#chargen dgram udp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.2	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.3
	varItem="6.1"
	varItemStandard="6.1.3"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="cmsd sunrpc_udp"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#cmsd sunrpc_udp udp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.3	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.4
	varItem="6.1"
	varItemStandard="6.1.4"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="comsat dgram"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#comsat dgram udp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.4	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.5
	varItem="6.1"
	varItemStandard="6.1.5"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="daytime stream"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#daytime stream tcp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.5	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.6
	varItem="6.1"
	varItemStandard="6.1.6"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="discard stream"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#discard stream tcp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.6	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.7
	varItem="6.1"
	varItemStandard="6.1.7"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="dtspc stream"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#dtspc stream tcp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.7	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.8
	varItem="6.1"
	varItemStandard="6.1.8"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="echo stream"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#echo stream tcp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.8	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.9
	varItem="6.1"
	varItemStandard="6.1.9"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="exec stream"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#exec stream tcp6"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.9	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.10
	varItem="6.1"
	varItemStandard="6.1.10"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="finger stream"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#finger stream tcp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.10	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.11
	varItem="6.1"
	varItemStandard="6.1.11"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="ftp stream"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#ftp stream tcp6"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.11	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.12
	varItem="6.1"
	varItemStandard="6.1.12"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="instsrv stream"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#instsrv stream tcp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.12	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.13
	varItem="6.1"
	varItemStandard="6.1.13"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="imap2 stream"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#imap2 stream tcp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.13	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.14
	varItem="6.1"
	varItemStandard="6.1.14"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="klogin stream tcp"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#klogin stream tcp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "^$varAtributo$" | awk '{if ($1=="klogin") print}'`
	if ( test "$varValEnc" != "" ); then	
		varCumplimiento="No cumple"
		varObservaciones="Error"
	else
		varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | awk '{if ($1=="#klogin") print}'`
		if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
		else		
			if ( test "$varValEnc" = "" ); then 
				varValEnc="Not exist"
				varCumplimiento="Cumple"
				varObservaciones="Ninguna" 	
			fi			
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.14	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.15
	varItem="6.1"
	varItemStandard="6.1.15"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="kshell stream"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#kshell stream tcp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.15	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.16
	varItem="6.1"
	varItemStandard="6.1.16"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="login stream"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#login stream tcp6"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "^$varAtributo" | awk '{if ($1=="login") print}'`
	if ( test "$varValEnc" != "" ); then	
		varCumplimiento="No cumple"
		varObservaciones="Error"
	else
		varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | awk '{if ($1=="#login") print}'`
		if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
		else		
			if ( test "$varValEnc" = "" ); then 
				varValEnc="Not exist"
				varCumplimiento="Cumple"
				varObservaciones="Ninguna" 	
			fi			
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.16	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.17
	varItem="6.1"
	varItemStandard="6.1.17"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="netstat stream"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#netstat stream tcp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.17	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.18
	varItem="6.1"
	varItemStandard="6.1.18"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="ntalk dgram"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#ntalk dgram udp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.18	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.19
	varItem="6.1"
	varItemStandard="6.1.19"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="pcnfsd sunrpc_udp"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#pcnfsd sunrpc_udp udp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.19	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.20
	varItem="6.1"
	varItemStandard="6.1.20"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="pop3 stream"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#pop3 stream tcp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.20	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.21
	varItem="6.1"
	varItemStandard="6.1.21"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="rexd sunrpc_tcp"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#rexd sunrpc_tcp tcp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.21	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.22
	varItem="6.1"
	varItemStandard="6.1.22"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="rquotad sunrpc_udp"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#rquotad sunrpc_udp udp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.22	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.23
	varItem="6.1"
	varItemStandard="6.1.23"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="rstatd sunrpc_udp"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#rstatd sunrpc_udp udp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.23	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.24
	varItem="6.1"
	varItemStandard="6.1.24"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="rusersd sunrpc_udp"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#rusersd sunrpc_udp udp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.24	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.25
	varItem="6.1"
	varItemStandard="6.1.25"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="rwalld sunrpc_udp"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#rwalld sunrpc_udp udp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.25	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.26
	varItem="6.1"
	varItemStandard="6.1.26"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="shell stream"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#shell stream tcp6"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "^$varAtributo" | awk '{if ($1=="shell") print}'`
	if ( test "$varValEnc" != "" ); then	
		varCumplimiento="No cumple"
		varObservaciones="Error"
	else
		varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | awk '{if ($1=="#shell") print}'`
		if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
		else		
			if ( test "$varValEnc" = "" ); then 
				varValEnc="Not exist"
				varCumplimiento="Cumple"
				varObservaciones="Ninguna" 	
			fi			
		fi
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.26	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.27
	varItem="6.1"
	varItemStandard="6.1.27"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="sprayd sunrpc_udp"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#sprayd sunrpc_udp udp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.27	
#------------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.28
	varItem="6.1"
	varItemStandard="6.1.28"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="systat stream"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#systat stream tcp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.28	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.29
	varItem="6.1"
	varItemStandard="6.1.29"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="talk dgram"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#talk dgram udp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "^$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "^#$varAtributo" | tail -1 ` 

		if ( test "$varValEnc" = "$varValEsp" ); then 
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.29	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.30
	varItem="6.1"
	varItemStandard="6.1.30"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="telnet stream"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#telnet stream tcp6"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.30	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.31
	varItem="6.1"
	varItemStandard="6.1.31"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="tftp dgram"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#tftp dgram udp6"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.31	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.32
	varItem="6.1"
	varItemStandard="6.1.32"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="time stream"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#time stream tcp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.32	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.33
	varItem="6.1"
	varItemStandard="6.1.33"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="ttdbserver sunrpc_tcp"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#ttdbserver sunrpc_tcp tcp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.33	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.34
	varItem="6.1"
	varItemStandard="6.1.34"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="uucp stream"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#uucp stream tcp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 ` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.34	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.1.35
	varItem="6.1"
	varItemStandard="6.1.35"		
	varCriticidad="Alto"
	varStanza="/etc/inetd.conf"
	varAtributo="wsmserver"
	varDetalle="ITEM $varItem Servicios de Red, Deshabilitar (Comentar #) las siguientes entradas en el archivo $varStanza"
	varValEsp="#wsmserver stream tcp"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "^$varAtributo" | awk '{if ($1=="wsmserver") print}'`
	if ( test "$varValEnc" != "" ); then	
		varCumplimiento="No cumple"
		varObservaciones="Error"
	else
		varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | awk '{if ($1=="#wsmserver") print}'`
		if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
		else		
			if ( test "$varValEnc" = "" ); then 
				varValEnc="Not exist"
				varCumplimiento="Cumple"
				varObservaciones="Ninguna" 	
			fi			
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.1.35	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.2.1
	varItem="6.2"
	varItemStandard="6.2.1"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/autoconf6"
	varDetalle="ITEM $varItem Servicios de Red, Comentar (#) principalmente los siguientes demonios $varStanza"
	varValEsp="#start /usr/sbin/autoconf6 \"\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 | tr -s "#"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.2.1	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.2.2
	varItem="6.2"
	varItemStandard="6.2.2"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="ctrmc"
	varDetalle="ITEM $varItem Servicios de Red, Comentar (#) principalmente los siguientes demonios $varStanza"
	varValEsp="#ctrmc"
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 | tr -s "#"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.2.2	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.2.3
	varItem="6.2"
	varItemStandard="6.2.3"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/dhcpcd"
	varDetalle="ITEM $varItem Servicios de Red, Comentar (#) principalmente los siguientes demonios $varStanza"
	varValEsp="#start /usr/sbin/dhcpcd \"\$src_running\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 | tr -s "#"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.2.3	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.2.4
	varItem="6.2"
	varItemStandard="6.2.4"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/dhcprd"
	varDetalle="ITEM $varItem Servicios de Red, Comentar (#) principalmente los siguientes demonios $varStanza"
	varValEsp="#start /usr/sbin/dhcprd \"\$src_running\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 | tr -s "#"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.2.4	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.2.5
	varItem="6.2"
	varItemStandard="6.2.5"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/dhcpsd"
	varDetalle="ITEM $varItem Servicios de Red, Comentar (#) principalmente los siguientes demonios $varStanza"
	varValEsp="#start /usr/sbin/dhcpsd \"\$src_running\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 | tr -s "#"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.2.5	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.2.6
	varItem="6.2"
	varItemStandard="6.2.6"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/dpid2"
	varDetalle="ITEM $varItem Servicios de Red, Comentar (#) principalmente los siguientes demonios $varStanza"
	varValEsp="#start /usr/sbin/dpid2 \"\$src_running\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 | tr -s "#"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.2.6	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.2.7
	varItem="6.2"
	varItemStandard="6.2.7"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/gated"
	varDetalle="ITEM $varItem Servicios de Red, Comentar (#) principalmente los siguientes demonios $varStanza"
	varValEsp="#start /usr/sbin/gated \"\$src_running\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 | tr -s "#"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.2.7	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.2.8
	varItem="6.2"
	varItemStandard="6.2.8"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/lpd"
	varDetalle="ITEM $varItem Servicios de Red, Comentar (#) principalmente los siguientes demonios $varStanza"
	varValEsp="#start /usr/sbin/lpd \"\$src_running\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 | tr -s "#"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.2.8	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.2.9
	varItem="6.2"
	varItemStandard="6.2.9"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/mrouted"
	varDetalle="ITEM $varItem Servicios de Red, Comentar (#) principalmente los siguientes demonios $varStanza"
	varValEsp="#start /usr/sbin/mrouted \"\$src_running\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 | tr -s "#"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.2.9	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.2.10
	varItem="6.2"
	varItemStandard="6.2.10"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/named"
	varDetalle="ITEM $varItem Servicios de Red, Comentar (#) principalmente los siguientes demonios $varStanza"
	varValEsp="#start /usr/sbin/named \"\$src_running\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 | tr -s "#"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.2.10	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.2.11
	varItem="6.2"
	varItemStandard="6.2.11"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/ndnpd-router"
	varDetalle="ITEM $varItem Servicios de Red, Comentar (#) principalmente los siguientes demonios $varStanza"
	varValEsp="#start /usr/sbin/ndnpd-router \"\$src_running\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 | tr -s "#"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.2.11	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.2.12
	varItem="6.2"
	varItemStandard="6.2.12"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/ndpd-host"
	varDetalle="ITEM $varItem Servicios de Red, Comentar (#) principalmente los siguientes demonios $varStanza"
	varValEsp="#start /usr/sbin/ndpd-host \"\$src_running\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 | tr -s "#"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.2.12	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.2.13
	varItem="6.2"
	varItemStandard="6.2.13"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/nscd"
	varDetalle="ITEM $varItem Servicios de Red, Comentar (#) principalmente los siguientes demonios $varStanza"
	varValEsp="#start /usr/sbin/nscd \"\$src_running\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 | tr -s "#"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.2.13	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.2.14
	varItem="6.2"
	varItemStandard="6.2.14"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/PPP"
	varDetalle="ITEM $varItem Servicios de Red, Comentar (#) principalmente los siguientes demonios $varStanza"
	varValEsp="#start /usr/sbin/PPP \"\$src_running\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 | tr -s "#"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.2.14	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.2.15
	varItem="6.2"
	varItemStandard="6.2.15"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/routed"
	varDetalle="ITEM $varItem Servicios de Red, Comentar (#) principalmente los siguientes demonios $varStanza"
	varValEsp="#start /usr/sbin/routed \"\$src_running\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 | tr -s "#"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.2.15	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.2.16
	varItem="6.2"
	varItemStandard="6.2.16"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/rwhod"
	varDetalle="ITEM $varItem Servicios de Red, Comentar (#) principalmente los siguientes demonios $varStanza"
	varValEsp="#start /usr/sbin/rwhod \"\$src_running\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 | tr -s "#"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.2.16	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.2.17
	varItem="6.2"
	varItemStandard="6.2.17"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/sendmail"
	varDetalle="ITEM $varItem Servicios de Red, Comentar (#) principalmente los siguientes demonios $varStanza"
	varValEsp="#start /usr/sbin/sendmail \"\$src_running\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 | tr -s "#"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.2.17	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.2.18
	varItem="6.2"
	varItemStandard="6.2.18"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/timed"
	varDetalle="ITEM $varItem Servicios de Red, Comentar (#) principalmente los siguientes demonios $varStanza"
	varValEsp="#start /usr/sbin/timed \"\$src_running\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 | tr -s "#"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.2.18	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.2.19
	varItem="6.2"
	varItemStandard="6.2.19"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/uucp"
	varDetalle="ITEM $varItem Servicios de Red, Comentar (#) principalmente los siguientes demonios $varStanza"
	varValEsp="#start /usr/sbin/uucp \"\$src_running\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 | tr -s "#"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.2.19	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.2.20
	varItem="6.2"
	varItemStandard="6.2.20"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/vold"
	varDetalle="ITEM $varItem Servicios de Red, Comentar (#) principalmente los siguientes demonios $varStanza"
	varValEsp="#start /usr/sbin/vold \"\$src_running\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 | tr -s "#"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.2.20	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.2.21
	varItem="6.2"
	varItemStandard="6.2.21"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/writesrv"
	varDetalle="ITEM $varItem Servicios de Red, Comentar (#) principalmente los siguientes demonios $varStanza"
	varValEsp="#start /usr/sbin/writesrv \"\$src_running\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo" | tail -1 | tr -s "#"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.2.21	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.3.1
	varItem="6.3"
	varItemStandard="6.3.1"		
	varCriticidad="Alto"
	varStanza="/etc/inittab"
	varAtributo="writesrv:"
	varDetalle="ITEM $varItem Comentar ( : ) las entradas innecesarias en el archivo $varStanza"
	varValEsp=":writesrv:"
	varValEnc=`cat $varStanza | awk -F":wait" '{print $1}' | grep "^$varAtributo" | tr -d " "` 
	varValSub=`echo $varValEnc | wc -c`
	if ( test $varValSub -gt 1 ); then	
		varCumplimiento="No cumple"
		varObservaciones="Error"
	else
		varValEnc=`cat $varStanza | awk -F":wait" '{print $1}' | grep "^:$varAtributo" | tr -d " "` 
		varValSub=`echo $varValEnc | wc -c` 
		if ( test $varValSub -gt 1 ); then	
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 
		else			
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 						
		fi
	fi	
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.3.1	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.3.2
	varItem="6.3"
	varItemStandard="6.3.2"		
	varCriticidad="Alto"
	varStanza="/etc/inittab"
	varAtributo="uprintfd:"
	varDetalle="ITEM $varItem Comentar ( : ) las entradas innecesarias en el archivo $varStanza"
	varValEsp=":uprintfd:23456789:respawn:"
	varValEnc=`cat $varStanza | awk -F"/" '{print $1}' | grep "$varAtributo" | tail -1 | tr -s ":"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.3.2	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.3.3
	varItem="6.3"
	varItemStandard="6.3.3"		
	varCriticidad="Alto"
	varStanza="/etc/inittab"
	varAtributo="httpdlite:"
	varDetalle="ITEM $varItem Comentar ( : ) las entradas innecesarias en el archivo $varStanza"
	varValEsp=":httpdlite:23456789:once:"
	varValEnc=`cat $varStanza | awk -F"/" '{print $1}' | grep "$varAtributo" | tail -1 | tr -s ":"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.3.3	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.3.4
	varItem="6.3"
	varItemStandard="6.3.4"		
	varCriticidad="Alto"
	varStanza="/etc/inittab"
	varAtributo="imnss:"
	varDetalle="ITEM $varItem Comentar ( : ) las entradas innecesarias en el archivo $varStanza"
	varValEsp=":imnss:2:once:"
	varValEnc=`cat $varStanza | awk -F"/" '{print $1}' | grep "$varAtributo" | tail -1 | tr -s ":"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.3.4	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.3.5
	varItem="6.3"
	varItemStandard="6.3.5"		
	varCriticidad="Alto"
	varStanza="/etc/inittab"
	varAtributo="imqss:"
	varDetalle="ITEM $varItem Comentar ( : ) las entradas innecesarias en el archivo $varStanza"
	varValEsp=":imqss:2:once:"
	varValEnc=`cat $varStanza | awk -F"/" '{print $1}' | grep "$varAtributo" | tail -1 | tr -s ":"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.3.5	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.3.6
	varItem="6.3"
	varItemStandard="6.3.6"		
	varCriticidad="Alto"
	varStanza="/etc/inittab"
	varAtributo="rcnfs:"
	varDetalle="ITEM $varItem Comentar ( : ) las entradas innecesarias en el archivo $varStanza"
	varValEsp=":rcnfs:"
	varValEnc=`cat $varStanza | awk -F":wait" '{print $1}' | grep "^$varAtributo" | tr -d " "` 
	varValSub=`echo $varValEnc | wc -c`
	if ( test $varValSub -gt 1 ); then	
		varCumplimiento="No cumple"
		varObservaciones="Error"		
	else
		varValEnc=`cat $varStanza | awk -F":wait" '{print $1}' | grep "^:$varAtributo" | tr -d " "` 
		varValSub=`echo $varValEnc | wc -c`
		if ( test $varValSub -gt 1 ); then	
			varCumplimiento="Cumple"
			varObservaciones="Ninguna"
		else			
			varValEnc="Not exist"
			varCumplimiento="No Cumple"
			varObservaciones="Error" 						
		fi
	fi	
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.3.6	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.3.7
	varItem="6.3"
	varItemStandard="6.3.7"		
	varCriticidad="Alto"
	varStanza="/etc/inittab"
	varAtributo="qdaemon:"
	varDetalle="ITEM $varItem Comentar ( : ) las entradas innecesarias en el archivo $varStanza"
	varValEsp=":qdaemon:"
	varValEnc=`cat $varStanza | awk -F":wait" '{print $1}' | grep "^$varAtributo" | tr -d " "` 
	varValSub=`echo $varValEnc | wc -c`
	if ( test $varValSub -gt 1 ); then	
		varCumplimiento="No cumple"
		varObservaciones="Error"
	else
		varValEnc=`cat $varStanza | awk -F":wait" '{print $1}' | grep "^:$varAtributo" | tr -d " "` 
		varValSub=`echo $varValEnc | wc -c`
		if ( test $varValSub -gt 1 ); then	
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 
		else			
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 						
		fi
	fi	
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.3.7	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.3.8
	varItem="6.3"
	varItemStandard="6.3.8"		
	varCriticidad="Alto"
	varStanza="/etc/inittab"
	varAtributo="piobe:"
	varDetalle="ITEM $varItem Comentar ( : ) las entradas innecesarias en el archivo $varStanza"
	varValEsp=":piobe:2:wait:"
	varValEnc=`cat $varStanza | awk -F"/" '{print $1}' | grep "$varAtributo" | tail -1 | tr -s ":"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.3.8	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.3.9
	varItem="6.3"
	varItemStandard="6.3.9"		
	varCriticidad="Alto"
	varStanza="/etc/inittab"
	varAtributo="lpd:"
	varDetalle="ITEM $varItem Comentar ( : ) las entradas innecesarias en el archivo $varStanza"
	varValEsp=":lpd:2:wait:"
	varValEnc=`cat $varStanza | awk -F"/" '{print $1}' | grep "$varAtributo" | tail -1 | tr -s ":"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.3.9	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.3.10
	varItem="6.3"
	varItemStandard="6.3.10"		
	varCriticidad="Alto"
	varStanza="/etc/inittab"
	varAtributo="dt:"
	varDetalle="ITEM $varItem Comentar ( : ) las entradas innecesarias en el archivo $varStanza"
	varValEsp=":dt:2:wait:"
	varValEnc=`cat $varStanza | awk -F"/" '{print $1}' | grep "$varAtributo" | tail -1 | tr -s ":"` 
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		if ( test "$varValEnc" = "" ); then 
			varValEnc="Not exist"
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 	
		else
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
		
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.3.10	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.4.1
	varItem="6.4"
	varItemStandard="6.4.1"		
	varCriticidad="Alto"
	varStanza="/etc/rc.nfs"
	varAtributo="automount"
	varDetalle="ITEM $varItem Comentar ( # ) los siguientes servicios NIS en el archivo $varStanza"	
	varValEsp=`grep "$varAtributo" /etc/rc.nfs | wc -l | tr -d " " | tr -d "\t" `
	varValEnc=`grep "$varAtributo" /etc/rc.nfs | awk '/#/' | wc -l | tr -d " " | tr -d "\t"` 
	varValDet="Servicio esperado $varAtributo # $varValEsp"
	if ( test "$varValEnc" -eq "$varValEsp" ); then
			
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi
	varValEsp="$varValDet"
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.4.1	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.4.2
	varItem="6.4"
	varItemStandard="6.4.2"		
	varCriticidad="Alto"
	varStanza="/etc/rc.nfs"
	varAtributo="domainname"
	varDetalle="ITEM $varItem Comentar ( # ) los siguientes servicios NIS en el archivo $varStanza"	
	varValEsp=`grep "$varAtributo" /etc/rc.nfs | wc -l | tr -d " " | tr -d "\t" `
	varValEnc=`grep "$varAtributo" /etc/rc.nfs | awk '/#/' | wc -l | tr -d " " | tr -d "\t"` 
	varValDet="Servicio esperado $varAtributo # $varValEsp"
	if ( test "$varValEnc" -eq "$varValEsp" ); then
			
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi
	varValEsp="$varValDet"
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.4.2	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.4.3
	varItem="6.4"
	varItemStandard="6.4.3"		
	varCriticidad="Alto"
	varStanza="/etc/rc.nfs"
	varAtributo="keyserv"
	varDetalle="ITEM $varItem Comentar ( # ) los siguientes servicios NIS en el archivo $varStanza"	
	varValEsp=`grep "$varAtributo" /etc/rc.nfs | wc -l | tr -d " " | tr -d "\t" `
	varValEnc=`grep "$varAtributo" /etc/rc.nfs | awk '/#/' | wc -l | tr -d " " | tr -d "\t"` 
	varValDet="Servicio esperado $varAtributo # $varValEsp"
	if ( test "$varValEnc" -eq "$varValEsp" ); then
			
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi
	varValEsp="$varValDet"
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.4.3	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.4.4
	varItem="6.4"
	varItemStandard="6.4.4"		
	varCriticidad="Alto"
	varStanza="/etc/rc.nfs"
	varAtributo="nis_cachemgr"
	varDetalle="ITEM $varItem Comentar ( # ) los siguientes servicios NIS en el archivo $varStanza"	
	varValEsp=`grep "$varAtributo" /etc/rc.nfs | wc -l | tr -d " " | tr -d "\t" `
	varValEnc=`grep "$varAtributo" /etc/rc.nfs | awk '/#/' | wc -l | tr -d " " | tr -d "\t"` 
	varValDet="Servicio esperado $varAtributo # $varValEsp"
	if ( test "$varValEnc" -eq "$varValEsp" ); then
			
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi
	varValEsp="$varValDet"
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.4.4	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.4.5
	varItem="6.4"
	varItemStandard="6.4.5"		
	varCriticidad="Alto"
	varStanza="/etc/rc.nfs"
	varAtributo="rpc.nisd"
	varDetalle="ITEM $varItem Comentar ( # ) los siguientes servicios NIS en el archivo $varStanza"	
	varValEsp=`grep "$varAtributo" /etc/rc.nfs | wc -l | tr -d " " | tr -d "\t" `
	varValEnc=`grep "$varAtributo" /etc/rc.nfs | awk '/#/' | wc -l | tr -d " " | tr -d "\t"` 
	varValDet="Servicio esperado $varAtributo # $varValEsp"
	if ( test "$varValEnc" -eq "$varValEsp" ); then
			
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi
	varValEsp="$varValDet"
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.4.5	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.4.6
	varItem="6.4"
	varItemStandard="6.4.6"		
	varCriticidad="Alto"
	varStanza="/etc/rc.nfs"
	varAtributo="rpc.nispasswdd"
	varDetalle="ITEM $varItem Comentar ( # ) los siguientes servicios NIS en el archivo $varStanza"	
	varValEsp=`grep "$varAtributo" /etc/rc.nfs | wc -l | tr -d " " | tr -d "\t" `
	varValEnc=`grep "$varAtributo" /etc/rc.nfs | awk '/#/' | wc -l | tr -d " " | tr -d "\t"` 
	varValDet="Servicio esperado $varAtributo # $varValEsp"
	if ( test "$varValEnc" -eq "$varValEsp" ); then
			
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi
	varValEsp="$varValDet"
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.4.6	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.4.7
	varItem="6.4"
	varItemStandard="6.4.7"		
	varCriticidad="Alto"
	varStanza="/etc/rc.nfs"
	varAtributo="rpc.yppasswdd"
	varDetalle="ITEM $varItem Comentar ( # ) los siguientes servicios NIS en el archivo $varStanza"	
	varValEsp=`grep "$varAtributo" /etc/rc.nfs | wc -l | tr -d " " | tr -d "\t" `
	varValEnc=`grep "$varAtributo" /etc/rc.nfs | awk '/#/' | wc -l | tr -d " " | tr -d "\t"` 
	varValDet="Servicio esperado $varAtributo # $varValEsp"
	if ( test "$varValEnc" -eq "$varValEsp" ); then
			
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi
	varValEsp="$varValDet"
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.4.7	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.4.8
	varItem="6.4"
	varItemStandard="6.4.8"		
	varCriticidad="Alto"
	varStanza="/etc/rc.nfs"
	varAtributo="rpc.ypudated"
	varDetalle="ITEM $varItem Comentar ( # ) los siguientes servicios NIS en el archivo $varStanza"	
	varValEsp=`grep "$varAtributo" /etc/rc.nfs | wc -l | tr -d " " | tr -d "\t" `
	varValEnc=`grep "$varAtributo" /etc/rc.nfs | awk '/#/' | wc -l | tr -d " " | tr -d "\t"` 
	varValDet="Servicio esperado $varAtributo # $varValEsp"
	if ( test "$varValEnc" -eq "$varValEsp" ); then
			
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi
	varValEsp="$varValDet"
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.4.8	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.4.9
	varItem="6.4"
	varItemStandard="6.4.9"		
	varCriticidad="Alto"
	varStanza="/etc/rc.nfs"
	varAtributo="ypbind"
	varDetalle="ITEM $varItem Comentar ( # ) los siguientes servicios NIS en el archivo $varStanza"	
	varValEsp=`grep "$varAtributo" /etc/rc.nfs | wc -l | tr -d " " | tr -d "\t" `
	varValEnc=`grep "$varAtributo" /etc/rc.nfs | awk '/#/' | wc -l | tr -d " " | tr -d "\t"` 
	varValDet="Servicio esperado $varAtributo # $varValEsp"
	if ( test "$varValEnc" -eq "$varValEsp" ); then
			
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi
	varValEsp="$varValDet"
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.4.9	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.4.10
	varItem="6.4"
	varItemStandard="6.4.10"		
	varCriticidad="Alto"
	varStanza="/etc/rc.nfs"
	varAtributo="ypserv"
	varDetalle="ITEM $varItem Comentar ( # ) los siguientes servicios NIS en el archivo $varStanza"	
	varValEsp=`grep "$varAtributo" /etc/rc.nfs | wc -l | tr -d " " | tr -d "\t" `
	varValEnc=`grep "$varAtributo" /etc/rc.nfs | awk '/#/' | wc -l | tr -d " " | tr -d "\t"` 
	varValDet="Servicio esperado $varAtributo # $varValEsp"
	if ( test "$varValEnc" -eq "$varValEsp" ); then
			
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi
	varValEsp="$varValDet"
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.4.10	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.5.1
	varItem="6.5"
	varItemStandard="6.5.1"		
	varCriticidad="Alto"
	varStanza="/usr/bin/rsh"
	varAtributo=""
	varDetalle="ITEM $varItem Deshabilitar los SUID de los comandos r-X $varStanza"	
	varValEsp="-r-xr-xr-x"
	varValEnc=`ls -al $varStanza | awk '{print $1}'`
	if ( test "$varValEnc" = "" ); then
		varValEnc="File not exists"
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		if ( test "$varValEnc" = "$varValEsp" ); then	
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 
		else		
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
	fi 
	
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.5.1	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.5.2
	varItem="6.5"
	varItemStandard="6.5.2"		
	varCriticidad="Alto"
	varStanza="/usr/bin/rexec"
	varAtributo=""
	varDetalle="ITEM $varItem Deshabilitar los SUID de los comandos r-X $varStanza"	
	varValEsp="-r-xr-xr-x"
	varValEnc=`ls -al $varStanza | awk '{print $1}'`
	if ( test "$varValEnc" = "" ); then
		varValEnc="File not exists"
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		if ( test "$varValEnc" = "$varValEsp" ); then	
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 
		else		
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
	fi 
	
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.5.2	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.5.3
	varItem="6.5"
	varItemStandard="6.5.3"		
	varCriticidad="Alto"
	varStanza="/usr/bin/rcp"
	varAtributo=""
	varDetalle="ITEM $varItem Deshabilitar los SUID de los comandos r-X $varStanza"	
	varValEsp="-r-xr-xr-x"
	varValEnc=`ls -al $varStanza | awk '{print $1}'`
	if ( test "$varValEnc" = "" ); then
		varValEnc="File not exists"
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		if ( test "$varValEnc" = "$varValEsp" ); then	
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 
		else		
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
	fi 
	
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.5.3	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.5.4
	varItem="6.5"
	varItemStandard="6.5.4"		
	varCriticidad="Alto"
	varStanza="/usr/bin/rlogin"
	varAtributo=""
	varDetalle="ITEM $varItem Deshabilitar los SUID de los comandos r-X $varStanza"	
	varValEsp="-r-xr-xr-x"
	varValEnc=`ls -al $varStanza | awk '{print $1}'`
	if ( test "$varValEnc" = "" ); then
		varValEnc="File not exists"
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		if ( test "$varValEnc" = "$varValEsp" ); then	
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 
		else		
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
	fi 
	
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.5.4	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.5.5
	varItem="6.5"
	varItemStandard="6.5.5"		
	varCriticidad="Alto"
	varStanza="/usr/bin/rlogin"
	varAtributo=""
	varDetalle="ITEM $varItem Deshabilitar los SUID de los comandos r-X $varStanza"	
	varValEsp="-r-xr-xr-x"
	varValEnc=`ls -al $varStanza | awk '{print $1}'`
	if ( test "$varValEnc" = "" ); then
		varValEnc="File not exists"
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		if ( test "$varValEnc" = "$varValEsp" ); then	
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 
		else		
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
	fi 
	
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.5.5	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 6.5.6
	varItem="6.5"
	varItemStandard="6.5.6"		
	varCriticidad="Alto"
	varStanza="/usr/bin/remsh"
	varAtributo=""
	varDetalle="ITEM $varItem Deshabilitar los SUID de los comandos r-X $varStanza"	
	varValEsp="-r-xr-xr-x"
	varValEnc=`ls -al $varStanza | awk '{print $1}'`
	if ( test "$varValEnc" = "" ); then
		varValEnc="File not exists"
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		if ( test "$varValEnc" = "$varValEsp" ); then	
			varCumplimiento="Cumple"
			varObservaciones="Ninguna" 
		else		
			varCumplimiento="No cumple"
			varObservaciones="Error"
		fi
	fi 
	
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 6.5.6	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.1.1
	varItem="7.1"
	varItemStandard="7.1.1"		
	varCriticidad="Alto"
	varStanza="/usr/sbin/no"
	varAtributo="ipforwarding"
	varDetalle="ITEM $varItem Configuración de RED, Deshabilitar ip_forwarding para evitar que el equipo se convierta en un enrutador $varStanza"	
	varValEsp="ipforwarding = 0"
	varValEnc=`$varStanza -o $varAtributo`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.1.1	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.1.2
	varItem="7.1"
	varItemStandard="7.1.2"		
	varCriticidad="Alto"
	varStanza="/usr/sbin/no"
	varAtributo="ip6forwarding"
	varDetalle="ITEM $varItem Configuración de RED, Deshabilitar ip_forwarding para evitar que el equipo se convierta en un enrutador $varStanza"	
	varValEsp="ip6forwarding = 0"
	varValEnc=`$varStanza -o $varAtributo`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.1.2	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.2.1
	varItem="7.2"
	varItemStandard="7.2.1"		
	varCriticidad="Alto"
	varStanza="/usr/sbin/no"
	varAtributo="clean_partial_conns"
	varDetalle="ITEM $varItem Configuración de RED, Deshabilitar ip_forwarding para evitar que el equipo se convierta en un enrutador $varStanza"	
	varValEsp="clean_partial_conns = 1"
	varValEnc=`$varStanza -o $varAtributo`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.2.1	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.3.1
	varItem="7.3"
	varItemStandard="7.3.1"		
	varCriticidad="Alto"
	varStanza="/usr/sbin/no"
	varAtributo="bcastping"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los siguientes parámetros para evitar negaciones de servicios mediante paquetes ICMP de broadcast dirigidos: $varStanza"	
	varValEsp="bcastping = 0"
	varValEnc=`$varStanza -o $varAtributo`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.3.1	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.3.2
	varItem="7.3"
	varItemStandard="7.3.2"		
	varCriticidad="Alto"
	varStanza="/usr/sbin/no"
	varAtributo="directed_broadcast"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los siguientes parámetros para evitar negaciones de servicios mediante paquetes ICMP de broadcast dirigidos: $varStanza"	
	varValEsp="directed_broadcast = 0"
	varValEnc=`$varStanza -o $varAtributo`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.3.2	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.3.3
	varItem="7.3"
	varItemStandard="7.3.3"		
	varCriticidad="Alto"
	varStanza="/usr/sbin/no"
	varAtributo="icmpaddressmask"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los siguientes parámetros para evitar negaciones de servicios mediante paquetes ICMP de broadcast dirigidos: $varStanza"	
	varValEsp="icmpaddressmask = 0"
	varValEnc=`$varStanza -o $varAtributo`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.3.3	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.3.4
	varItem="7.3"
	varItemStandard="7.3.4"		
	varCriticidad="Alto"
	varStanza="/usr/sbin/no"
	varAtributo="ipsendredirects"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los siguientes parámetros para evitar negaciones de servicios mediante paquetes ICMP de broadcast dirigidos: $varStanza"	
	varValEsp="ipsendredirects = 0"
	varValEnc=`$varStanza -o $varAtributo`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.3.4	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.3.5
	varItem="7.3"
	varItemStandard="7.3.5"		
	varCriticidad="Alto"
	varStanza="/usr/sbin/no"
	varAtributo="ipignoreredirects"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los siguientes parámetros para evitar negaciones de servicios mediante paquetes ICMP de broadcast dirigidos: $varStanza"	
	varValEsp="ipignoreredirects = 1"
	varValEnc=`$varStanza -o $varAtributo`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.3.5	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.4.1
	varItem="7.4"
	varItemStandard="7.4.1"		
	varCriticidad="Alto"
	varStanza="/usr/sbin/no"
	varAtributo="ipsrcroutesend"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los siguientes parámetros para asegurar los paquetes source routed: $varStanza"	
	varValEsp="ipsrcroutesend = 0"
	varValEnc=`$varStanza -o $varAtributo`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.4.1	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.4.2
	varItem="7.4"
	varItemStandard="7.4.2"		
	varCriticidad="Alto"
	varStanza="/usr/sbin/no"
	varAtributo="ipsrcrouterecv"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los siguientes parámetros para asegurar los paquetes source routed: $varStanza"	
	varValEsp="ipsrcrouterecv = 0"
	varValEnc=`$varStanza -o $varAtributo`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.4.2	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.4.3
	varItem="7.4"
	varItemStandard="7.4.3"		
	varCriticidad="Alto"
	varStanza="/usr/sbin/no"
	varAtributo="ipsrcrouteforward"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los siguientes parámetros para asegurar los paquetes source routed: $varStanza"	
	varValEsp="ipsrcrouteforward = 0"
	varValEnc=`$varStanza -o $varAtributo`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.4.3	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.4.4
	varItem="7.4"
	varItemStandard="7.4.4"		
	varCriticidad="Alto"
	varStanza="/usr/sbin/no"
	varAtributo="ip6srcrouteforward"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los siguientes parámetros para asegurar los paquetes source routed: $varStanza"	
	varValEsp="ip6srcrouteforward = 0"
	varValEnc=`$varStanza -o $varAtributo`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.4.4	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.4.5
	varItem="7.4"
	varItemStandard="7.4.5"		
	varCriticidad="Alto"
	varStanza="/usr/sbin/no"
	varAtributo="ip6srcrouteforward"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los siguientes parámetros para asegurar los paquetes source routed: $varStanza"	
	varValEsp="ip6srcrouteforward = 0"
	varValEnc=`$varStanza -o $varAtributo`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.4.5	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.5.1
	varItem="7.5"
	varItemStandard="7.5.1"		
	varCriticidad="Alto"
	varStanza="/etc/rc.securenet"
	varAtributo=""
	varDetalle="ITEM $varItem Configuración de RED, Configurar los parámetros anteriores para que estén disponibles en cada inicio del servidor: $varStanza"	
	varValEsp="-rwx------"
	varValEnc=`ls -al $varStanza | awk '{print $1}'`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.5.1	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.5.2
	varItem="7.5"
	varItemStandard="7.5.2"		
	varCriticidad="Alto"
	varStanza="/etc/rc.securenet"
	varAtributo="ipforwarding"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los parámetros anteriores para que estén disponibles en cada inicio del servidor: $varStanza"	
	varValEsp="/usr/sbin/no -o ipforwarding=0"
	varValEnc=`cat $varStanza | grep $varAtributo`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.5.2	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.5.3
	varItem="7.5"
	varItemStandard="7.5.3"		
	varCriticidad="Alto"
	varStanza="/etc/rc.securenet"
	varAtributo="ip6forwarding"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los parámetros anteriores para que estén disponibles en cada inicio del servidor: $varStanza"	
	varValEsp="/usr/sbin/no -o ip6forwarding=0"
	varValEnc=`cat $varStanza | grep $varAtributo`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.5.3	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.5.4
	varItem="7.5"
	varItemStandard="7.5.4"		
	varCriticidad="Alto"
	varStanza="/etc/rc.securenet"
	varAtributo="clean_partial_conns"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los parámetros anteriores para que estén disponibles en cada inicio del servidor: $varStanza"	
	varValEsp="/usr/sbin/no -o clean_partial_conns=1"
	varValEnc=`cat $varStanza | grep $varAtributo`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.5.4	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.5.5
	varItem="7.5"
	varItemStandard="7.5.5"		
	varCriticidad="Alto"
	varStanza="/etc/rc.securenet"
	varAtributo="bcastping"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los parámetros anteriores para que estén disponibles en cada inicio del servidor: $varStanza"	
	varValEsp="/usr/sbin/no -o bcastping=0"
	varValEnc=`cat $varStanza | grep $varAtributo`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.5.5	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.5.6
	varItem="7.5"
	varItemStandard="7.5.6"		
	varCriticidad="Alto"
	varStanza="/etc/rc.securenet"
	varAtributo="directed_broadcast"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los parámetros anteriores para que estén disponibles en cada inicio del servidor: $varStanza"	
	varValEsp="/usr/sbin/no -o directed_broadcast=0"
	varValEnc=`cat $varStanza | grep $varAtributo`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.5.6	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.5.7
	varItem="7.5"
	varItemStandard="7.5.7"		
	varCriticidad="Alto"
	varStanza="/etc/rc.securenet"
	varAtributo="icmpaddressmask"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los parámetros anteriores para que estén disponibles en cada inicio del servidor: $varStanza"	
	varValEsp="/usr/sbin/no -o icmpaddressmask=0"
	varValEnc=`cat $varStanza | grep $varAtributo`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.5.7	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.5.8
	varItem="7.5"
	varItemStandard="7.5.8"		
	varCriticidad="Alto"
	varStanza="/etc/rc.securenet"
	varAtributo="ipsendredirects"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los parámetros anteriores para que estén disponibles en cada inicio del servidor: $varStanza"	
	varValEsp="/usr/sbin/no -o ipsendredirects=0"
	varValEnc=`cat $varStanza | grep $varAtributo`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.5.8	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.5.9
	varItem="7.5"
	varItemStandard="7.5.9"		
	varCriticidad="Alto"
	varStanza="/etc/rc.securenet"
	varAtributo="ipignoreredirects"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los parámetros anteriores para que estén disponibles en cada inicio del servidor: $varStanza"	
	varValEsp="/usr/sbin/no -o ipignoreredirects=1"
	varValEnc=`cat $varStanza | grep $varAtributo`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.5.9	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.5.10
	varItem="7.5"
	varItemStandard="7.5.10"		
	varCriticidad="Alto"
	varStanza="/etc/rc.securenet"
	varAtributo="ipsrcroutesend"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los parámetros anteriores para que estén disponibles en cada inicio del servidor: $varStanza"	
	varValEsp="/usr/sbin/no -o ipsrcroutesend=0"
	varValEnc=`cat $varStanza | grep $varAtributo`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.5.10	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.5.11
	varItem="7.5"
	varItemStandard="7.5.11"		
	varCriticidad="Alto"
	varStanza="/etc/rc.securenet"
	varAtributo="ipsrcrouterecv"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los parámetros anteriores para que estén disponibles en cada inicio del servidor: $varStanza"	
	varValEsp="/usr/sbin/no -o ipsrcrouterecv=0"
	varValEnc=`cat $varStanza | grep $varAtributo`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.5.11	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.5.12
	varItem="7.5"
	varItemStandard="7.5.12"		
	varCriticidad="Alto"
	varStanza="/etc/rc.securenet"
	varAtributo="ipsrcrouteforward"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los parámetros anteriores para que estén disponibles en cada inicio del servidor: $varStanza"	
	varValEsp="/usr/sbin/no -o ipsrcrouteforward=0"
	varValEnc=`cat $varStanza | grep $varAtributo | awk -F"=" '{print $1"="$2}'`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.5.12	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.5.13
	varItem="7.5"
	varItemStandard="7.5.13"		
	varCriticidad="Alto"
	varStanza="/etc/rc.securenet"
	varAtributo="ip6srcrouteforward"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los parámetros anteriores para que estén disponibles en cada inicio del servidor: $varStanza"	
	varValEsp="/usr/sbin/no -o ip6srcrouteforward=0"
	varValEnc=`cat $varStanza | grep $varAtributo | awk -F"=" '{print $1"="$2}'`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.5.13	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.5.14
	varItem="7.5"
	varItemStandard="7.5.14"		
	varCriticidad="Alto"
	varStanza="/etc/rc.securenet"
	varAtributo="udp_pmtu_discover"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los parámetros anteriores para que estén disponibles en cada inicio del servidor: $varStanza"	
	varValEsp="/usr/sbin/no -o udp_pmtu_discover=0"
	varValEnc=`cat $varStanza | grep $varAtributo | awk -F"=" '{print $1"="$2}'`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.5.14	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.5.15
	varItem="7.5"
	varItemStandard="7.5.15"		
	varCriticidad="Alto"
	varStanza="/etc/rc.securenet"
	varAtributo="tcp_pmtu_discover"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los parámetros anteriores para que estén disponibles en cada inicio del servidor: $varStanza"	
	varValEsp="/usr/sbin/no -o tcp_pmtu_discover=0"
	varValEnc=`cat $varStanza | grep $varAtributo | awk -F"=" '{print $1"="$2}'`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.5.15	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.5.16
	varItem="7.5"
	varItemStandard="7.5.16"		
	varCriticidad="Alto"
	varStanza="/etc/rc.securenet"
	varAtributo="nonlocsrcroute"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los parámetros anteriores para que estén disponibles en cada inicio del servidor: $varStanza"	
	varValEsp="/usr/sbin/no -o nonlocsrcroute=0"
	varValEnc=`cat $varStanza | grep $varAtributo | awk -F"=" '{print $1"="$2}'`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.5.16	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 7.5.17
	varItem="7.5"
	varItemStandard="7.5.17"		
	varCriticidad="Alto"
	varStanza="/etc/rc.securenet"
	varAtributo="portcheck"
	varDetalle="ITEM $varItem Configuración de RED, Configurar los parámetros anteriores para que estén disponibles en cada inicio del servidor: $varStanza"	
	varValEsp="/usr/sbin/nfso -o portcheck=1"
	varValEnc=`cat $varStanza | grep $varAtributo | awk -F"=" '{print $1"="$2}'`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 7.5.17	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.1.1
	varItem="8.1"
	varItemStandard="8.1.1"		
	varCriticidad="Alto"
	varStanza="/etc/ssh/sshd_config"
	varAtributo="Port"
	varDetalle="ITEM $varItem Configuración servicios SSH, Editar el archivo /etc/ssh/sshd_config, y habilitar los siguientes parámetros:: $varStanza"	
	varValEsp="Port 22"
	varValEnc=`cat $varStanza | grep "^$varAtributo" | tail -1 `
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.1.1	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.1.2
	varItem="8.1"
	varItemStandard="8.1.2"		
	varCriticidad="Alto"
	varStanza="/etc/ssh/sshd_config"
	varAtributo="Protocol"
	varDetalle="ITEM $varItem Configuración servicios SSH, Editar el archivo /etc/ssh/sshd_config, y habilitar los siguientes parámetros:: $varStanza"	
	varValEsp="Protocol 2"
	varValEnc=`cat $varStanza | grep "^$varAtributo" | tail -1 `
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.1.2	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.1.3
	varItem="8.1"
	varItemStandard="8.1.3"		
	varCriticidad="Alto"
	varStanza="/etc/ssh/sshd_config"
	varAtributo="ListenAddress"
	varDetalle="ITEM $varItem Configuración servicios SSH, Editar el archivo /etc/ssh/sshd_config, y habilitar los siguientes parámetros:: $varStanza"	
	varValEsp="ListenAddress IPAddress"
	varValBus=`cat $varStanza | grep "^$varAtributo" | awk '{print $2}' | tail -1 `
	varValCont=`echo $varValBus | wc -m | tr -d "\t"`
	if ( test $varValCont -gt 1 ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna"
		varValEnc="ListenAddress $varValBus"
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
		varValEnc="ListenAddress $varValBus"
		
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.1.3	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.1.4
	varItem="8.1"
	varItemStandard="8.1.4"		
	varCriticidad="Alto"
	varStanza="/etc/ssh/sshd_config"
	varAtributo="IgnoreRhosts"
	varDetalle="ITEM $varItem Configuración servicios SSH, Editar el archivo /etc/ssh/sshd_config, y habilitar los siguientes parámetros:: $varStanza"	
	varValEsp="IgnoreRhosts yes"
	varValEnc=`cat $varStanza | grep "^$varAtributo" | tail -1 `
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.1.4	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.1.5
	varItem="8.1"
	varItemStandard="8.1.5"		
	varCriticidad="Alto"
	varStanza="/etc/ssh/sshd_config"
	varAtributo="PermitEmptyPasswords"
	varDetalle="ITEM $varItem Configuración servicios SSH, Editar el archivo /etc/ssh/sshd_config, y habilitar los siguientes parámetros:: $varStanza"	
	varValEsp="PermitEmptyPasswords no"
	varValEnc=`cat $varStanza | grep "^$varAtributo" | tail -1 `
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.1.5	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.1.6
	varItem="8.1"
	varItemStandard="8.1.6"		
	varCriticidad="Alto"
	varStanza="/etc/ssh/sshd_config"
	varAtributo="StrictModes"
	varDetalle="ITEM $varItem Configuración servicios SSH, Editar el archivo /etc/ssh/sshd_config, y habilitar los siguientes parámetros:: $varStanza"	
	varValEsp="StrictModes yes"
	varValEnc=`cat $varStanza | grep "^$varAtributo" | tail -1 `
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.1.6	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.1.7
	varItem="8.1"
	varItemStandard="8.1.7"		
	varCriticidad="Alto"
	varStanza="/etc/ssh/sshd_config"
	varAtributo="KeepAlive"
	varDetalle="ITEM $varItem Configuración servicios SSH, Editar el archivo /etc/ssh/sshd_config, y habilitar los siguientes parámetros:: $varStanza"	
	varValEsp="KeepAlive yes"
	varValEnc=`cat $varStanza | grep "^$varAtributo" | tail -1 `
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.1.7	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.1.8
	varItem="8.1"
	varItemStandard="8.1.8"		
	varCriticidad="Alto"
	varStanza="/etc/ssh/sshd_config"
	varAtributo="PasswordAuthentication"
	varDetalle="ITEM $varItem Configuración servicios SSH, Editar el archivo /etc/ssh/sshd_config, y habilitar los siguientes parámetros:: $varStanza"	
	varValEsp="PasswordAuthentication yes"
	varValEnc=`cat $varStanza | grep "^$varAtributo" | tail -1 `
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.1.8	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.1.9
	varItem="8.1"
	varItemStandard="8.1.9"		
	varCriticidad="Alto"
	varStanza="/etc/ssh/sshd_config"
	varAtributo="AllowTcpForwarding"
	varDetalle="ITEM $varItem Configuración servicios SSH, Editar el archivo /etc/ssh/sshd_config, y habilitar los siguientes parámetros:: $varStanza"	
	varValEsp="AllowTcpForwarding no"
	varValEnc=`cat $varStanza | grep "^$varAtributo" | tail -1 `
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.1.9	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.1.10
	varItem="8.1"
	varItemStandard="8.1.10"		
	varCriticidad="Alto"
	varStanza="/etc/ssh/sshd_config"
	varAtributo="PermitRootLogin"
	varDetalle="ITEM $varItem Configuración servicios SSH, Editar el archivo /etc/ssh/sshd_config, y habilitar los siguientes parámetros:: $varStanza"	
	varValEsp="PermitRootLogin no"
	varValEnc=`cat $varStanza | grep "^$varAtributo" | tail -1 `
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.1.10	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.1.11
	varItem="8.1"
	varItemStandard="8.1.11"		
	varCriticidad="Alto"
	varStanza="/etc/ssh/sshd_config"
	varAtributo="Printmotd"
	varDetalle="ITEM $varItem Configuración servicios SSH, Editar el archivo /etc/ssh/sshd_config, y habilitar los siguientes parámetros:: $varStanza"	
	varValEsp="Printmotd yes"
	varValEnc=`cat $varStanza | grep "^$varAtributo" | tail -1 `
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.1.11	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.2.1
	varItem="8.2"
	varItemStandard="8.2.1"		
	varCriticidad="Alto"
	varStanza="/etc/ntp.conf"
	varAtributo="server"
	varDetalle="ITEM $varItem Configuración NTP, Incluir la Ip del servidor de Tiempo en el archivo $varStanza"
	varValEsp="server"	
	varSrvNtp="ecuio012d04 ecuio012d02 ecbpprd11 10.0.0.163 10.151.1.125 ECUIO012D04 ECUIO012D02 ECBPPRD11"
	varFlag="False"
	varValEnc=`cat /etc/ntp.conf | grep "^server" | awk '{print $2}'`
	if ( test -f "/etc/ntp.conf" ); then
		if	( test "$varValEnc" = "`echo $varSrvNtp | awk '{print $1}'`" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
			varFlag="True"
		fi
		if	( test "$varValEnc" = "`echo $varSrvNtp | awk '{print $2}'`" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
			varFlag="True"
		fi
		if	( test "$varValEnc" = "`echo $varSrvNtp | awk '{print $3}'`" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
			varFlag="True"
		fi
		
		if	( test "$varValEnc" = "`echo $varSrvNtp | awk '{print $4}'`" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
			varFlag="True"
		fi
		if	( test "$varValEnc" = "`echo $varSrvNtp | awk '{print $5}'`" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
			varFlag="True"
		fi
		if	( test "$varValEnc" = "`echo $varSrvNtp | awk '{print $6}'`" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
			varFlag="True"
		fi
		if	( test "$varValEnc" = "`echo $varSrvNtp | awk '{print $7}'`" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
			varFlag="True"
		fi
		if	( test "$varValEnc" = "`echo $varSrvNtp | awk '{print $8}'`" ) ; then
			varCumplimiento="Cumple"	
			varObservaciones="Ninguna"
			varFlag="True"
		fi
		if	( test "$varFlag" = "False" ) ; then
			varCumplimiento="No Cumple"	
			varObservaciones="Error"
			varValEnc="Not configurated"
		fi
		echo $varValEnc
	else
		varCumplimiento="No Cumple"	
		varValEnc="Not exists file"
		varObservaciones="Error"
	fi	

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.2.1	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.2.2
	varItem="8.2"
	varItemStandard="8.2.2"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/xntpd "
	varDetalle="ITEM $varItem Configuración NTP, Descomentar la siguiente línea en el archivo /etc/rc.tcpip $varStanza"	
	varValEsp="start /usr/sbin/xntpd \"\$src_running\""
	varValEnc=`cat $varStanza | grep "$varAtributo" | tail -1 `
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.2.2	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.3.1
	varItem="8.3"
	varItemStandard="8.3.1"		
	varCriticidad="Alto"
	varStanza="default:"
	varAtributo="fsize "
	varDetalle="ITEM $varItem Configurar los límites del sistema, Editar el archivos /etc/security/limits y modificar los siguientes parámetros: $varStanza"	
	varValEsp="fsize = -1"
	varValEnc=`grep -p "$varStanza" "/etc/security/limits" | grep "$varAtributo" | tail -1 | tr -d "\t" | awk '{print $1, $2, $3}'`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.3.1	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.3.2
	varItem="8.3"
	varItemStandard="8.3.2"		
	varCriticidad="Alto"
	varStanza="default:"
	varAtributo="core "
	varDetalle="ITEM $varItem Configurar los límites del sistema, Editar el archivos /etc/security/limits y modificar los siguientes parámetros: $varStanza"	
	varValEsp="core = -1"
	varValEnc=`grep -p "$varStanza" "/etc/security/limits" | grep "$varAtributo" | tail -1 | tr -d "\t" | awk '{print $1, $2, $3}'`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.3.2	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.3.3
	varItem="8.3"
	varItemStandard="8.3.3"		
	varCriticidad="Alto"
	varStanza="default:"
	varAtributo="data "
	varDetalle="ITEM $varItem Configurar los límites del sistema, Editar el archivos /etc/security/limits y modificar los siguientes parámetros: $varStanza"	
	varValEsp="data = -1"
	varValEnc=`grep -p "$varStanza" "/etc/security/limits" | grep "$varAtributo" | tail -1 | tr -d "\t" | awk '{print $1, $2, $3}'`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.3.3	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.3.4
	varItem="8.3"
	varItemStandard="8.3.4"		
	varCriticidad="Alto"
	varStanza="default:"
	varAtributo="rss "
	varDetalle="ITEM $varItem Configurar los límites del sistema, Editar el archivos /etc/security/limits y modificar los siguientes parámetros: $varStanza"	
	varValEsp="rss = -1"
	varValEnc=`grep -p "$varStanza" "/etc/security/limits" | grep "$varAtributo" | tail -1 | tr -d "\t" | awk '{print $1, $2, $3}'`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.3.4	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.3.5
	varItem="8.3"
	varItemStandard="8.3.5"		
	varCriticidad="Alto"
	varStanza="default:"
	varAtributo="nofiles"
	varDetalle="ITEM $varItem Configurar los límites del sistema, Editar el archivos /etc/security/limits y modificar los siguientes parámetros: $varStanza"	
	varValEsp="nofiles = -1"
	varValEnc=`grep -p "$varStanza" "/etc/security/limits" | grep "$varAtributo" | tail -1 | tr -d "\t" | awk '{print $1, $2, $3}'`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else		
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi

	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.3.5	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.3.6
	varItem="8.3"
	varItemStandard="8.3.6"		
	varCriticidad="Alto"
	varStanza="default:"
	varAtributo="stack "
	varDetalle="ITEM $varItem Configurar los límites del sistema, Editar el archivos /etc/security/limits y modificar los siguientes parámetros: $varStanza"	
	varValEsp="stack = -1"
	varValEnc=`grep -p "$varStanza" "/etc/security/limits" | grep "$varAtributo" | tail -1 | tr -d "\t" | awk '{print $1, $2, $3}'`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		if ( test "$varValEnc" = "" ); then		
		varValEnc=`Not Configurated`
		varCumplimiento="No cumple"
		varObservaciones="Error"
		fi
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.3.6	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.4.1
	varItem="8.4"
	varItemStandard="8.4.1"		
	varCriticidad="Alto"
	varStanzaHigh="/etc/security/fpm/data/high_fpm_list"
	varStanzaMedium="/etc/security/fpm/data/med_fpm_list"
	varAtributo=""
	varDetalle="ITEM $varItem Configurar los límites del sistema, Chequear permisos setuid y setgid.en los archivos del sistema fpm_list"	
	varValEsp="TotalHigh = 0, TotalMedium = 0"
	varValDet=""
	varValEncHigh=`cat "$varStanzaHigh" | xargs ls -la 2>/dev/null | awk '{print $1, $NF}' | awk '{print $1}' | grep -i "s" | wc -l | awk '{print $1}'`
	varValEncMedium=`cat "$varStanzaMedium" | xargs ls -la 2>/dev/null | awk '{print $1, $NF}' | awk '{print $1}' | grep -i "s" | wc -l | awk '{print $1}'`
	varValEnc="TotalHigh = $varValEncHigh, TotalMedium = $varValEncMedium"
	if ( test "$varValEsp" = "$varValEnc" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi
	
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.4.1	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.5.1
	varItem="8.5"
	varItemStandard="8.5.1"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/snmpd"
	varDetalle="ITEM $varItem Configurcion SNMP, Para evitar que se inicie el servicio se deben comentar las lìneas que comienzan con start: $varStanza"	
	varValEsp="#start /usr/sbin/snmpd \"\$src_running\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo"`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.5.1	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.5.2
	varItem="8.5"
	varItemStandard="8.5.2"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/hostmibd"
	varDetalle="ITEM $varItem Configurcion SNMP, Para evitar que se inicie el servicio se deben comentar las líneas que comienzan con start: $varStanza"	
	varValEsp="#start /usr/sbin/hostmibd \"\$src_running\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo"`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.5.2	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.5.3
	varItem="8.5"
	varItemStandard="8.5.3"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/snmpmibd"
	varDetalle="ITEM $varItem Configurcion SNMP, Para evitar que se inicie el servicio se deben comentar las lìneas que comienzan con start: $varStanza"	
	varValEsp="#start /usr/sbin/snmpmibd \"\$src_running\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo"`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.5.3	
#-----------------------------------------


#------------------------------------------
# [INICIO] ÍTEM 8.5.4
	varItem="8.5"
	varItemStandard="8.5.4"		
	varCriticidad="Alto"
	varStanza="/etc/rc.tcpip"
	varAtributo="start /usr/sbin/aixmibd"
	varDetalle="ITEM $varItem Configurcion SNMP, Para evitar que se inicie el servicio se deben comentar las lìneas que comienzan con start: $varStanza"	
	varValEsp="#start /usr/sbin/aixmibd \"\$src_running\""
	varValEnc=`cat $varStanza | awk '{print $1, $2, $3}' | grep "$varAtributo"`
	if ( test "$varValEnc" = "$varValEsp" ); then	
		varCumplimiento="Cumple"
		varObservaciones="Ninguna" 
	else
		varCumplimiento="No cumple"
		varObservaciones="Error"
	fi
	varItemReg="$oDate|$constServer|$constVersion|$varItem|$varItemStandard|$varCriticidad|$varDetalle|$varValEsp|$varValEnc|$varCumplimiento|$varObservaciones"
	echo "$varItemReg"
	echo "$dateTime|$constServer|$varItemStandard|$varValEnc --- $varObservaciones" >> $constPathClb/LOG_$constServer.$oMonth.log
	echo $varItemReg >> $constPathClb/CLB_$constServer.$oMonth.csv
# [FIN] ÍTEM 8.5.4	
#-----------------------------------------




echo		
if (test -f  $constPathClb/CLB_$constServer.$oMonth.csv ); then
	echo [*] El archivo CLB fue creado de manera satisfactoria  $constPathClb/CLB_$constServer.$oMonth.csv
else
	echo [*] No se pudo crear el archivo CLB $constPathClb/CLB_$constServer.$oMonth.csv 
	echo [*] Error al ejecutasr el control de linea base 
fi

echo 	 
echo [FIN PROCESO] - $dateTime 
echo